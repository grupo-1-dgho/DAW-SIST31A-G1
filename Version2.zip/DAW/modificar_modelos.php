<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($_SESSION["esadministrador"]))) {
header("Location:principal_docente.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>

 <?php
 include_once("conexion.php");
if (isset($_POST["ok"])) {
	$id=$_POST["idmodelo"];
	$modelo=ucfirst($_POST["modelo"]);
	$idmarca=ucfirst($_POST["idmarca"]);
	$update="UPDATE Modelos set Modelo='$modelo' , IdMarca='$idmarca' where IdModelo='$id'";
	$conexion->query($update);
	echo "<script> 
        location.href='index.php?pag=modelos.php';
    </script>";
}
   ?>
   <?php 

$id=$_GET["idcat"];
$consultar="select * from Modelos where IdModelo='$id'";
$r=$conexion->query($consultar);
$fila=$r->fetch_assoc();
 ?>
 <form method="post">
 	<table class=blue-form2>
 		<tr>
 	<th>Modificar Modelos</th>
</tr>
<tr>
	<td><input name="idmodelo" type="hidden" value="<?php echo $fila["IdModelo"]?>"> 
		Modelo<br><input type="text" name="modelo" class="texto" value="<?php echo $fila["Modelo"];?>" required=required></td>
</tr>
<tr>
	<td>Marca<br><select class="select" name="idmarca">
		<?php  
$sql="select * from Marcas";
$r=$conexion->query($sql);
while ($row=$r->fetch_assoc()) {
	if($row["IdMarca"]==$fila["IdMarca"]){
		echo "
<option value=".$row["IdMarca"]." selected=selected>".$row["Marca"]."</option>";
	}elseif($row["IdMarca"]!=$fila["IdMarca"]){

		echo "
<option value=".$row["IdMarca"].">".$row["Marca"]."</option>";}
}
		?>

	</select></td>
</tr>
<tr><th><input type="submit" name="ok" class="boton" value="Actualizar"></th></tr>
 	</table>
 </form>
 