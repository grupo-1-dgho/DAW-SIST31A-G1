<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($_SESSION["esadministrador"]))) {
header("Location:principal_docente.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>
<a href="?pag=agregar_fallas.php">Volver</a><br>
<?php  
include_once 'Clase_Fallas.php';
$falla=new Fallas();
if (isset($_POST["eliminar"]) and isset($_POST['idfallas']) ) {
	$idfalla=$_POST['idfallas'];
	$resultado=$falla->eliminar($idfalla);
	
}
if (!(isset($_SESSION["id"]))){
$_SESSION["id"]=$_GET["idcat"];
$resultado=$falla->mostrar($_SESSION["id"]);
echo "$resultado";
}
else{
	
$resultado=$falla->mostrar($_SESSION["id"]);
echo "$resultado";
}


?>

