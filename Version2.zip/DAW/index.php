<?php
@session_start();  
$usaindex='si';
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}


?>
<!DOCTYPE html>
<html>

<head>
	<link rel="stylesheet" type="text/css" href="css/sweetalert2.css">
<script type="text/javascript" src="css/sweetalert2.min.js.download"></script>
<script type="text/javascript">
	function aler(titulo,mensaje)
	{  Swal.fire({ 
	   type: 'error',   
	    title: titulo,   
	     text: mensaje  
	 }) 
}
function aler2(titulo,mensaje)
	{  Swal.fire({ 
	   type: 'info',   
	    title: titulo,   
	     text: mensaje  
	 }) 
}
</script> 

	<title>SISTEMA ITCA</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<style type="text/css">
body{
	font-family: Comic Sans MS,Arial,Verdana;
		
}
 .blue-form3 { 
    border:3px solid #3E83C9; 
    margin-top: 0px; 
    margin-bottom: 10px; 
    font-size:80%; 
    font-weight: bold;
     width: 100%;
    background-color: white;
 /*establece la altura máxima, lo que no entre quedará por debajo y saldra la barra de scroll*/

} 
.blue-form3 th{ 
    border-bottom:3px solid #999; 
    width: auto;
    background-color:#9B0B0D;
    color: white; 
}
/*esto no lo tienen que editar*/
article{
			width: 95%;
			border-radius: 20px;
			padding: 8px;
			box-sizing: border-box;
			background-color: #16C0CA;
			margin: 10px;
			text-align: left;
			font-size: 18px;
		}
 .texto:focus{
    border:3px solid green;
}
 .texto2:focus{
    border:3px solid green;
}
.select:focus{
    border:3px solid green;
}
.checkbox :click{
    border:3px solid green;
}
/*esto no lo tienen que editar*/
section{
			width: 85%;
			border-radius: 20px;
			padding: 10px;
			box-sizing: border-box;
			background-color: #0984DA;
		}

.texto{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 70%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
		.texto2{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 40%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
.textarea{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 70%;
			border-radius: 15px;
			height: 70px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
 .select{
			width: 45%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
.select2{
		width: 100%;
		border-radius: 15px;
		height: 25px;
		border:1px black solid;
		font-size: 15px;
		font-family: Comic Sans MS,Arial,Verdana;
		}
input[type="checkbox"] {
   width: 20px;
   height: 20px;
}
input[type="radio"] {
   width: 20px;
   height: 20px;
}
.boton{
	/*dependiento del texto del boton pueden cambiarle el ancho en el width*/
	border-radius: 20px;
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 160px;
	font-size: 18px;
	background-color:green;
	color: white;
}
.blue-form { 
    border:3px solid #3E83C9; 
    margin-top: 0px; 
    margin-bottom: 10px; 
    font-size:80%; 
    font-weight: bold;
     width: 70%;
    background-color: white;
 /*establece la altura máxima, lo que no entre quedará por debajo y saldra la barra de scroll*/

} 
.blue-form th{ 
    border-bottom:3px solid #999; 
    width: auto;
    background-color:#9B0B0D;
    color: white; 
} 
.blue-form td{ 
    border-bottom:1px solid #999; 
   width: auto;
}
.blue-form2 td{ 
    border-bottom:1px solid #999; 
   width: auto;
} 
.blue-form2 th{ 
    border-bottom:3px solid #999; 
    width: auto;
    background-color:#9B0B0D;
    color: white; 
} 
.boton2{
	/*dependiento del texto del boton pueden cambiarle el ancho en el width*/
	border-radius: 20px;
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 150px;
	font-size: 18px;
	background-color:#1C2EDE;
	color: white;
}
.blue-form2 { 
    border:3px solid #3E83C9; 
    margin-top: 0px; 
    margin-bottom: 10px; 
    font-size:80%; 
    font-weight: bold;
     width: 45%;
    background-color: white;
    float: left;
    margin-right: 50px ;
 /*establece la altura máxima, lo que no entre quedará por debajo y saldra la barra de scroll*/

} 
	</style>


</head>
<body bgcolor="#A80A0D" >
<!--<?php
/*$Datetime = 'America/El_Salvador';
date_default_timezone_set($Datetime);
echo "Fecha: " . date("d/m/Y")."<br>" ;
echo "Hora: " . date("h:i:s A")."<br>" ;*/
  ?>-->
  <form method="post" action="login.php" >
  	<input type="submit" name="cerrar" value="Cerrar sesión" class="boton2">
  </form><br><br>
<center>
<section>
		<!--aqui se incluye el encabezado. NO BORRAR NUNCA ESTO-->
		<?php
include_once("encabezado.html");
		?>
<!--aqui se incluye el menu. NO BORRAR NUNCA ESTO-->
<?php
if ($_SESSION["usuario"]["cargo"]=="Administrador") {
	include_once("menus/menu_mantenimiento.html");
}elseif ($_SESSION["usuario"]["cargo"]=="Docente") {
	include_once("menus/menu_docente.html");
}



		?>
		<!--aqui se incluye el contenido. ESTO ES LO UNICO DONDE VAN IR EDITANDO-->
<article><fieldset>
	
	<?php 
	if(isset($_GET["pag"])){ 
    require_once($_GET["pag"]); 
} ?>
</fieldset>
</article>
<!--aqui se incluye el pie de pagina. NO BORRAR NUNCA ESTO-->

			<?php
include_once("pie.html");
		?>
	</section></center>
</section>

</body>
</html>

