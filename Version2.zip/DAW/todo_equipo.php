<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($_SESSION["esadministrador"]))) {
header("Location:principal_docente.php");
}
  
?>
<?php include_once("conexion.php");
    	$sql2="SELECT
    `equipos`.`IdEquipo`
    , `equipos`.`NombreEquipo`
    , `equipos`.`Descripcion`
    , `equipos`.`NumeroSerie`
    , `equipos`.`Estado`
    , `equipos`.`Fecha_Registro`
    , `marcas`.`Marca`
    , `tiposequipo`.`Tipo`
    , `carreras`.`Carrera`
    , `modelos`.`Modelo`
FROM
    `proyecto2019_5`.`equipos`
    INNER JOIN `proyecto2019_5`.`marcas` 
        ON (`equipos`.`IdMarca` = `marcas`.`IdMarca`)
    INNER JOIN `proyecto2019_5`.`tiposequipo` 
        ON (`equipos`.`IdTipo` = `tiposequipo`.`IdTipo`)
    INNER JOIN `proyecto2019_5`.`carreras` 
        ON (`equipos`.`IdCarrera` = `carreras`.`IdCarrera`)
    INNER JOIN `proyecto2019_5`.`modelos` 
        ON (`equipos`.`IdModelo` = `modelos`.`IdModelo`)
;
        ";
if ($conexion->query($sql2)==TRUE) {
    $resultado2=$conexion->query($sql2);
    
if ($resultado2->num_rows>0) {
$valor=' ';
$valor.="<br><form method=post>";
$valor.="<input type=submit  name=Ndisponible value='No disponible' class=boton2>
<input type=submit  name=Sdisponible value='Disponible' class=boton2><br><br>";
$valor.="<table class=blue-form3 cellpadding=8 width=100%>
<tr>
<th width='1%'>ID</th>
<th>Nombre</th>
<th>N° <br>Serie</th>
<th>Marca</th>
<th>Modelo</th>
<th>Tipo</th>
<th>Carrera</th>
<th>Estado</th>
<th width='20%'>Descripcion</th>
<th >Fecha de <br>Registro</th>
<th> <a href='?pag=agregar_fallas.php'><img src=img/agreg.jpg width=25 height=25 title='Agregar Fallas'></a></th>
</tr>
";

    while ($fila=$resultado2->fetch_assoc()) {
        $valor.=" 
<tr>
<td >
<input type=checkbox name=equipos[] class=checkbox value='$fila[IdEquipo]' ></td>";
        $valor.="
<td>$fila[NombreEquipo]</td>
<td>$fila[NumeroSerie]</td>
<td >$fila[Marca]</td>
<td >$fila[Modelo]</td>
<td>$fila[Tipo]</td>
<td> $fila[Carrera]</td>
<td>$fila[Estado]</td>
<td >$fila[Descripcion]</td>
<td >$fila[Fecha_Registro]</td>
<td><a href='?pag=modificar_equipos.php&idcat=$fila[IdEquipo]'><img src=img/edit.jpg width=25 height=25 title='Modificar Registro'></a>
    </td>
</tr>

    ";
  
    	
    } $valor.="</table></form>" ;  echo "$valor";}}
    ?>