<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>

 <?php
 include_once'Clase_Prestamos.php';
 include_once'Conectar.php';
 $objeto=new Prestamos();
 $c=new Conexion();
$id=$_GET["idcat"];

if (isset($_POST["ok"])) {
//para insertar a la tabla prestamo
$idusuario=$_SESSION["usuario2"]["IdUsuario"];
$idaula=$_POST["IdAula"];
$tabla1="Prestamos";
$campos1="IdEquipo,IdUsuario,IdAula";
$valores1="'$id','$idusuario','$idaula'";
//para insertar a la tabla horarios
$inicio=$_POST["inicio"];
$fin=$_POST["fin"];
$fecha=$_POST["fecha"];
$total=$inicio."-".$fin;
$tabla2="horarios_prestamo";
$campos2="HoraInicio,HoraFinal,Fecha,HoraTotal";
$valores2="'$inicio','$fin','$fecha','$total'";
//para verificar si el prestamo ya existe
$resultado=$objeto->prestamoexistente($id,$fecha,$total);
if ($resultado==TRUE) {
	$r=$objeto->mensajeprestamo($id,$total);
	echo $r;
	echo"<script>Location.href='?pag=realizar_prestamo.php';</script>";
}else{
$mensaje1=$objeto->agregar($tabla1,$campos1,$valores1);
$mensaje2=$objeto->agregar($tabla2,$campos2,$valores2);

if ($mensaje1==TRUE and $mensaje2==TRUE) {
	$sql="SELECT * from prestamos 
	WHERE IdEquipo='$id' and IdAula='$idaula' and IdUsuario='$idusuario' LIMIT 1	";
	$res1=$c->consultar($sql);
	$sql2="SELECT * from horarios_prestamo 
	WHERE HoraInicio='$inicio' and HoraFinal='$fin' and Fecha='$fecha' and HoraTotal='$total' LIMIT 1";
	$res2=$c->consultar($sql2);
	if ($res1->num_rows>0 and $res2->num_rows>0) {
	$fila1=$res1->fetch_assoc();
	$fila2=$res2->fetch_assoc();	
	$idprestamo=$fila1["IdPrestamo"];
	$idhorario=$fila2["IdHorario"];
	$tabla3="descripcionprestamo";
$campos3="IdPrestamo,IdHorario";
$valores3="'$idprestamo','$idhorario'";
$mensaje3=$objeto->agregar($tabla3,$campos3,$valores3);
if ($mensaje3==TRUE) {
	echo "<script>alert('Prestamo realizado');location.href='?pag=buscar_equipo.php';</script>";
}else{
	
	echo "No se guardo el prestamo";
	}
}

}}
}
$tabla=$objeto->prestar($id);
echo $tabla;


   ?>

 
 