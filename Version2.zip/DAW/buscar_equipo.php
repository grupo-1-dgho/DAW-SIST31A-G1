<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>



<script type="text/javascript">
function xmlhttp(){
        var xmlhttp;
        try{xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");}
        catch(e){
            try{xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");}
            catch(e){
                try{xmlhttp = new XMLHttpRequest();}
                catch(e){
                    xmlhttp = false;
                }
            }
        }
        if (!xmlhttp)
                return null;
            else
                return xmlhttp;
    }

function buscar(){
        var query = document.getElementById('busqueda').value;
        var A = document.getElementById('resultados');
        var ajax = xmlhttp();
 
        ajax.onreadystatechange=function(){
                if(ajax.readyState==4 && ajax.status==200){
                        
                        A.innerHTML = ajax.responseText;
                    }
            }
ajax.open("GET","prestamos.php?valor="+query);

        ajax.send(null);
        return false;
    }
</script>

<style type="text/css">
    
    .text{
    /*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
width: 40%;
border-radius: 15px;
height: 25px;
border:1px black solid;
font-size: 15px;
 font-family: Comic Sans MS,Arial,Verdana;
        }
.selec{
 width: 30%;
border-radius: 15px;
height: 25px;
border:1px black solid;
font-size: 15px;
 font-family: Comic Sans MS,Arial,Verdana;
        }
        .text:focus{
    border:3px solid green;
}
</style>
	
<legend>Buscar Equipos</legend>
Nombre del Equipo:
<input type=text name=dato required=required class=text id=busqueda onKeyUp=buscar(); placeholder="Escribe aquí..." autofocus="">

<div id=resultados class=nocss>
</div>




