<?php
@session_start();  
unset($_SESSION["id"]);
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($_SESSION["esadministrador"]))) {
header("Location:principal_docente.php");
}elseif (!(isset($usaindex))) {
    header("Location:index.php");
}
  
?>

<script type="text/javascript">
    function validar(form){
if (form.falla.value.length <8) {
msg="Error: Debe agregar al menos 8 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.falla.focus();
return false;
}
    }
</script>
<?php 
if (isset($_POST["ok"])) {
    include_once'conexion.php';
    $fecha=date("Y/m/d");
    $falla=$_POST["falla"];
    $id=$_POST["serie"];
    $disponible=$_POST["disponible"];
    $inser="INSERT INTO fallas_equipo (IdEquipo,Descripcion,Fechareporte) VALUES ('$id','$falla','$fecha')";
   if ($disponible=='si') {
       $update="update Equipos set Estado='Disponible' where IdEquipo='$id'";
$conexion->query($update);
   }else{
      $update="update Equipos set Estado='No Disponible' where IdEquipo='$id'";
$conexion->query($update);
   }
    if ($conexion->query($inser)==TRUE) {
        echo "<script>
alert('Falla Guardada');
 </script>
        ";
    }else{
       echo "<script>
alert('Falla No Guardada');
 </script>
        ";
    }
 } 
?>
<?php 
include 'conexion.php';
$carreras="select * from equipos";
$r_m=$conexion->query($carreras);
if ($r_m->num_rows==0) {
    echo "<h1>DEBEN EXIXTIR EQUIPOS PARA INGRESAR FALLAS</h1>";
}else{
 ?>

<form method="post" onsubmit="return validar(this);">
    <table class="blue-form2" >

    <tr><th colspan="2">Descripción de La falla</th>    </tr>
    
    <tr><td>Número de serie<br> del equipo:</td><td>
<?php  
include_once 'conexion.php';
$sql="select NumeroSerie,IdEquipo from Equipos";
$r=$conexion->query($sql);
echo "<select name=serie class=select2><";
 while ($row=$r->fetch_assoc()) {
echo "<option value=$row[IdEquipo]>$row[NumeroSerie]</option>";

 }

echo "</select>";
?>

    </td></tr>
    <tr><td colspan="2"><textarea class="textarea" name=falla id=falla autofocus=""  required="required" placeholder="Escriba la falla...."></textarea></td></tr>
    <tr><td>El equipo está disponible<br>para prestar</td><td>
        <input type="radio" name="disponible" class="radio" value=si required="">Si
        <input type="radio" name="disponible" class="radio" value='no' required="">No
    </td></tr>
    <tr><th colspan="2"><input type="submit" name="ok" class="boton" value="Guardar" ></th></tr>
    </table>
</form>

<?php include_once("conexion.php");
    	$sql2="SELECT 
    `equipos`.`IdEquipo`
    , `equipos`.`NombreEquipo`
    , `equipos`.`NumeroSerie`
    , `equipos`.`Estado`
    , `equipos`.`Fecha_Registro`
    , `marcas`.`Marca`
    , `modelos`.`Modelo`,
    COUNT(IdFalla) Fallas 
FROM
    `proyecto2019_5`.`fallas_equipo`
    
    INNER JOIN `proyecto2019_5`.`equipos` 
        ON (`fallas_equipo`.`IdEquipo` = `equipos`.`IdEquipo`)
    INNER JOIN `proyecto2019_5`.`marcas` 
        ON (`equipos`.`IdMarca` = `marcas`.`IdMarca`)
    INNER JOIN `proyecto2019_5`.`modelos` 
        ON (`equipos`.`IdModelo` = `modelos`.`IdModelo`)
GROUP BY `equipos`.`IdEquipo`        
        ;
        ";
if ($conexion->query($sql2)==TRUE) {
    $resultado2=$conexion->query($sql2);
    
if ($resultado2->num_rows>0) {
    
$valor=" ";
$valor.="<br><form method=post>";

$valor.="<table class=blue-form3 cellpadding=8 width=100%>
<tr>

<th>Nombre</th>
<th>N° <br>Serie</th>
<th>Marca</th>
<th>Modelo</th>
<th>Estado</th>
<th >Fecha de <br>Registro</th>
<th>Fallas</th>

<th> Ver Fallas </th>
</tr>
";

    while ($fila=$resultado2->fetch_assoc()) {
        $valor.=" 
<tr>";
        $valor.="
<td>$fila[NombreEquipo]</td>
<td>$fila[NumeroSerie]</td>
<td >$fila[Marca]</td>
<td >$fila[Modelo]</td>
<td >$fila[Estado]</td>
<td >$fila[Fecha_Registro]</td>
<td>$fila[Fallas]</td>
<td><a href='?pag=fallasporequipo.php&idcat=$fila[IdEquipo]'>Ver</a>


    </td>
</tr>

    ";
  
    	
    } $valor.="</table></form>" ;  echo "$valor";}}
    ?>
    <?php 

    } ?>