<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($_SESSION["esadministrador"]))) {
header("Location:principal_docente.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>



<script type="text/javascript">
function xmlhttp(){
        var xmlhttp;
        try{xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");}
        catch(e){
            try{xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");}
            catch(e){
                try{xmlhttp = new XMLHttpRequest();}
                catch(e){
                    xmlhttp = false;
                }
            }
        }
        if (!xmlhttp)
                return null;
            else
                return xmlhttp;
    }

function buscar(){
        var query = document.getElementById('busqueda').value;
        var A = document.getElementById('resultados');
        var ajax = xmlhttp();
 
        ajax.onreadystatechange=function(){
                if(ajax.readyState==4 && ajax.status==200){
                        
                        A.innerHTML = ajax.responseText;
                    }
            }
ajax.open("GET","busqueda_equipos.php?valor="+query);

        ajax.send(null);
        return false;
    }
</script>

<style type="text/css">
    
    .text{
    /*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
width: 40%;
border-radius: 15px;
height: 25px;
border:1px black solid;
font-size: 15px;
 font-family: Comic Sans MS,Arial,Verdana;
        }
.selec{
 width: 30%;
border-radius: 15px;
height: 25px;
border:1px black solid;
font-size: 15px;
 font-family: Comic Sans MS,Arial,Verdana;
        }
        .text:focus{
    border:3px solid green;
}
</style>
	<?php
if (isset($_POST["Ndisponible"]) and isset($_POST['equipos'])) {
    
   
        $ids=$_POST["equipos"];
include_once("conexion.php");
foreach ($ids as $id) {
$update="update Equipos set Estado='No Disponible' where IdEquipo='$id'";
$conexion->query($update);
}
  echo "<script>alert('Modificación de datos exitoso');</script>";


    
    }
elseif (isset($_POST["Sdisponible"]) and isset($_POST['equipos']) )  {
    
      $ids=$_POST["equipos"];
include_once("conexion.php");
foreach ($ids as $id) {
$update="update Equipos set Estado='Disponible' where IdEquipo='$id'";
$conexion->query($update);
}
  echo "<script>alert('Modificación de datos exitoso');</script>";



    
}



 ?>
<legend>Buscar Equipos</legend>
Buscar Por:<select name=filtro required="required" class="selec" id="filtro">
    <option value=Marca>Marca</option>
    <option value=NombreEquipo>Nombre</option>
    <option value=NumeroSerie>Número de serie</option>
</select>
<input type=text name=dato required=required class=text id=busqueda onKeyUp=buscar(); placeholder="Escribe aquí..." autofocus="">

<div id=resultados class=nocss>
</div>




