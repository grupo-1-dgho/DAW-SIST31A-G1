<?php 
include 'Conectar.php';
class Prestamos{
	protected $C;
	public function Prestamos(){
		//inicializamos lo necesario
		$this->C=new Conexion();
	}
public function Mostrar(){
	$sql="SELECT
    `equipos`.`IdEquipo`
    , `equipos`.`NombreEquipo`
    , `equipos`.`NumeroSerie`
    , `equipos`.`Descripcion`
    , `equipos`.`Estado`
    , `marcas`.`Marca`
    , `modelos`.`Modelo`
    , `carreras`.`Carrera`
FROM
    `proyecto2019_5`.`equipos`
    INNER JOIN `proyecto2019_5`.`marcas` 
        ON (`equipos`.`IdMarca` = `marcas`.`IdMarca`)
    INNER JOIN `proyecto2019_5`.`modelos` 
        ON (`equipos`.`IdModelo` = `modelos`.`IdModelo`)
    INNER JOIN `proyecto2019_5`.`carreras` 
        ON (`equipos`.`IdCarrera` = `carreras`.`IdCarrera`)     
      where Estado='Disponible'  ;
        ";
       
        $resultado=$this->C->consultar($sql);
        if ($resultado->num_rows>0) {
        	
        	$mostrar='';
        	$mostrar.="<form method=post><table class=blue-form3>
<th>Nombre <br>del Equipo</th>
<th>N° <br>Serie</th>
<th>Marca</th>
<th>Modelo</th>
<th>Descripcion</th>
<th>Ver <br>Fallas</th>
<th >Prestar</th>";

while ($filas=$resultado->fetch_assoc()) {
	$mostrar.="<tr>";
$mostrar.="
<td>$filas[NombreEquipo]</td>
<td>$filas[NumeroSerie]</td>
<td>$filas[Marca]</td>
<td>$filas[Modelo]</td>
<td>$filas[Descripcion]</td>
<td><a href='?pag=fallasporequipo_docente.php&idcat=$filas[IdEquipo]'><H4>VER</H4></a></td>
<td><a href='?pag=realizar_prestamo.php&idcat=$filas[IdEquipo]'><H4>PRESTAR</H4></a></td>
";

	$mostrar.="</tr>";
}

        	$mostrar.="</table></form>";

        	return $mostrar;
        }
}	

public function mostrarfallas($id){
		$sql1="select * from fallas_equipo where IdEquipo='$id';";
		$sql2="   SELECT
    `equipos`.`NombreEquipo`
    , `marcas`.`Marca`
    , `modelos`.`Modelo`
    , `equipos`.`NumeroSerie`
FROM
    `proyecto2019_5`.`equipos`
    INNER JOIN `proyecto2019_5`.`marcas` 
        ON (`equipos`.`IdMarca` = `marcas`.`IdMarca`)
    INNER JOIN `proyecto2019_5`.`modelos` 
        ON (`equipos`.`IdModelo` = `modelos`.`IdModelo`)
   
        WHERE equipos.IdEquipo='$id';";
		$result=$this->C->Consultar($sql1);
		$resultado2=$this->C->Consultar($sql2);
		if ($result->num_rows>0) {
   $row=$resultado2->fetch_assoc();
$valor="<form method=post>
<h3><table class=blue-form3 cellpadding=8 width=100%><tr><td>
El equipo $row[NombreEquipo] $row[Marca] $row[Modelo], con número de serie $row[NumeroSerie] contiene las siguientes fallas:
</td></tr></table></h3>

";
$valor.="<table class=blue-form3 cellpadding=8 width=100%>
<tr>
<th >Fecha de reporte</th>
<th >Descripción</th>
</tr>
";
while ($fila=$result->fetch_assoc()) {
        $valor.=" 
<tr>";
         $valor.="

<td>$fila[Fechareporte]</td>
<td >$fila[Descripcion]</td>

</tr>
 ";
    } 
    $valor.="</table>
</form>" ;  
    return $valor;
}else{
	$valor="<h1>NO HAY FALLAS EN ESTE EQUIPO</H1>";
return $valor;
}
}

	public function prestar($id){
		$sql="select * from aulas";
		$aulas=$this->C->Consultar($sql);
		$respuesta="<form method=post>
 	<table class=blue-form2>
 		<tr>
 	<th colspan=2>Realizar Prestamo</th>
</tr>
<tr>
	<td>Aula del prestamo</td>
			<td><select name=IdAula class=select>";
	while ($row=$aulas->fetch_assoc()) {
		$respuesta.= "
<option value=$row[IdAula]>$row[Aula]</option>";
}
$respuesta.= "</select></td></tr><tr><td>
Fecha del prestamo:</td><td><input type=date name=fecha class=texto required=required></td></tr>
<tr><td>Hora Inicio:</td><td><input type=time name=inicio class=texto min='06:00' max='18:00' step=600 required=required></td></tr>
<tr><td>Hora Final:</td><td><input type=time name=fin class=texto min='06:00' max='18:00' step=600 required=required></td></tr>
<tr><th colspan=2><input type=submit class=boton name=ok value=Guardar></th></tr>
";

$respuesta.="</table></form>";
return $respuesta;
	}
	public function prestamoexistente($id,$fecha,$total){
		$sql="SELECT
    `usuarios`.`Nombre`
    , `usuarios`.`Apellido`
    , `prestamos`.`IdEquipo`
    , `prestamos`.`IdUsuario`
    , `descripcionprestamo`.`EstadoPrestamo`
    , `aulas`.`Aula`
    , `horarios_prestamo`.`Fecha`
    , `horarios_prestamo`.`HoraTotal`
FROM
    `proyecto2019_5`.`descripcionprestamo`
    INNER JOIN `proyecto2019_5`.`prestamos` 
        ON (`descripcionprestamo`.`IdPrestamo` = `prestamos`.`IdPrestamo`)
    INNER JOIN `proyecto2019_5`.`usuarios` 
        ON (`prestamos`.`IdUsuario` = `usuarios`.`IdUsuario`)
    INNER JOIN `proyecto2019_5`.`aulas` 
        ON (`prestamos`.`IdAula` = `aulas`.`IdAula`)
    INNER JOIN `proyecto2019_5`.`horarios_prestamo` 
        ON (`descripcionprestamo`.`IdHorario` = `horarios_prestamo`.`IdHorario`)
where IdEquipo='$id' and EstadoPrestamo='Activo' and Fecha='$fecha' and HoraTotal='$total'
        ;";
        $consultar=$this->C->Consultar($sql);
if ($consultar->num_rows>0) {
	
return TRUE;
}else{
	return FALSE;
}
}
public function mensajeprestamo($id,$total){
$sql="SELECT
    `usuarios`.`Nombre`
    , `usuarios`.`Apellido`
    , `prestamos`.`IdEquipo`
    , `prestamos`.`IdUsuario`
    , `descripcionprestamo`.`EstadoPrestamo`
    , `aulas`.`Aula`
    , `horarios_prestamo`.`Fecha`
    , `horarios_prestamo`.`HoraTotal`
FROM
    `proyecto2019_5`.`descripcionprestamo`
    INNER JOIN `proyecto2019_5`.`prestamos` 
        ON (`descripcionprestamo`.`IdPrestamo` = `prestamos`.`IdPrestamo`)
    INNER JOIN `proyecto2019_5`.`usuarios` 
        ON (`prestamos`.`IdUsuario` = `usuarios`.`IdUsuario`)
    INNER JOIN `proyecto2019_5`.`aulas` 
        ON (`prestamos`.`IdAula` = `aulas`.`IdAula`)
    INNER JOIN `proyecto2019_5`.`horarios_prestamo` 
        ON (`descripcionprestamo`.`IdHorario` = `horarios_prestamo`.`IdHorario`)
where IdEquipo='$id'  and HoraTotal='$total'
        ;";
        $consultar=$this->C->Consultar($sql);
	$c=$consultar->fetch_assoc();

	$mensaje="<script>
titulo='Este equipo se encuentra actualmente prestado por:';
msg='$c[Nombre] $c[Apellido] en el aula $c[Aula]';
	aler2(titulo,msg);</script>
	";
	return $mensaje;
}
public function agregar($tabla,$campos,$valores){
$sql="INSERT INTO $tabla ($campos) Values ($valores)";
$resultado=$this->C->ejecutar($sql);
if ($resultado==TRUE) {
	return TRUE;
}else{
return FALSE;
}

}
}
 ?>

