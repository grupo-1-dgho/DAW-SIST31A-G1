<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($_SESSION["esadministrador"]))) {
header("Location:principal_docente.php");
}elseif (!(isset($usaindex))) {
    header("Location:index.php");
}
  
?>
<style type="text/css">
    .text{
    /*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
width: 40%;
border-radius: 15px;
height: 25px;
border:1px black solid;
font-size: 15px;
 font-family: Comic Sans MS,Arial,Verdana;
        }
.text:focus{
    border:3px solid green;
}

</style>




<script type="text/javascript">
function xmlhttp(){
        var xmlhttp;
        try{xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");}
        catch(e){
            try{xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");}
            catch(e){
                try{xmlhttp = new XMLHttpRequest();}
                catch(e){
                    xmlhttp = false;
                }
            }
        }
        if (!xmlhttp)
                return null;
            else
                return xmlhttp;
    }

function buscar(){
        var query = document.getElementById('busqueda').value;
        var A = document.getElementById('resultados');
        var B = document.getElementById('loading');
        var ajax = xmlhttp();
 
        ajax.onreadystatechange=function(){
                if(ajax.readyState==1){
                        B.innerHTML = "<img src='images/loading.gif' alg='Loading...'>";
                    }
                if(ajax.readyState==4 && ajax.status==200){
                        
                        A.innerHTML = ajax.responseText;
                        B.innerHTML = "";
                    }
            }
 ajax.open("GET","busqueda.php?valor="+encodeURIComponent(query),true);
        ajax.send(null);
        return false;
    }
</script>


	
<legend>Buscar usuarios</legend>
Carnet:
<input type=text name=dato required=required class=text id=busqueda onKeyUp=buscar(); autofocus="">
<div id=resultados class=nocss>
</div>

<?php
if (isset($_POST["btndesactivar"]) ) {
	
	if (!empty($_POST["usuarios"])) {
		$id=$_POST["usuarios"];
include_once("conexion.php");

$update="update Usuarios set Estado='Inactivo' where IdUsuario='$id'";
if ($conexion->query($update)==TRUE) {


}	echo "<script>alert('Modificación de datos exitoso');</script>";


	
	}else{
		
echo "Carnet:
<input type=text name=dato required=required class=texto id=busqueda onKeyUp=buscar(); autofocus>
<div id=resultados class=nocss>
</div>";
	}

}
elseif (isset($_POST["btnactivar"]) )  {
	
	if (!empty($_POST["usuarios"])) {
		$id=$_POST["usuarios"];
include_once("conexion.php");

$update="update Usuarios set Estado='Activo' where IdUsuario='$id'";
if ($conexion->query($update)==TRUE) {
	
}echo "<script>alert('Modificación de datos exitoso');</script>";



	}else{
		echo "Carnet:
<input type=text name=dato required=required class=texto id=busqueda onKeyUp=buscar(); autofocus>
<div id=resultados class=nocss>
</div>";
	}

}



 ?>

</form>



