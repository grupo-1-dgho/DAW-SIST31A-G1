
<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($_SESSION["esadministrador"]))) {
header("Location:principal_docente.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>

	<?php
include('conexion.php');
?>
<?php
if (isset($_POST['ok'])) {
	$aula=ucfirst($_POST['aula']);

	$inser= "INSERT INTO Aulas (Aula) VALUES ('$aula')";

	if ($conexion->query($inser)==TRUE) {
 	
						echo "<h1>Registro Insertado</h1>";
						 }else{
echo "<h1>Registro No Insertado</h1>";
}

}if (isset($_POST["eliminar"]) and isset($_POST['id']) ) {
	$ids=$_POST['id'];
foreach ($ids as $id) {
$delete= "Delete from Aulas where IdAula='$id'";
$conexion->query($delete);
}

		}

?>
	<form method='post'>
		<table class="blue-form">
	<tr>
	<th colspan="2">Agregar Aulas </th>
		</tr>
		<tr>
			<td><input type="text" name="aula" placeholder="Ingrese un aula..." required='' autofocus class="texto"></td>
			<td><input type="submit" name="ok" class=boton value="Aceptar"></td>
		</tr>	
		</table>
	</form>	
	<br>
	<form method="post"><table class="blue-form2">
		<tr>
			<th colspan="2">Aulas</th>
		</tr>
		
		<?php  
$aulas="Select * from Aulas";
if ($conexion->query($aulas)==TRUE) {
	$resultado2=$conexion->query($aulas);
	while ($row=$resultado2->fetch_assoc()) {
		echo "<tr>
			<td>
			<input type=checkbox name=id[]  value=$row[IdAula]>$row[Aula]	
			</td>
	<td><a href='?pag=modificar_aulas.php&idcat=$row[IdAula]'><img src=img/edit.jpg width=25 height=25 title='Modificar Registro'></a>
	</td>
		</tr>";
	}
}
		?>
		<tr>
			<th colspan="2"><input type="submit" name="eliminar" class="boton" value="Eliminar"></th>
		</tr>
	</table></form>









	