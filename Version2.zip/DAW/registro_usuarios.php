<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($_SESSION["esadministrador"]))) {
header("Location:principal_docente.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>
<?php 
@session_start(); 
include 'conexion.php';

$consulta_departamentos="Select * from Carreras";
$resultado2=$conexion->query($consulta_departamentos);

$n2=$resultado2->num_rows;

?>


<script type="text/javascript">   
	function checkForm(form){         
			      
			 	     
if(form.contra.value.length < 8) { 
msg="Error: La clave debe tener un minimo de 8 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.contra.focus();
return false;       
}  

if(form.contra.value == form.nombre.value) { 
msg="Error: La clave debe ser diferente al nombre !";   
tit="Error!!!";  
aler(tit,msg);          
form.contra.focus();         
return false; 
      }     
re = /[0-9]/;       
if(!re.test(form.contra.value)) {         
aler("Error: la clave debe tener almenos un digito (0-9)!");         
form.contra.focus();         
return false;       } 
re = /[a-z]/;       
if(!re.test(form.contra.value)) {  
msg="Error: La clave debe tener al menos una letra minuscula (a-z)!";   
tit="Error!!!";  aler(tit,msg);  
form.contra.focus();          
return false;       }       
re = /[A-Z]/;       
if (!re.test(form.contra.value)) {  
msg="Error: La clave debe tener al menos una letra mayuscula (A-Z)!";   
tit="Error!!!";  
aler(tit,msg);           
form.contra.focus();          
return false;       
}  
re = /[0-9]/;
if (!re.test(form.carnet.value)) {  
msg="Error: El carnet solo acepta numeros!";   
tit="Error!!!";  
aler(tit,msg);           
form.carnet.focus();          
return false;       
}
if(form.carnet.value.length < 6 || form.carnet.value.length > 6) { 
msg="Error: El carnet tiene que tener 6 números!";   
tit="Error!!!";  
aler(tit,msg);
form.carnet.focus();
return false;       
} 
if(form.nombre.value.length < 3) { 
msg="Error: El nombre tiene que tener al menos 3 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.nombre.focus();
return false;       
}  
if(form.apellido.value.length < 3) { 
msg="Error: El apellido tiene que tener al menos 3 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.apellido.focus();
return false;       
}  

}
     
       </script> 

	<article class="article2">
<?php
if (isset($_POST['registrar'])) {
	$nombre=ucwords($_POST['nombre']);
	$apellido=ucwords($_POST['apellido']);
	$carnet=$_POST['carnet'];
	$correo=$_POST['correo'];
	$contraseña=$_POST['contra'];
	$Cod_Departamento=$_POST['departamento'];

$consultar="select * from Usuarios where Contra='$contraseña'";
	$r1=$conexion->query($consultar);
	if ($r1->num_rows>0) {
		echo "Error: esa contraseña ya se encuentra en uso!";   
}else{
	
	
	$sql="INSERT INTO Usuarios (Carnet,Nombre,Apellido,E_mail,IdCarrera,Contra)
						 VALUES ('$carnet','$nombre','$apellido','$correo','$Cod_Departamento','$contraseña')";
 if ($conexion->query($sql)==TRUE) {
 	
						echo "<h1>Registro guardado</h1>";
						 }else{
echo "<h1>No se guardo el registro</h1>

";
						 } 
}
}

?>
<?php
include 'conexion.php';
$carreras="select * from carreras";
$r_m=$conexion->query($carreras);
if ($r_m->num_rows==0) {
	echo "<h1>DEBEN EXIXTIR CARRERAS PARA INGRESAR USUARIOS</h1>";
}else{
	echo "<form method=post name=registro onsubmit='return checkForm(this);' >
<table cellpadding=8 class=blue-form>
	
	<tr>
		<td>Nombre:</td><td width=600><input type=text name=nombre class=texto required=required id=nombre title='Debe ingresar almenos 3 caracteres' autofocus></td>
	</tr>
	<tr>
		<td>Apellido:</td><td width=600><input type=text name=apellido class=texto required=required id=apellido title='Debe ingresar almenos 3 caracteres'></td>
	</tr>
	<tr>
		<td>Carnet:</td><td><input type=text  name=carnet class=texto2  required=required id=carnet placeholder=000000></td>
	</tr>
	<tr>
		<td>Correo:</td><td><input type=email name=correo class=texto required=required id=correo></td>
	</tr>
	
	
	<tr>
		<td>Carrera:</td><td>
			"; 
if ($n2>0) {
	
	echo "<select name=departamento class=select>";
	while ($row2=$resultado2->fetch_assoc()) {
		echo "
<option value=".$row2["IdCarrera"]." title=".$row2["IdCarrera"].">".$row2["Carrera"]."</option>";
}
echo "</select>";
}
			echo "

		</td>
	</tr>
	<tr>
		<td>Contraseña:</td><td><input type=password name=contra class=texto2 required=required id=contraseña  title='Debe contener 8 o más caracteres '></td>
	</tr>
	<tr><td colspan=2><input type=submit name=registrar class=boton value=Registrar></td></tr>
</table>


</form>";}?>

</article>


