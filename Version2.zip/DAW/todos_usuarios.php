<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($_SESSION["esadministrador"]))) {
header("Location:principal_docente.php");
}
  
?>
<?php

 include_once("conexion.php");
$sql="SELECT
    `usuarios`.`IdUsuario`
    , `usuarios`.`Carnet`
    , `usuarios`.`Nombre`
    , `usuarios`.`Apellido`
    , `usuarios`.`E_mail`
    , `usuarios`.`Direccion`
    , `usuarios`.`Fecha_Nacimiento`
    , `usuarios`.`Fotografia`
    , `usuarios`.`Tipo`
    , `usuarios`.`Contra`
    , `carreras`.`Carrera`
    , `usuarios`.`Estado`
FROM
    `proyecto2019_5`.`usuarios`
    INNER JOIN `proyecto2019_5`.`carreras` 
        ON (`usuarios`.`IdCarrera` = `carreras`.`IdCarrera`)
        ;";
if ($conexion->query($sql)==TRUE) {
    $resultado=$conexion->query($sql);
    
if ($resultado->num_rows>0) {
$r=' ';
$r.="<br><form method=post><input type=submit name=btndesactivar value=Desactivar class=boton2>
<input type=submit name=btnactivar value=Activar class=boton2><br><br>";
    while ($fila=$resultado->fetch_assoc()) {
        $r.="<table class=blue-form cellpadding= 10>
<tr>
<th colspan=2>
<input type=radio name=usuarios class=radio value='$fila[IdUsuario]' required=required>Usuario</th></tr>";
        $r.="

<tr>
<td rowspan=10>
<img src=$fila[Fotografia] width=200 height=250></td>
<td>Carnet: $fila[Carnet]</td>
</tr>
<tr>
<td>Nombre: $fila[Nombre]</td>
</tr>
<tr>
<td>Apellido: $fila[Apellido]</td>
</tr>
<tr>
<td>E-mail: $fila[E_mail]</td>
</tr>
<tr>
<td width='20%'>Dirección: $fila[Direccion]</td>
</tr>
<tr>
<td >Fecha de Nacimiento: $fila[Fecha_Nacimiento]</td>
</tr>
<tr>
<td >Carrera: $fila[Carrera]</td>
</tr>
<tr>
<td >Tipo: $fila[Tipo]</td>
</tr>
<tr>
<td >Contraseña: $fila[Contra]</td>
</tr>
<tr>
<td >Estado: $fila[Estado]</td>
</tr>
    ";
     

    }
    $r.="</table></form>";
    echo $r;}}

 ?>
