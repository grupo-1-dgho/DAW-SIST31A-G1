<?php
@session_start();  
?>
<!DOCTYPE html>
<html>
<head>
	<title>Sistema ITCA</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<style type="text/css">

body{
	font-family: Comic Sans MS,Arial,Verdana;

}

.texto:focus{
	border:3px solid green;
}
.texto{
width: 100%;
border-radius: 15px;
height: 25px;
font-size: 15px;
				}
.article2{
width: 40%;
padding: 10px;
box-sizing: border-box;
background-color: rgba(0,0,0,0.5);
color: white;
font-size: 25px;
border: 3px solid #3E83C9;
}

.boton{
	/*dependiento del texto del boton pueden cambiarle el ancho en el width*/
	border-radius: 20px;
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 160px;
	font-size: 18px;
	background-color:green;
	color: white;
}




	</style>


</head>
<body bgcolor="#A80A0D">


<?php
include_once'conexion.php';  
$sql="Select * from usuarios";
$resultado=$conexion->query($sql);
if ($resultado->num_rows>0) {
	


?>

<?php 
@session_start();
function SQLsegura($strVar){  
 	$banned = array("select", "drop","|","'", ";", "--", "insert","delete", "xp_");     
   $vowels = $banned; 
    $no = str_replace($vowels, "", $strVar);  
    $final = str_replace( "'","",$no);
      return $final; }
      //End Function 
$Usuario='root';
$Contraseña='itca2019';
$Servidor='localhost';
$Basededatos='proyecto2019_5';
if (isset($_POST["entrar"])) {
	$correo=SQLsegura($_POST["correo"]);
	$contraseña=SQLsegura($_POST["contraseña"]);
	$conexion= new mysqli($Servidor,$Usuario,$Contraseña,$Basededatos);
	
	
$sql="SELECT Tipo, Estado FROM Usuarios
WHERE E_mail='$correo' AND Contra='$contraseña'";

	$resultado=$conexion->query($sql);
	
	$cuantos=$resultado->num_rows;


	if ($cuantos==0) {
		echo "<script>alert('Correo o contraseña incorrecta');location.href ='login.php';</script>";
	}else{

$fila=$resultado->fetch_assoc();
	$cargo=$fila["Tipo"];
	$_SESSION["usaindex"]='Si';
	$sql2="SELECT
    `usuarios`.`IdUsuario`
    , `usuarios`.`Carnet`
    , `usuarios`.`Nombre`
    , `usuarios`.`Apellido`
    , `usuarios`.`E_mail`
    , `usuarios`.`Direccion`
    , `usuarios`.`Fecha_Nacimiento`
    , `usuarios`.`Fotografia`
    , `usuarios`.`Tipo`
    , `usuarios`.`IdCarrera`
    , `usuarios`.`Contra`
    , `usuarios`.`Estado`
    , `carreras`.`Carrera`
FROM
    `proyecto2019_5`.`usuarios`
    INNER JOIN `proyecto2019_5`.`carreras` 
        ON (`usuarios`.`IdCarrera` = `carreras`.`IdCarrera`) 
        where contra='$contraseña';
        ";
	$rs=$conexion->query($sql2);
	$todo=$rs->fetch_assoc();
	foreach ($todo as $key => $value) {
		$_SESSION["usuario2"][$key]=$value;
	}


	
	if($fila["Estado"]=="Activo"){
		$_SESSION["usuario"]["correo"]=$correo;
		$_SESSION["usuario"]["contraseña"]=$contraseña;
		$_SESSION["usuario"]["cargo"]=$cargo;
		if ($cargo=="Administrador") {
		$_SESSION["esadministrador"]='Si';
		header("Location: index.php");
		}else{
			
			header("Location: index.php");
		}
	
}else{
	
	echo "<script>alert('Actualmente su usuario se encuentra desactivado');</script>";
}
	
	}}

	elseif  (isset($_POST["cerrar"])) {
unset($_SESSION["usuario"]);
unset($_SESSION["usuario2"]);
unset($_SESSION["usaindex"]);
unset($_SESSION["esadministrador"]);

	
}




 ?>
<center><article class=article2>
<form method=post>
	<center><table cellspacing=20 >
		<tr><th colspan=2>INGRESE SUS DATOS</th></tr>
		<tr><td colspan=2><img src=img/login.jpg></td></tr>
		<tr><td>Correo:</td><td><input type=email name=correo required=required class=texto autofocus></td></tr>
		<tr><td>Contraseña:</td><td><input type=password name=contraseña required=required class=texto></td></tr>
		<tr><th colspan=2><input type=submit name=entrar class=boton value='Iniciar sesión'></th></tr>
	</table>
</center>
</form></article></center>

</body>
</html>
<?php  
}else{
header("Location:registro.php")	;
}	
?>


