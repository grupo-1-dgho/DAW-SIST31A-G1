<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($_SESSION["esadministrador"]))) {
header("Location:principal_docente.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>

 <?php
 include_once("conexion.php");
if (isset($_POST["ok"])) {
	$id=$_POST["idcarrera"];
	$carrera=ucfirst($_POST["carrera"]);
	$update="UPDATE Carreras set Carrera='$carrera' where IdCarrera='$id'";
	$conexion->query($update);
	echo "<script> 
        location.href='index.php?pag=agregar_carreras.php';
    </script>";
}
   ?>
   <?php 

$id=$_GET["idcat"];
$consultar="select * from Carreras where IdCarrera='$id'";
$r=$conexion->query($consultar);
$fila=$r->fetch_assoc();
 ?>
 <form method="post">
 	<table class=blue-form2>
 		<tr>
 	<th>Modificar Carrera</th>
</tr>
<tr>
	<td><input name="idcarrera" type="hidden" value="<?php echo $fila["IdCarrera"]?>"> 
		<input type="text" name="carrera" class="texto" value="<?php echo $fila["Carrera"];?>" required=required></td>
</tr>
<tr><th><input type="submit" name="ok" class="boton" value="Actualizar"></th></tr>
 	</table>
 </form>
 