<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}
  
?>


<?php 
include_once'conexion.php';
$filtro=$_GET["valor"];
if ($filtro!=' ') {
    
  $sql="SELECT
    `equipos`.`IdEquipo`
    , `equipos`.`NombreEquipo`
    , `equipos`.`NumeroSerie`
    , `equipos`.`Descripcion`
    , `equipos`.`Estado`
    , `marcas`.`Marca`
    , `modelos`.`Modelo`
    , `carreras`.`Carrera`
FROM
    `proyecto2019_5`.`equipos`
    INNER JOIN `proyecto2019_5`.`marcas` 
        ON (`equipos`.`IdMarca` = `marcas`.`IdMarca`)
    INNER JOIN `proyecto2019_5`.`modelos` 
        ON (`equipos`.`IdModelo` = `modelos`.`IdModelo`)
    INNER JOIN `proyecto2019_5`.`carreras` 
        ON (`equipos`.`IdCarrera` = `carreras`.`IdCarrera`)     
      where Estado='Disponible' and  NombreEquipo like '$filtro%';
        ";
       
      $resultado= $conexion->query($sql);
        if ($resultado->num_rows>0) {
            
            $mostrar='';
            $mostrar.="<form method=post><table class=blue-form3>
<th>Nombre <br>del Equipo</th>
<th>N° <br>Serie</th>
<th>Marca</th>
<th>Modelo</th>
<th>Descripcion</th>
<th>Ver <br>Fallas</th>
<th >Prestar</th>";

while ($filas=$resultado->fetch_assoc()) {
    $mostrar.="<tr>";
$mostrar.="
<td>$filas[NombreEquipo]</td>
<td>$filas[NumeroSerie]</td>
<td>$filas[Marca]</td>
<td>$filas[Modelo]</td>
<td>$filas[Descripcion]</td>
<td><a href='?pag=fallasporequipo_docente.php&idcat=$filas[IdEquipo]'><H4>VER</H4></a></td>
<td><a href='?pag=realizar_prestamo.php&idcat=$filas[IdEquipo]'><H4>PRESTAR</H4></a></td>
";

    $mostrar.="</tr>";
}

            $mostrar.="</table></form>";

            echo $mostrar;
        }else{
require_once 'Clase_Prestamos.php';
$objeto= new Prestamos();
$r=$objeto->Mostrar();
echo "<H1>NO HAY RESULTADOS CON LA BUSQUEDA</H1><BR>$r";
}
}
else{
require_once 'Clase_Prestamos.php';
$objeto= new Prestamos();
$r=$objeto->Mostrar();
echo "$r";
}
 ?>




