<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>
<a href="?pag=buscar_equipo.php">Volver</a><br>
<?php  
include_once 'Clase_Prestamos.php';
$falla=new Prestamos();

$id=$_GET["idcat"];
$resultado=$falla->mostrarfallas($id);
echo "$resultado";


?>

