<?php
@session_start(); 
if ($_SESSION["usuario2"]["Tipo"]!='Administrador') {
header("Location:login.php");
}else{
 ?>
<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>
<?php
$id=$_GET["idcat"];
$consulta="select * from Equipos where IdEquipo='$id'";
include_once("conexion.php");
$r=$conexion->query($consulta);
$rows=$r->fetch_assoc();?>
<?php
	include_once 'conexion.php';

if (isset($_POST['ok'])) {
	$marca=$_POST['marca'];
	$modelo=$_POST['modelo'];
	$tipo=$_POST['tipo'];
	$des=$_POST['descripcion'];
	$carrera=$_POST['carrera'];
	$nombre=ucfirst($_POST['nombre']);
	$numero=$_POST['numero'];
	$consultar="select * from equipos where NombreEquipo='$nombre'  AND IdEquipo!= '$id'";
	$r1=$conexion->query($consultar);
	$consultar2="select * from equipos where NumeroSerie='$numero' AND IdEquipo!= '$id'";
	$r2=$conexion->query($consultar2);
	if ($r1->num_rows>0) {
		echo "Error: El nombre de ese equipo ya está en uso!";   

	}elseif ($r2->num_rows>0) {
		echo "Error: El número de serie del equipo ya está en uso!";   

	}else{
	$update= "UPDATE Equipos SET   Idmarca='$marca',IdModelo='$modelo',IdTipo='$tipo',Descripcion='$des',IdCarrera='$carrera',NombreEquipo='$nombre',NumeroSerie='$numero' where IdEquipo='$id'";
if ($conexion->query($update)==TRUE) {
 	
						echo "<script>alert('modificación exitosa'); 
        location.href='index.php?pag=mantenimiento_equipos.php';
    </script>";
						 }else{
echo "<H1>El Registro No se Modifico </H1>";
}
}}
?>

<?php
echo "
		<form method=post><table class=blue-form><tr>
			<th colspan=2>Modificar equipo</th>
		</tr>
		<tr>
			<td>Marca</td>
			<td><select name=marca class=select id=marca onchange=marcas(); autofocus>";
			$consulta_marca="Select * from marcas";
$resultado_marcas=$conexion->query($consulta_marca);
	while ($row3=$resultado_marcas->fetch_assoc()) {
if($row3["IdMarca"]==$rows["IdMarca"]){
		echo "
<option value=".$row3["IdMarca"]." selected=selected>".$row3["Marca"]."</option>";
}elseif($row3["IdMarca"]!=$rows["IdMarca"]){
		echo "
<option value=".$row3["IdMarca"].">".$row3["Marca"]."</option>";
}
}
echo "</select>";
echo "</td>
</tr>";

	echo "<tr id=resultado><td> Modelo</td>
			<td><select name=modelo class=select>";
$consulta_modelo="Select * from Modelos";
$resultado_modelo=$conexion->query($consulta_modelo);	
		while ($rowM=$resultado_modelo->fetch_assoc()) {
if($rowM["IdModelo"]==$rows["IdModelo"]){
		echo "
<option value=".$rowM["IdModelo"]." selected=selected>".$rowM["Modelo"]."</option>";
}
}
			
	
echo "</select>
</td>
</tr>
<tr>
	
			<td>Tipo</td>
<td>
<select name=tipo class=select>";
$sql3="select * from tiposequipo ";
	$resultado3=$conexion->query($sql3);
	while ($row3=$resultado3->fetch_assoc()) {
	if($row3["IdTipo"]==$rows["IdTipo"]){
		echo "
<option value=".$row3["IdTipo"]." selected=selected>".$row3["Tipo"]."</option>";
}elseif($row3["IdMarca"]!=$rows["IdMarca"]){
		echo "
<option value=".$row3["IdTipo"].">".$row3["Tipo"]."</option>";
}
}
 echo "</select>
</td></tr>
<tr>
<td>Nombre de equipo</td>
<td><input type=text name=nombre id=nombre required=required class=texto value=$rows[NombreEquipo]></td>
</tr>
<tr>
<td>Número de serie</td>
<td><input type=text name=numero id=numero required=required class=texto value=$rows[NumeroSerie]></td>
</tr>
<tr>

			<td>Descripcion</td>
		<td><textarea name=descripcion  title=Debe ingresar almenos 8 caracteres  class=textarea 
		>$rows[Descripcion]</textarea ></td>
</tr><tr>
<td>Carrera a la que pertenece</td>
<td><select name=carrera class=select>";
$sql2="select * from Carreras ";
	$resultado2=$conexion->query($sql2);
	while ($row2=$resultado2->fetch_assoc()) {
		if($row2["IdCarrera"]==$rows["IdCarrera"]){
		echo "
<option value=".$row2["IdCarrera"]." selected=selected>".$row2["Carrera"]."</option>";
}elseif($row3["IdCarrera"]!=$rows["IdCarrera"]){
		echo "
<option value=".$row2["IdCarrera"].">".$row2["Carrera"]."</option>";
}
}
echo "</select> </td></tr>
		<tr>
		<th colspan=2 align=center><input type=submit name=ok class=boton value=Aceptar></th>
		</tr>

		
</table></form>";
  ?>
  <script type="text/javascript">
function xmlhttp(){
        var xmlhttp;
        try{xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");}
        catch(e){
            try{xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");}
            catch(e){
                try{xmlhttp = new XMLHttpRequest();}
                catch(e){
                    xmlhttp = false;
                }
            }
        }
        if (!xmlhttp)
                return null;
            else
                return xmlhttp;
    }

function marcas(){
        var query = document.getElementById('marca').value;
        var A = document.getElementById('resultado');
        var ajax = xmlhttp();
  
        ajax.onreadystatechange=function(){
                
                if(ajax.readyState==4 && ajax.status==200){
                        
                        A.innerHTML = ajax.responseText;
                   
                   
                      
                    }
            }
 ajax.open("GET","ajaxEquipo.php?valor="+encodeURIComponent(query),true);
        ajax.send(null);
        return false;
    }

</script>
<?php
}
?>