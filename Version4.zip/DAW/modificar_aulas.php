<?php
@session_start(); 
if ($_SESSION["usuario2"]["Tipo"]!='Administrador') {
header("Location:login.php");
}else{
 ?>
<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>
<?php 
include_once("conexion.php");
$id=$_GET["idcat"];
$consultar="select * from Aulas where IdAula='$id'";
$r=$conexion->query($consultar);
$fila=$r->fetch_assoc();
 ?>
 <?php
if (isset($_POST["ok"])) {
	$id=$_POST["idaula"];
	$aula=$_POST["aula"];
	$update="UPDATE Aulas set Aula='$aula' where IdAula='$id'";
	$conexion->query($update);
	echo "<script> 
        location.href='index.php?pag=agregar_aulas.php';
    </script>";
}
   ?>
 <form method="post">
 	<table class=blue-form2>
 		<tr>
 	<th>Modificar Aula</th>
</tr>
<tr>
	<td><input name="idaula" type="hidden" value="<?php echo $fila["IdAula"]?>"> 
		<input type="text" name="aula" class="texto" value="<?php echo $fila["Aula"];?>" required=required></td>
</tr>
<tr><th><input type="submit" name="ok" class="boton" value="Actualizar"></th></tr>
 	</table>
 </form>
 <?php
}
?>