<?php
@session_start(); 
if ($_SESSION["usuario2"]["Tipo"]!='Administrador') {
header("Location:login.php");
}else{
 ?>
<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>

	
	<?php
	include_once 'conexion.php';

if (isset($_POST['ok'])) {
	if ( isset($_POST['modelo'])) {
		
	
	$marca=$_POST['marca'];
	$modelo=$_POST['modelo'];
	$tipo=$_POST['tipo'];
	$des=$_POST['descripcion'];
	$carrera=$_POST['carrera'];
	$nombre=ucfirst($_POST['nombre']);
	$numero=$_POST['numero'];
	$fecha=date("Y/m/d");
	$consultar="select * from equipos where NombreEquipo='$nombre'";
	$r1=$conexion->query($consultar);
	$consultar2="select * from equipos where NumeroSerie='$numero'";
	$r2=$conexion->query($consultar2);
	if ($r1->num_rows>0) {
		echo "Error: El nombre de ese equipo ya está en uso!";   

	}elseif ($r2->num_rows>0) {
		echo "Error: El número de serie del equipo ya está en uso!";   

	}else{
	$inser= "INSERT INTO Equipos (Idmarca,IdModelo,IdTipo,Descripcion,IdCarrera,NombreEquipo,NumeroSerie,Fecha_Registro) 
	VALUES ('$marca','$modelo','$tipo','$des','$carrera','$nombre','$numero','$fecha')";
if ($conexion->query($inser)==TRUE) {
 	
						echo "<H1>REGISTRO INSERTADO</H1>";
						 }else{
echo "<H1>EL REGISTRO NO SE GUARDO </H1>";
}
}}else{
	echo "Debe seleccionar un modelo";
}}
?>

<form method='post'>
		

<?php
include('conexion.php');


$consulta_marca="Select * from marcas";
$resultado_marcas=$conexion->query($consulta_marca);
$c3=$resultado_marcas->num_rows;

$consulta_modelo="Select * from modelos";
$resultado_m=$conexion->query($consulta_modelo);
$c4=$resultado_m->num_rows;

$consulta_carrera="Select * from Carreras";
$resultado_c=$conexion->query($consulta_carrera);
$c5=$resultado_c->num_rows;

$consulta_tipo="Select * from tiposequipo";
$resultado_t=$conexion->query($consulta_tipo);
$c6=$resultado_t->num_rows;

if ($c3==0 || $c4==0 || $c5==0 || $c6==0) {
	echo "<h1>Deben existir modelos, marcas, carreras y tipos de equipo para poder agregar</h1>";
}else{
	echo "
		<table class=blue-form><tr>
			<th colspan=2>Agregar equipos</th>
		</tr>
		<tr>
			<td>Marca</td>
			<td><select name=marca class=select id=marca onchange=marcas(); autofocus>
			<option value=0>--Seleccione Marca--</option>";
	while ($row3=$resultado_marcas->fetch_assoc()) {
		echo "
<option value=".$row3["IdMarca"].">".$row3["Marca"]."</option>";
}
echo "</select>";
echo "</td>
</tr>";

	echo "<tr id=resultado><td> Modelo</td>
			<td><select name=modelo class=select>";
	
echo "</select>
</td>
</tr>
<tr>
	
			<td>Tipo</td>
<td>
<select name=tipo class=select>";
$sql3="select * from tiposequipo ";
	$resultado3=$conexion->query($sql3);
	while ($row3=$resultado3->fetch_assoc()) {
		echo "
<option value=".$row3["IdTipo"].">".$row3["Tipo"]."</option>";
}
 echo "</select>
</td></tr>
<tr>
<td>Nombre de equipo</td>
<td><input type=text name=nombre id=nombre required=required class=texto placeholder='Ej: Computadora1'></td>
</tr>
<tr>
<td>Número de serie</td>
<td><input type=text name=numero id=numero required=required class=texto></td>
</tr>
<tr>

			<td>Descripcion</td>
		<td><textarea name=descripcion  title=Debe ingresar almenos 8 caracteres  class=textarea ></textarea></td>
</tr><tr>
<td>Carrera a la que pertenece</td>
<td><select name=carrera class=select>";
$sql2="select * from Carreras ";
	$resultado2=$conexion->query($sql2);
	while ($row2=$resultado2->fetch_assoc()) {
		echo "
<option value=".$row2["IdCarrera"].">".$row2["Carrera"]."</option>";
}
echo "</select> </td></tr>
		<tr>
		<th colspan=2 align=center><input type=submit name=ok class=boton value=Aceptar></th>
		</tr>

		
</table>
"
;
}
?>	
<script type="text/javascript">
function xmlhttp(){
        var xmlhttp;
        try{xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");}
        catch(e){
            try{xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");}
            catch(e){
                try{xmlhttp = new XMLHttpRequest();}
                catch(e){
                    xmlhttp = false;
                }
            }
        }
        if (!xmlhttp)
                return null;
            else
                return xmlhttp;
    }

function marcas(){
        var query = document.getElementById('marca').value;
        var A = document.getElementById('resultado');
        var ajax = xmlhttp();
  
        ajax.onreadystatechange=function(){
                
                if(ajax.readyState==4 && ajax.status==200){
                        
                        A.innerHTML = ajax.responseText;
                   
                   
                      
                    }
            }
 ajax.open("GET","ajaxEquipo.php?valor="+encodeURIComponent(query),true);
        ajax.send(null);
        return false;
    }

</script>
	

</form>

<?php
}
?>