<?php
@session_start();

if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  $secion=$_SESSION["usuario2"];
?>


<script type="text/javascript">
function xmlhttp(){
        var xmlhttp;
        try{xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");}
        catch(e){
            try{xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");}
            catch(e){
                try{xmlhttp = new XMLHttpRequest();}
                catch(e){
                    xmlhttp = false;
                }
            }
        }
        if (!xmlhttp)
                return null;
            else
                return xmlhttp;
    }

function horas(){
        var query = document.getElementById('inicio').value;
        var A = document.getElementById('resultado');
        var ajax = xmlhttp();
  
        ajax.onreadystatechange=function(){          
                if(ajax.readyState==4 && ajax.status==200){
                   A.innerHTML = ajax.responseText;                 
                    }
            }
 ajax.open("GET","ajaxHora.php?valor="+encodeURIComponent(query),true);
        ajax.send(null);
        return false;
    }

</script>
 <?php
 include_once'Clase_Prestamos.php';
 include_once'Conectar.php';
 $objeto=new Prestamos();
 $c=new Conexion();
$id=$_GET["idcat"];
$idcarrera=strtolower($_SESSION["usuario2"]["Carrera"]);
$carreras=$objeto->carrera($id,$idcarrera);
if ($carreras==TRUE) {
	echo "<script>alert('No puede prestar equipos de Patrimonio');location.href='index.php?pag=buscar_equipo.php';</script>";

}else{
	
if (isset($_POST["ok"]) and isset($_POST["fin"])) {
	$Datetime = 'America/El_Salvador';
date_default_timezone_set($Datetime);
$FechaSistema=date("Y-m-d");
$horactual=date("G:i");
$hora12=date("h:i");
//para insertar a la tabla prestamo
$idusuario=$_SESSION["usuario2"]["IdUsuario"];
$idaula=$_POST["IdAula"];
$inicio=$_POST["inicio"];
$fin=$_POST["fin"];
$fecha=$_POST["fecha"];
if (($horactual>='12:00' or $hora12>='12:00') and $FechaSistema==$fecha  ) {
	$total=$inicio."Pm-".$fin."Pm";
}elseif ($inicio>='12:00' ) {
	$total=$inicio."Pm-".$fin."Pm";
} elseif($fin>='12:00') {
$total=$inicio."Am-".$fin."Pm";
}else{
	$total=$inicio."Am-".$fin."Am";
}

$tabla1="Prestamos";
$campos1="IdEquipo,IdUsuario,IdAula,Fecha,HoraInicio,HoraFin,HoraTotal";
$valores1="'$id','$idusuario','$idaula','$fecha','$inicio','$fin','$total'";
if ($fecha<$FechaSistema) {
	echo "Debe ingresar una fecha igual o mayor a la actual";

}else{
if ($fin<=$inicio) {
	echo "Ingrese una hora final mayor a la hora inicial";
}else{
	if (($inicio<$horactual or $inicio<$hora12) and $fecha==$FechaSistema) {
		echo "Ingrese una hora mayor o igual a la actual";
	}
else{
        $dia=$objeto->findesemana($fecha);
        if ($dia!=FALSE) {
            echo "$dia";
        }else{

//para verificar si el prestamo ya existe
$resultado=$objeto->prestamoexistente($id,$fecha,$inicio,$fin);
if ($resultado!=FALSE) {
	
	echo $resultado;
	
}else{	
$resultado2=$objeto->aula($fecha,$inicio,$fin,$idaula);
if ($resultado2!=FALSE) {
	
	echo $resultado2;
	
}else{

$mensaje1=$objeto->agregar($tabla1,$campos1,$valores1);

if ($mensaje1==TRUE) {
	
echo "<script>alert('Prestamo realizado');location.href='?pag=buscar_equipo.php';</script>";
}else{
	
	echo "No se guardo el prestamo";
	}
}
}
}
}
}
}
}
$tabla=$objeto->prestar($id);
echo $tabla;

}
   ?>

 
 