

    <link rel="stylesheet" href="Areloj/estilos.css">

	<div class="wrap">
		<div class="widget">
			<div class="fecha">
				<table cellpadding ="10"><tr><td >
				<p id="diaSemana" class="diaSemana"></p>
				<p id="dia" class="dia"></p>
				<p>de </p>
				<p id="mes" class="mes"></p>
				<p>del </p>
				<p id="year" class="year"></p></td><td>
			
	<P> </P>
			
				<p id="horas" class="horas"></p>
				<p>:</p>
				<p id="minutos" class="minutos"></p>
				<p>:</p>
				<p class="caja-segundos">
					<p id="segundos" class="segundos"></p>
					<p id="ampm" class="ampm"></p>
					
				</p></td></tr>
			</div>
		</div>
	</div>
	<script src="Areloj/reloj.js"></script>


	