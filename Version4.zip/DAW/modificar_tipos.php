<?php
@session_start(); 
if ($_SESSION["usuario2"]["Tipo"]!='Administrador') {
header("Location:login.php");
}else{
 ?>
<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>

 <?php
 include_once("conexion.php");
if (isset($_POST["ok"])) {
	$id=$_POST["idtipo"];
	$tipo=ucfirst($_POST["tipo"]);
	$update="UPDATE tiposequipo set Tipo='$tipo' where IdTipo='$id'";
	$conexion->query($update);
	echo "<script> 
        location.href='index.php?pag=agregar_tipos.php';
    </script>";
}
   ?>
   <?php 

$id=$_GET["idcat"];
$consultar="select * from tiposequipo where IdTipo='$id'";
$r=$conexion->query($consultar);
$fila=$r->fetch_assoc();
 ?>
 <form method="post">
 	<table class=blue-form2>
 		<tr>
 	<th>Modificar Tipos de Equipo</th>
</tr>
<tr>
	<td><input name="idtipo" type="hidden" value="<?php echo $fila["IdTipo"]?>"> 
		<input type="text" name="tipo" class="texto" value="<?php echo $fila["Tipo"];?>" required=required></td>
</tr>
<tr><th><input type="submit" name="ok" class="boton" value="Actualizar"></th></tr>
 	</table>
 </form>
 <?php 
}
?>
 