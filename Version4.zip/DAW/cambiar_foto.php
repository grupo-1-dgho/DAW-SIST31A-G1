<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:index.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>



<?php 

if(isset($_POST["guardar"]) && !empty($_POST["guardar"]) && (isset($_FILES["fichero"]))){
	if(is_uploaded_file($_FILES["fichero"]["tmp_name"])){
		$tmp_name=$_FILES["fichero"]["tmp_name"];
		$namee="img/".$_FILES["fichero"]["name"];
		if(is_file($namee)){
			$idunico=time();
			$namee="img/".$idunico."-".$_FILES["fichero"]["name"];
		}
		move_uploaded_file($tmp_name, $namee);
include_once("conexion.php");
$sql="UPDATE Usuarios set
Fotografia='$namee' where IdUsuario='".$_SESSION["usuario2"]["IdUsuario"]."'";
if ($conexion->query($sql)==TRUE) {
	$consulta="SELECT * from Usuarios where IdUsuario='".$_SESSION["usuario2"]["IdUsuario"]."'";
	$rs=$conexion->query($consulta);
	$row=$rs->fetch_assoc();
	foreach ($row as $key => $value) {
		$_SESSION["usuario2"][$key]=$value;
	}
	
echo "<script>location.href ='?pag=principal_docente.php';</script>";
}
}else{
	echo "<table cellspacing=15 width=80%>


	<tr>
		<td ><img src=". $_SESSION["usuario2"]["Fotografia"]." width=150 height=200></td>
	</tr>
	
<tr><form method=post ENCTYPE=multipart/form-data>
	<td>
<input type=file name=fichero>
	</td></tr><tr>
	<td>
	<input type=submit name=guardar value=Guadar class=boton>
	</td>
</form></tr>
</table>";
}

}else{
	echo "<table cellspacing=15 width=80%>

	<tr>
		<td ><img src=". $_SESSION["usuario2"]["Fotografia"]." width=150 height=200></td>
	</tr>
	
<tr><form method=post ENCTYPE=multipart/form-data>
	<td>
<input type=file name=fichero>
	</td></tr><tr>
	<td>
	<input type=submit name=guardar value=Guadar class=boton>
	</td>
</form></tr>
</table>";
}

 ?>


