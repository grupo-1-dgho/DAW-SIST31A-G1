<?php
include_once'conexion.php';  
$sql="Select * from usuarios";
$resultado=$conexion->query($sql);
if ($resultado->num_rows>0) {
	
header("Location:login.php");}
else{


?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/sweetalert2.css">
<script type="text/javascript" src="css/sweetalert2.min.js.download"></script>
<script type="text/javascript">
	function aler(titulo,mensaje)
	{  Swal.fire({ 
	   type: 'error',   
	    title: titulo,   
	     text: mensaje  
	 }) 
}
</script> 
<script type="text/javascript">   
	function checkForm(form){         
			      
			 	     
if(form.contra.value.length < 8) { 
msg="Error: La clave debe tener un minimo de 8 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.contra.focus();
return false;       
}  

if(form.contra.value == form.nombre.value) { 
msg="Error: La clave debe ser diferente al nombre !";   
tit="Error!!!";  
aler(tit,msg);          
form.contra.focus();         
return false; 
      }     
re = /[0-9]/;       
if(!re.test(form.contra.value)) {         
aler("Error: la clave debe tener almenos un digito (0-9)!");         
form.contra.focus();         
return false;       } 
re = /[a-z]/;       
if(!re.test(form.contra.value)) {  
msg="Error: La clave debe tener al menos una letra minuscula (a-z)!";   
tit="Error!!!";  aler(tit,msg);  
form.contra.focus();          
return false;       }       
re = /[A-Z]/;       
if (!re.test(form.contra.value)) {  
msg="Error: La clave debe tener al menos una letra mayuscula (A-Z)!";   
tit="Error!!!";  
aler(tit,msg);           
form.contra.focus();          
return false;       
}  
re = /[0-9]/;
if (!re.test(form.carnet.value)) {  
msg="Error: El carnet solo acepta numeros!";   
tit="Error!!!";  
aler(tit,msg);           
form.carnet.focus();          
return false;       
}
if(form.carnet.value.length < 6 || form.carnet.value.length > 6) { 
msg="Error: El carnet tiene que tener 6 números!";   
tit="Error!!!";  
aler(tit,msg);
form.carnet.focus();
return false;       
} 
if(form.nombre.value.length < 3) { 
msg="Error: El nombre tiene que tener al menos 3 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.nombre.focus();
return false;       
}  
if(form.apellido.value.length < 3) { 
msg="Error: El apellido tiene que tener al menos 3 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.apellido.focus();
return false;       
}  

}
     
       </script> 
	<title></title>
	<style type="text/css">

body{
	font-family: Arial;
	background-image: url(fondo3.jpg);
	background-repeat: no-repeat;
	background-position: fixed;
	background-size: cover;

}

.texto:focus{
	border:3px solid green;
}
.texto{
width: 100%;
border-radius: 5px;
height: 25px;
font-size: 15px;
				}
.article2{
width: 40%;
padding: 10px;
box-sizing: border-box;
background-color:#A80A0D;
color: white;
font-size: 25px;
border: 3px solid blue;
 box-shadow:0px 5px 20px blue;
 margin: 50px;
}

.boton{
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 150px;
	font-size: 18px;
	background-color:#1C2EDE;
	
    border: 1px double #6699FF; 
    color: #FFF; 
    font-weight: bold; 
    cursor: pointer; 
     
    margin: 0 0px 0 0px; 
    padding: 2px 10px 2px 10px; 
    border-radius:5px; 
    box-shadow: inset 0px 3px 5px #FFF; 
}




	</style>
</head>
<body bgcolor="gray">
<?php 
@session_start(); 
include 'conexion.php';


?>



	<center><article class="article2">
<?php
include_once 'Conectar.php';
$objeto=new Conexion();

if (isset($_POST['registrar'])) {
	$nombre=ucwords($_POST['nombre']);
	$apellido=ucwords($_POST['apellido']);
	$carnet=$_POST['carnet'];
	$correo=$_POST['correo'];
	$password=$_POST['contra'];
$contraseña =$objeto-> encriptar($password);
$consultar="select * from Usuarios where Contra='$contraseña'";
	$r1=$conexion->query($consultar);
	if ($r1->num_rows>0) {
		echo "Error: esa contraseña ya se encuentra en uso!";   
}else{
	
	
	$sql="INSERT INTO Usuarios (Carnet,Nombre,Apellido,E_mail,Contra,Tipo)
						 VALUES ('$carnet','$nombre','$apellido','$correo','$contraseña','Administrador')";
 if ($conexion->query($sql)==TRUE) {
 	
						echo "<script>location.href='login.php';</script>";
						 }else{
echo "<h1>No se guardo el registro</h1>

";
						 } 
}
}

?>
<?php
include 'conexion.php';
	echo "REGISTRARSE<form method=post name=registro onsubmit='return checkForm(this);' >
<table cellpadding=8 class=blue-form>
	
	<tr>
		<td width=600><input type=text name=nombre class=texto required=required id=nombre title='Debe ingresar almenos 3 caracteres' autofocus placeholder='Ingrese sus nombres'></td>
	</tr>
	<tr>
		<td width=600><input type=text name=apellido class=texto required=required id=apellido title='Debe ingresar almenos 3 caracteres' placeholder='Ingrese sus apellidos'></td>
	</tr>
	<tr>
		<td><input type=text  name=carnet class=texto required=required id=carnet placeholder=000000></td>
	</tr>
	<tr>
		<td>
		<input type=email name=correo class=texto required=required id=correo placeholder='example@gmail.com'></td>
	</tr>
	
	<tr>
		<td><input type=password name=contra class=texto required=required id=contraseña  title='Debe contener 8 o más caracteres ' placeholder='Contraseña'><font style='font-size:15px; color:black;'>*Debe contener lestras mayusculas, minusculas y números</font></td>
	</tr>
	<tr><td align=center><input type=submit name=registrar class=boton value=Registrar></td></tr>
</table>


</form>";
?>

</article></center>


</body>
</html>

<?php 
}
 ?>