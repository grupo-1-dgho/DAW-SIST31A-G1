<?php
@session_start();  
?>
<!DOCTYPE html>
<html>
<head>
	<title>Sistema ITCA</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<style type="text/css">

body{
font-family: Arial;
	background-image: url(fondo3.jpg);
	background-repeat: no-repeat;
	background-position: fixed;
	background-size: cover;

}

.texto:focus{
	border:3px solid green;
}
.texto{
width: 100%;
border-radius: 5px;
height: 25px;
font-size: 15px;
				}
.article2{
width: 40%;
padding: 10px;
box-sizing: border-box;
background-color:#A80A0D;
color: white;
font-size: 25px;
border: 3px solid blue;
 box-shadow:0px 5px 20px blue; 
}

.boton{
	/*dependiento del texto del boton pueden cambiarle el ancho en el width*/
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 150px;
	font-size: 18px;
	background-color:#1C2EDE;
	
    border: 1px double #6699FF; 
    color: #FFF; 
    font-weight: bold; 
    cursor: pointer; 
     
    margin: 0 0px 0 0px; 
    padding: 2px 10px 2px 10px; 
    border-radius:5px; 
    box-shadow: inset 0px 3px 5px #FFF; 
}




	</style>


</head>
<body bgcolor="gray">

<?php 
	if(isset($_GET["c"])){ 
    require_once($_GET["c"]); 
} ?>
<?php
include_once'conexion.php';  
$sql="Select * from usuarios";
$resultado=$conexion->query($sql);
if ($resultado->num_rows>0) {
	


?>

<?php 
@session_start();
function SQLsegura($strVar){  
 	$banned = array("select","drop","|","'", ";", "--", "insert","delete", "xp_");     
   $vowels = $banned; 
    $no = str_replace($vowels, "", $strVar);  
    $final = str_replace( "'","",$no);
      return $final; }
      //End Function 
$Usuario='root';
$Contraseña='itca2019';
$Servidor='localhost';
$Basededatos='proyecto2019_5';
if (isset($_POST["entrar"])) {
	$correo=SQLsegura($_POST["correo"]);
	$contraseña=SQLsegura($_POST["contraseña"]);
	$conexion= new mysqli($Servidor,$Usuario,$Contraseña,$Basededatos);
	include_once'Conectar.php';
	$objeto=New Conexion();
	$password = $objeto->encriptar($contraseña);
	
$sql="SELECT Tipo, Estado FROM Usuarios
WHERE E_mail='$correo' AND Contra='$password'";
$sql2="SELECT * from Usuarios where Tipo='Administrador'";
$resultado2=$conexion->query($sql2);
$f=$resultado2->fetch_assoc();
$resultado=$conexion->query($sql);
$fila=$resultado->fetch_assoc();
$cuantos=$resultado->num_rows;
$cuantos2=$resultado2->num_rows;

	if ($cuantos==0) {
		
		echo "<script>alert('Correo o contraseña incorrecta');location.href ='login.php';</script>";
	}
elseif ($cuantos==1 and $f["Tipo"]==$fila["Tipo"]) {
	
	$cargo=$fila["Tipo"];
	$_SESSION["usaindex"]='Si';
	$sql3="SELECT
    `usuarios`.`IdUsuario`
    , `usuarios`.`Carnet`
    , `usuarios`.`Nombre`
    , `usuarios`.`Apellido`
    , `usuarios`.`E_mail`
    , `usuarios`.`Direccion`
    , `usuarios`.`Fecha_Nacimiento`
    , `usuarios`.`Fotografia`
    , `usuarios`.`Tipo`
    , `usuarios`.`Contra`
    , `usuarios`.`Estado`
    
FROM
    `proyecto2019_5`.`usuarios`
        where contra='$password';
        ";
	$rs=$conexion->query($sql3);
	$todo=$rs->fetch_assoc();
	foreach ($todo as $key => $value) {
		$_SESSION["usuario2"][$key]=$value;
	}


	
	if($fila["Estado"]=="Activo"){
		$_SESSION["contraseña"]=$_POST["contraseña"];
		$_SESSION["usuario"]["correo"]=$correo;
		$_SESSION["usuario"]["contraseña"]=$password;
		$_SESSION["usuario"]["cargo"]=$cargo;
		if ($cargo=="Administrador") {
		$_SESSION["esadministrador"]='Si';
		header("Location: index.php");
		}else{
			header("Location: index.php");
		}
	
}else{
	
	echo "<script>alert('Actualmente su usuario se encuentra desactivado');</script>";
}
}
	else{


	$cargo=$fila["Tipo"];
	$_SESSION["usaindex"]='Si';
	$sql3="SELECT
    `usuarios`.`IdUsuario`
    , `usuarios`.`Carnet`
    , `usuarios`.`Nombre`
    , `usuarios`.`Apellido`
    , `usuarios`.`E_mail`
    , `usuarios`.`Direccion`
    , `usuarios`.`Fecha_Nacimiento`
    , `usuarios`.`Fotografia`
    , `usuarios`.`Tipo`
    , `usuarios`.`IdCarrera`
    , `usuarios`.`Contra`
    , `usuarios`.`Estado`
    , `carreras`.`Carrera`
FROM
    `proyecto2019_5`.`usuarios`
    INNER JOIN `proyecto2019_5`.`carreras` 
        ON (`usuarios`.`IdCarrera` = `carreras`.`IdCarrera`) 
        where contra='$password';
        ";
	$rs=$conexion->query($sql3);
	$todo=$rs->fetch_assoc();
	foreach ($todo as $key => $value) {
		$_SESSION["usuario2"][$key]=$value;
	}


	
	if($fila["Estado"]=="Activo"){
			$_SESSION["contraseña"]=$_POST["contraseña"];;
		$_SESSION["usuario"]["correo"]=$correo;
		$_SESSION["usuario"]["contraseña"]=$password;
		$_SESSION["usuario"]["cargo"]=$cargo;
		if ($cargo=="Administrador") {
		$_SESSION["esadministrador"]='Si';
		header("Location: index.php");
		}else{
			
			header("Location: index.php");
		}
	
}else{
	
	echo "<script>alert('Actualmente su usuario se encuentra desactivado');</script>";
}
	
	}}

	elseif  (isset($_GET["cerrar"])) {
unset($_SESSION["usuario"]);
unset($_SESSION["usuario2"]);
unset($_SESSION["usaindex"]);
unset($_SESSION["esadministrador"]);
unset($_SESSION["contraseña"]);
	
}




 ?>
<center><article class=article2>
<form method=post>
	<center><table cellspacing=20 >
		<tr><th >INGRESE SUS DATOS</th></tr>
		<tr><td ><img src=img/login.jpg></td></tr>
		<tr><td><input type=email name=correo required=required class=texto autofocus placeholder="Ingrese su email"></td></tr>
		<tr><td><input type=password name=contraseña required=required class=texto placeholder="Ingrese su contraseña"></td></tr>
		<tr><th ><input type=submit name=entrar class=boton value='Iniciar sesión'></th></tr>
	</table>
</center>
</form></article></center>

</body>
</html>
<?php  
}else{
header("Location:registro.php")	;
}	
?>


