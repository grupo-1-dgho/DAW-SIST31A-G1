<?php
@session_start(); 
if ($_SESSION["usuario2"]["Tipo"]!='Administrador') {
header("Location:login.php");
}else{
 ?>
<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>


	<?php
include('conexion.php');
?>
<?php
if (isset($_POST['ok'])) {
	$carrera=ucfirst($_POST['carrera']);
$consultar="select * from Carreras where Carrera='$carrera'";
	$r1=$conexion->query($consultar);
	if ($r1->num_rows>0) {
		echo "Error: Ya existe una carrera con ese nombre y esa marca!";   
}else{
	$inser= "INSERT INTO Carreras (Carrera) VALUES ('$carrera')";

	if ($conexion->query($inser)==TRUE) {
 	
						echo "<h1>Registro Insertado</h1>";
						 }else{
echo "<h1>Registro No Insertado</h1>";
}
}
}elseif (isset($_POST["eliminar"]) and isset($_POST['id']) ) {
	$ids=$_POST['id'];
foreach ($ids as $id) {
$delete= "Delete from Carreras where IdCarrera='$id'";
$conexion->query($delete);
}

		}
?>
	<form method='post'>
		<table class="blue-form">
	<tr>
	<th colspan="2">Agregar Carreras de ITCA</th>
		</tr>
		<tr>
			<td><input type="text" name="carrera" placeholder="Ingrese una carrera..." required='' autofocus class="texto"></td>
			<td><input type="submit" name="ok" class=boton value="Aceptar"></td>
		</tr>	
		</table>
	</form>	
	<br>
	<form method="post"><table class="blue-form2">
		<tr>
			<th colspan="2">Carreras</th>
		</tr>
		
		<?php  
$carreras="Select * from Carreras";
if ($conexion->query($carreras)==TRUE) {
	$resultado2=$conexion->query($carreras);
	while ($row=$resultado2->fetch_assoc()) {
		echo "<tr>
			<td>
			<input type=checkbox name=id[]  value=$row[IdCarrera]>$row[Carrera]	
			</td>
			<td><a href='?pag=modificar_carreras.php&idcat=$row[IdCarrera]'><img src=img/edit.jpg width=25 height=25 title='Modificar Registro'></a>
	</td>
		</tr>";
	}
}
		?>
		<tr>
			<th colspan="2"><input type="submit" name="eliminar" class="boton" value="Eliminar"></th>
		</tr>
	</table></form>

<?php } ?>
	





	