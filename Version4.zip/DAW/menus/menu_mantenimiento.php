
	<style >

ul.menu { 
    list-style-type: none; 
    margin: 0; 
    padding: 0; 
    overflow: hidden; 
    background-color: #9B0B0D; 
    width: 95%;
    border-radius: 5px;

} 

ul.menu li { 
    float: center; 
} 

ul.menu li a, .dropbtn { 
    display: inline-block; 
    color: white; 
    text-align: center; 
    padding: 14px 16px; 
    text-decoration: none; 
} 

ul.menu li a:hover, .dropdown:hover .dropbtn { 
    background-color:black ; 
} 

ul.menu li.dropdown { 
    display: inline-block; 
} 

ul.menu .dropdown-content { 
    display: none; 
    position: absolute; 
    background-color: #9B0B0D; 
    min-width: 160px; 
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); 
    z-index: 1; 
} 

ul.menu .dropdown-content a { 
    color: white; 
    padding: 12px 16px; 
    text-decoration: none; 
    display: block; 
    text-align: left; 
} 

ul.menu .dropdown-content a:hover {background-color: black} 

ul.menu .dropdown:hover .dropdown-content { 
    display: block; 
} 



</style>
</head>
<body>
<nav><!--solo editen cada el nombre y los link-->
	<ul class=menu>
	<li class=dropdown>
	<a href= "?pag=principal_docente.php">Mi perfil</a>
	</li>
	
	<li class=dropdown>
		<a href="javascript:void(0)" class="dropbtn" >Mantenimiento 1</a>
		<div class=dropdown-content>
		<a href="?pag=marcas.php">Marcas de equipo</a>
		<a href="?pag=modelos.php">Modelos de equipo</a>
		<a href="?pag=agregar_tipos.php">Tipos de equipo</a>
		<a href="?pag=agregar_carreras.php">Carreras</a>
		<a href="?pag=agregar_aulas.php">Aulas</a>
		<a href="?pag=agregar_horarios.php">Horarios</a>
		</div>
	</li >
	<li class=dropdown>
		<a href="javascript:void(0)" class="dropbtn" >Mantenimiento 2</a>
		<div class=dropdown-content>
		<a href="?pag=agregar_equipos.php">Agregar equipo</a>
		<a href="?pag=registro_usuarios.php">Agregar usuarios</a>
		<a href="?pag=agregar_fallas.php">Fallas</a>
		
		</div>
	</li >
	<li class=dropdown>
		<a href="javascript:void(0)" class="dropbtn" >Consultas</a>
		<div class=dropdown-content>
	
			<a href="?pag=mantenimiento_usuario.php">Usuarios</a>
		<a href="?pag=mantenimiento_equipos.php">Equipos</a>
		<a href="?pag=consulta_prestamos.php">Prestamos</a>
		</div>
	</li >
	<li class=dropdown>
		<a href="javascript:void(0)" class="dropbtn">Reportes</a>
		<div class=dropdown-content>
		<a href="reporte_usuario.php " target="_bank">Usuarios</a>
		<a href="reporte_equipos.php" target="_bank">Equipos</a>
		<a href="reporte_computadora.php" target="_bank">Computadoras</a>
		<a href="reporte_fallas.php" target="_bank">Fallas</a>
		<a href="reporte_presadmin.php" target="_bank">Prestamos</a>
		</div>
	</li>
	<li class=dropdown>
	<a href="login.php">Cerrar</a>
	</li>
</ul></nav>


