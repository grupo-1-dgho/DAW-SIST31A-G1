<?php
@session_start(); 
if ($_SESSION["usuario2"]["Tipo"]!='Administrador') {
header("Location:login.php");
}else{
 ?>
<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>

       

      <legend>Prestamos Activos</legend>
<?php 
include_once'Clase_Prestamos.php';
$objeto=New Prestamos();
$sql="SELECT
    `equipos`.`NombreEquipo`
    , `equipos`.`NumeroSerie`
    , `equipos`.`IdEquipo`
    , `prestamos`.`IdPrestamo`
    , `prestamos`.`EstadoPrestamo`
    , `prestamos`.`IdEquipo`
    , `prestamos`.`Fecha`
    , `prestamos`.`HoraTotal`
    , `equipos`.`NombreEquipo`
    , `equipos`.`NumeroSerie`
    , `marcas`.`Marca`
    , `modelos`.`Modelo`
    , `aulas`.`Aula`
    , `usuarios`.`Carnet`
    , `usuarios`.`Nombre`
    , `usuarios`.`Apellido`
FROM
    `proyecto2019_5`.`prestamos`
    INNER JOIN `proyecto2019_5`.`equipos` 
        ON (`prestamos`.`IdEquipo` = `equipos`.`IdEquipo`)
    INNER JOIN `proyecto2019_5`.`marcas` 
        ON (`equipos`.`IdMarca` = `marcas`.`IdMarca`)
    INNER JOIN `proyecto2019_5`.`modelos` 
        ON (`equipos`.`IdModelo` = `modelos`.`IdModelo`)
    INNER JOIN `proyecto2019_5`.`aulas` 
        ON (`prestamos`.`IdAula` = `aulas`.`IdAula`)
    INNER JOIN `proyecto2019_5`.`usuarios` 
        ON (`prestamos`.`IdUsuario` = `usuarios`.`IdUsuario`)
        where EstadoPrestamo='Activo'";
$r=$objeto->prestamosadministrador($sql);
echo "$r";
}
 ?>