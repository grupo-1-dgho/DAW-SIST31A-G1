<?php
include_once'clase_reportes.php';
$ob=new Reportes();
echo $ob->Requipos(); 

 ?>