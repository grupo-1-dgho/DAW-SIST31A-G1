<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>
<legend>Prestamos Activos</legend>
<?php 
include_once'Clase_Prestamos.php';
$objeto=New Prestamos();
if (isset($_POST["devolver"])) {
	$idprestamo=$_POST["idprestamo"];
	$objeto->devolver($idprestamo);
}
$id=$_SESSION["usuario2"]["IdUsuario"];
$r=$objeto->prestamosdocente($id);
echo "$r";

 ?>