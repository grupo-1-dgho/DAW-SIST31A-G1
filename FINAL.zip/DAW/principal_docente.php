<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>


<table cellspacing=15 width=80%>

	<tr>
		<td rowspan=5><img src= <?php echo $_SESSION["usuario2"]["Fotografia"]; ?> width=150 height=200></td>
		<td style='border-bottom: 2px solid #9B0B0D'>Carnet: <?php echo $_SESSION["usuario2"]["Carnet"]; ?> </td>
	</tr>
	<tr>
		<td style='border-bottom: 2px solid #9B0B0D' >Nombre: 
		 <?php echo $_SESSION["usuario2"]["Nombre"] ." ".$_SESSION["usuario2"]["Apellido"]; ?></td>
		
	</tr>
<tr>
	<td style='border-bottom: 2px solid #9B0B0D'>E-mail:  <?php echo $_SESSION["usuario2"]["E_mail"]; ?></td>
</tr>
<tr>
	<td style='border-bottom: 2px solid #9B0B0D'>Dirección:  <?php echo $_SESSION["usuario2"]["Direccion"]; ?></td>
</tr>
<tr>
	<td  style='border-bottom: 2px solid #9B0B0D'>Fecha de nacimiento:  <?php echo $_SESSION["usuario2"]["Fecha_Nacimiento"]; ?></td>
</tr>
<tr><form method=post>
	<td>
	<a href="?pag=cambiar_foto.php">Cambiar foto</a>
	</td>
	<td>
	<a href="?pag=modificar.php">Modificar datos</a>
	</td>
</form></tr>
</table>
