<link rel="stylesheet" type="text/css" href="EstilosReportes.css">
<?php 
include 'Conectar.php';

class Reportes{
	protected $C;
	public function Reportes(){
		//inicializamos lo necesario
		$this->C=new Conexion();
	}
	
public function RUsuarios(){
	$res = "SELECT
    `usuarios`.`IdUsuario`
    , `usuarios`.`Carnet`
    , `usuarios`.`Nombre`
    , `usuarios`.`Apellido`
    , `usuarios`.`E_mail`
    , `usuarios`.`Direccion`
    , `usuarios`.`Fecha_Nacimiento`
    , `usuarios`.`Fotografia`
    , `usuarios`.`Tipo`
    , `usuarios`.`IdCarrera`
    , `usuarios`.`Contra`
    , `usuarios`.`Estado`
    , `carreras`.`Carrera`
FROM
    `proyecto2019_5`.`usuarios`
    INNER JOIN `proyecto2019_5`.`carreras` 
        ON (`usuarios`.`IdCarrera` = `carreras`.`IdCarrera`);";

       $resultado= $this->C->consultar($res);
       $valor=' ';

$valor.="
<img src='itca2.jpg' width='200' height='70' align=center>

<h1>REPORTE DE USUARIOS</h1>
<table class=blue-form3 cellpadding=10>
<tr>

<th>Carnet</th>
<th>Nombre</th>
<th>Correo</th>
<th>Carrera</th>
<th>Estado</th>

</tr>
";
       while ($fila=$resultado->fetch_assoc()) {
      $valor.=" <tr>
";
        $valor.="
<td><b>$fila[Carnet]</b><br>
<img src='$fila[Fotografia]' width=50 height=50></td>
<td>$fila[Nombre] $fila[Apellido]</td>
<td >$fila[E_mail]</td>
<td >$fila[Carrera]</td>
<td>$fila[Estado]</td>

</tr>

    ";
       }
       $valor.="</table>" ;
      // $valor="hola"; 
        return $valor;

	}
  public function Rcomputadoras (){
  $res = "SELECT
    `equipos`.`NombreEquipo`
    , `marcas`.`Marca`
    , `modelos`.`Modelo`
    , `equipos`.`NumeroSerie`
    , `equipos`.`Descripcion`
    , `tiposequipo`.`Tipo`
    , `equipos`.`Estado`
    , `equipos`.`Fecha_Registro`
    , `equipos`.`IdEquipo`
    , `carreras`.`Carrera`
FROM
    `proyecto2019_5`.`equipos`
    INNER JOIN `proyecto2019_5`.`marcas` 
        ON (`equipos`.`IdMarca` = `marcas`.`IdMarca`)
    INNER JOIN `proyecto2019_5`.`modelos` 
        ON (`equipos`.`IdModelo` = `modelos`.`IdModelo`)
    INNER JOIN `proyecto2019_5`.`tiposequipo` 
        ON (`equipos`.`IdTipo` = `tiposequipo`.`IdTipo`)
    INNER JOIN `proyecto2019_5`.`carreras` 
        ON (`equipos`.`IdCarrera` = `carreras`.`IdCarrera`)
WHERE Tipo='Computadora'        
        ;";

       $resultado= $this->C->consultar($res);
       $valor=' ';

$valor.="
<img src='itca2.jpg' width='200' height='70' align=center>

<h1>REPORTE DE COMPUTADORAS</h1>
<table class=blue-form3 cellpadding=10>
<tr>

<th>Nombre</th>
<th>Número de Serie</th>
<th>Descripción</th>
<th>Carrera</th>
<th>Estado</th>

<th >Fecha de <br>Registro</th>

</tr>
";
       while ($fila=$resultado->fetch_assoc()) {
      $valor.=" <tr>
";
        $valor.="
<td>$fila[NombreEquipo]</td>
<td>$fila[NumeroSerie]</td>
<td >Marca: $fila[Marca]<br>
Modelo: $fila[Modelo] 
<br>$fila[Descripcion]</td>


<td> $fila[Carrera]</td>
<td>$fila[Estado]</td>

<td >$fila[Fecha_Registro]</td>

</tr>

    ";
       }
       $valor.="</table>" ;
      // $valor="hola"; 
        return $valor;

  }
  public function RFallas (){
  $res = "SELECT
    `equipos`.`NombreEquipo`
    , `equipos`.`IdMarca`
    , `equipos`.`IdModelo`
    , `equipos`.`NumeroSerie`
    , `marcas`.`Marca`
    , `modelos`.`Modelo`
    , `fallas_equipo`.`Descripcion`
    , `fallas_equipo`.`Fechareporte`
    , `fallas_equipo`.`IdFalla`
FROM
    `proyecto2019_5`.`equipos`
    INNER JOIN `proyecto2019_5`.`modelos` 
        ON (`equipos`.`IdModelo` = `modelos`.`IdModelo`)
    INNER JOIN `proyecto2019_5`.`marcas` 
        ON (`equipos`.`IdMarca` = `marcas`.`IdMarca`)
    INNER JOIN `proyecto2019_5`.`fallas_equipo` 
        ON (`fallas_equipo`.`IdEquipo` = `equipos`.`IdEquipo`)
        ORDER BY NombreEquipo;";

       $resultado= $this->C->consultar($res);
       $valor=' ';

$valor.="
<img src='itca2.jpg' width='200' height='70' align=center>

<h1>REPORTE DE FALLAS</h1>
<table class=blue-form3 cellpadding=10>
<tr>

<th>Nombre Equipo</th>
<th>Marca</th>
<th>Modelo</th>
<th>Falla</th>
<th >Fecha de reporte</th>

</tr>
";
       while ($fila=$resultado->fetch_assoc()) {
      $valor.=" <tr>
";
        $valor.="
<td>$fila[NombreEquipo]</td>
<td>$fila[Marca]</td>
<td>$fila[Modelo] </td>
<td id=falla> $fila[Descripcion]</td>
<td >$fila[Fechareporte]</td>

</tr>

    ";
       }
       $valor.="</table>" ;
      // $valor="hola"; 
        return $valor;

  }
   public function Requipos(){
  $res = "SELECT
    `equipos`.`IdEquipo`
    , `equipos`.`NombreEquipo`
    , `equipos`.`Descripcion`
    , `equipos`.`NumeroSerie`
    , `equipos`.`Estado`
    , `equipos`.`Fecha_Registro`
    , `marcas`.`Marca`
    , `tiposequipo`.`Tipo`
    , `carreras`.`Carrera`
    , `modelos`.`Modelo`
FROM
    `proyecto2019_5`.`equipos`
    INNER JOIN `proyecto2019_5`.`marcas` 
        ON (`equipos`.`IdMarca` = `marcas`.`IdMarca`)
    INNER JOIN `proyecto2019_5`.`tiposequipo` 
        ON (`equipos`.`IdTipo` = `tiposequipo`.`IdTipo`)
    INNER JOIN `proyecto2019_5`.`carreras` 
        ON (`equipos`.`IdCarrera` = `carreras`.`IdCarrera`)
    INNER JOIN `proyecto2019_5`.`modelos` 
        ON (`equipos`.`IdModelo` = `modelos`.`IdModelo`)
        where Tipo!='Computadora' or  Tipo!='computadora'
        or  Tipo!='COMPUTADORA'
;";

       $resultado= $this->C->consultar($res);
       $valor=' ';

$valor.="
<img src='itca2.jpg' width='200' height='70' align=center>

<h1>REPORTE DE EQUIPOS</h1>
<table class=blue-form3 cellpadding=10>
<tr>

<th>Nombre</th>
<th>N° <br>Serie</th>
<th>Tipo</th>
<th>Carrera</th>
<th>Estado</th>
<th >Descripcion</th>
<th >Fecha <br>de Registro</th>
</tr>
";
       while ($fila=$resultado->fetch_assoc()) {
      $valor.=" <tr>
";
        $valor.="
<td>$fila[NombreEquipo]</td>
<td>$fila[NumeroSerie]</td>
<td>$fila[Tipo]</td>
<td> $fila[Carrera]</td>
<td>$fila[Estado]</td>
<td id=des>Marca:$fila[Marca]<br>Modelo: $fila[Modelo]<br>$fila[Descripcion]</td>
<td >$fila[Fecha_Registro]</td>

</tr>

    ";
       }
       $valor.="</table>" ;
      // $valor="hola"; 
        return $valor;

  }
 
   public function RprestamosD($id){
  $res = "SELECT
    `prestamos`.`IdPrestamo`
    , `prestamos`.`IdUsuario`
    , `prestamos`.`EstadoPrestamo`
    , `prestamos`.`HoraTotal`
    , `prestamos`.`Fecha`
    , `aulas`.`Aula`
    , `equipos`.`NombreEquipo`
    , `equipos`.`NumeroSerie`
    , `marcas`.`Marca`
    , `modelos`.`Modelo`
FROM
    `proyecto2019_5`.`prestamos`
    INNER JOIN `proyecto2019_5`.`aulas` 
        ON (`prestamos`.`IdAula` = `aulas`.`IdAula`)
    INNER JOIN `proyecto2019_5`.`equipos` 
        ON (`prestamos`.`IdEquipo` = `equipos`.`IdEquipo`)
    INNER JOIN `proyecto2019_5`.`marcas` 
        ON (`equipos`.`IdMarca` = `marcas`.`IdMarca`)
    INNER JOIN `proyecto2019_5`.`modelos` 
        ON (`equipos`.`IdModelo` = `modelos`.`IdModelo`) 
    where IdUsuario='$id' 
;";

       $resultado= $this->C->consultar($res);
       $valor=' ';

$valor.="
<img src='itca2.jpg' width='200' height='70' align=center>

<h1>REPORTE DE PRESTAMOS</h1>
<table class=blue-form3 cellpadding=10>
<tr>

<th>Nombre del Equipo</th>
<th>Descripcion</th>
<th>Fecha</th>
<th>Hora del prestamo</th>
<th>Aula</th>
<th>Estado del <br>Prestamo</th>
</tr>
";
       while ($filas=$resultado->fetch_assoc()) {
      $valor.=" <tr>
";
        $valor.="
<td>$filas[NombreEquipo]</td>
<td>Marca:$filas[Marca]<br>Modelo:$filas[Modelo]<br>N° Serie:$filas[NumeroSerie]</td>
<td>$filas[Fecha]</td>
<td>$filas[HoraTotal]</td>
<td>$filas[Aula]</td>
<td>$filas[EstadoPrestamo]</td>
</tr>

    ";
       }
       $valor.="</table>" ;
      // $valor="hola"; 
        return $valor;

  }
   public function RprestamosA(){
  $res = " SELECT `equipos`.`NombreEquipo`
    , `equipos`.`NumeroSerie`
    , `equipos`.`IdEquipo`
    , `prestamos`.`IdPrestamo`
    , `prestamos`.`EstadoPrestamo`
    , `prestamos`.`IdEquipo`
    , `prestamos`.`Fecha`
    , `prestamos`.`HoraTotal`
    , `equipos`.`NombreEquipo`
    , `equipos`.`NumeroSerie`
    , `marcas`.`Marca`
    , `modelos`.`Modelo`
    , `aulas`.`Aula`
    , `usuarios`.`Carnet`
    , `usuarios`.`Nombre`
    , `usuarios`.`Apellido`
FROM
    `proyecto2019_5`.`prestamos`
    INNER JOIN `proyecto2019_5`.`equipos` 
        ON (`prestamos`.`IdEquipo` = `equipos`.`IdEquipo`)
    INNER JOIN `proyecto2019_5`.`marcas` 
        ON (`equipos`.`IdMarca` = `marcas`.`IdMarca`)
    INNER JOIN `proyecto2019_5`.`modelos` 
        ON (`equipos`.`IdModelo` = `modelos`.`IdModelo`)
    INNER JOIN `proyecto2019_5`.`aulas` 
        ON (`prestamos`.`IdAula` = `aulas`.`IdAula`)
    INNER JOIN `proyecto2019_5`.`usuarios` 
        ON (`prestamos`.`IdUsuario` = `usuarios`.`IdUsuario`)
   order by Fecha
;";

       $resultado= $this->C->consultar($res);
       $valor=' ';

$valor.="
<img src='itca2.jpg' width='200' height='70' align=center>

<h1>REPORTE DE PRESTAMOS</h1>
<table class=blue-form3 cellpadding=10>
<tr>
<th>Descripcion<br>del equipo</th>
<th>Detalles <br>del prestamo</th>

<th>Estado</th>
<th>Docente</th>
<th>carnet</th>

</tr>
";
       while ($filas=$resultado->fetch_assoc()) {
      $valor.=" <tr>
";
        $valor.="
<td><b>Nombre:</b><br> $filas[NombreEquipo]<br>
<b>Marca:</b><br> $filas[Marca]<br>
<b>Modelo:</b><br> $filas[Modelo]<br>
<b>N° Serie:</b> $filas[NumeroSerie]</td>
<td><b>Fecha:</b><br> $filas[Fecha]<br>
<b>Hora:</b><br> $filas[HoraTotal]<br>
<b>Aula:</b><br> $filas[Aula]</td>
<td  >$filas[EstadoPrestamo]</td>
<td>$filas[Nombre] $filas[Apellido]</td>
<td  >$filas[Carnet]</td>
</tr>

    ";
       }
       $valor.="</table>" ;
      // $valor="hola"; 
        return $valor;

  }
}
	
	
?>