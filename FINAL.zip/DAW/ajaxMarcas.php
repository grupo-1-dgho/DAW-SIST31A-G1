<?php
@session_start(); 
if ($_SESSION["usuario2"]["Tipo"]!='Administrador') {
header("Location:login.php");
}else{
 ?>
<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>
<?php 
include_once("conexion.php");
$id=$_GET["idcat"];
$consultar="select * from Marcas where IdMarca='$id'";
$r=$conexion->query($consultar);
$fila=$r->fetch_assoc();
 ?>
 <?php
if (isset($_POST["ok"])) {
	$id=$_POST["idmarca"];
	$marca=$_POST["marca"];
	$update="UPDATE Marcas set Marca='$marca' where IdMarca='$id'";
	$conexion->query($update);
	echo "<script> 
        location.href='index.php?pag=marcas.php';
    </script>";
}
   ?>
 <form method="post">
 	<table class=blue-form2>
 		<tr>
 	<th>Modificar Marca</th>
</tr>
<tr>
	<td><input name="idmarca" type="hidden" value="<?php echo $fila["IdMarca"]?>"> 
		<input type="text" name="marca" class="texto" value="<?php echo $fila["Marca"];?>" required=required></td>
</tr>
<tr><th><input type="submit" name="ok" class="boton" value="Actualizar"></th></tr>
 	</table>
 </form>
 <?php
}
?>