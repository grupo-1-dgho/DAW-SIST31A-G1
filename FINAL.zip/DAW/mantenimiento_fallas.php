<?php
@session_start(); 
if ($_SESSION["usuario2"]["Tipo"]!='Administrador') {
header("Location:login.php");
}else{
 ?>
<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>
<script type="text/javascript">
    function validar(form){
if (form.falla.value.length <8) {
msg="Error: Debe agregar al menos 8 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.falla.focus();
return false;
}
    }
</script>
<a href="?pag=agregar_fallas.php">Agregar Fallas</a>  &nbsp;&nbsp;&nbsp; &nbsp;<a href="?pag=fallasporequipo.php">Volver</a><br>

<?php 
  include_once'conexion.php';
$idfalla=$_GET["idcat"];
$sql="Select * from Fallas_equipo where IdFalla='$idfalla'";
$r=$conexion->query($sql);
$rowf=$r->fetch_assoc();
$sql2="SELECT
    `equipos`.`IdEquipo`
    , `fallas_equipo`.`IdFalla`
FROM
    `proyecto2019_5`.`fallas_equipo`
    INNER JOIN `proyecto2019_5`.`equipos` 
        ON (`fallas_equipo`.`IdEquipo` = `equipos`.`IdEquipo`)  where IdFalla='$idfalla';";
$r2=$conexion->query($sql2);
$rows=$r2->fetch_assoc();
if (isset($_POST["ok"])) {
  
    $falla=$_POST["falla"];
    $disponible=$_POST["disponible"];
    $updatefalla="UPDATE fallas_equipo set
     Descripcion='$falla' where IdFalla='$idfalla'";
   if ($disponible=='si') {
       $update="update Equipos set Estado='Disponible' where IdEquipo='$rows[IdEquipo]'";


   }else{
      $update="update Equipos set Estado='No Disponible' where IdEquipo='$rows[IdEquipo]'";

   }
    if ($conexion->query($updatefalla)==TRUE and $conexion->query($update)==TRUE) {
      echo "<script>
alert('Falla Guardada');
 location.href='index.php?pag=agregar_fallas.php';
 </script>
        ";
    }else{
       echo "<script>
alert('Falla No Guardada');
 </script>
        ";
    }
 } 
?>

<form method="post" onsubmit="return validar(this);">
    <table class="blue-form2">

    <tr><th colspan="2">Modificar falla</th>    </tr>
    
    <tr><td>Número de serie<br> del equipo:</td><td width="40%">
<?php  

$sql3="select NumeroSerie,IdEquipo from Equipos";
$r3=$conexion->query($sql3);
 while ($row=$r3->fetch_assoc()) {
 	if ($row["IdEquipo"]==$rowf["IdEquipo"]) {
  echo $row["NumeroSerie"];
 	}
 }


?>

    </td></tr>
    <tr><td colspan="2"><textarea class="textarea" name=falla id=falla autofocus=""  required="required" ><?php echo $rowf["Descripcion"];?></textarea></td></tr>
    <tr><td>El equipo está disponible<br>para prestar</td><td>
        <input type="radio" name="disponible" class="radio" value='si' required="">Si
        <input type="radio" name="disponible" class="radio" value='no' required="">No
    </td></tr>
    <tr><th colspan="2"><input type="submit" name="ok" class="boton" value="Guardar" ></th></tr>
    </table>
</form>

<?php
}
?>