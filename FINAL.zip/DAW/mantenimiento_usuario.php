<?php
@session_start(); 
if ($_SESSION["usuario2"]["Tipo"]!='Administrador') {
header("Location:login.php");
}else{
 ?>

<?php
  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
    header("Location:index.php");
}
  
?>
<style type="text/css">
    .text{
    /*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
width: 40%;
border-radius: 5px;
height: 30px;
border:1px black solid;
font-size: 15px;
 font-family: Comic Sans MS,Arial,Verdana;
        }
.text:focus{
    border:3px solid green;
}

</style>




<script type="text/javascript">
function xmlhttp(){
        var xmlhttp;
        try{xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");}
        catch(e){
            try{xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");}
            catch(e){
                try{xmlhttp = new XMLHttpRequest();}
                catch(e){
                    xmlhttp = false;
                }
            }
        }
        if (!xmlhttp)
                return null;
            else
                return xmlhttp;
    }

function buscar(){
        var query = document.getElementById('busqueda').value;
        var A = document.getElementById('resultados');
        var B = document.getElementById('loading');
        var ajax = xmlhttp();
 
        ajax.onreadystatechange=function(){
                if(ajax.readyState==1){
                        B.innerHTML = "<img src='images/loading.gif' alg='Loading...'>";
                    }
                if(ajax.readyState==4 && ajax.status==200){
                        
                        A.innerHTML = ajax.responseText;
                        B.innerHTML = "";
                    }
            }
 ajax.open("GET","busqueda.php?valor="+encodeURIComponent(query),true);
        ajax.send(null);
        return false;
    }
</script>


	
<legend>Buscar usuarios</legend>
Carnet:
<input type=text name=dato required=required class=text id=busqueda onKeyUp=buscar(); autofocus="">
<div id=resultados class=nocss>
    
<?php
if (isset($_POST["btndesactivar"]) and isset($_POST["usuarios"])) {
    
    if (!empty($_POST["usuarios"])) {
        $ids=$_POST["usuarios"];
include_once("conexion.php");
foreach ($ids as $id) {
 $update="update Usuarios set Estado='No Activo' where IdUsuario='$id'";
 $conexion->query($update);
}
    }else{
        
echo "Carnet:
<input type=text name=dato required=required class=texto id=busqueda onKeyUp=buscar(); autofocus>
<div id=resultados class=nocss>
</div>";
    }

}
elseif (isset($_POST["btnactivar"]) and isset($_POST["usuarios"]))  {
    
    if (!empty($_POST["usuarios"])) {
        $ids=$_POST["usuarios"];
include_once("conexion.php");
foreach ($ids as $id) {
 $update="update Usuarios set Estado='Activo' where IdUsuario='$id'";
 $conexion->query($update);
}




    }else{
        echo "Carnet:
<input type=text name=dato required=required class=texto id=busqueda onKeyUp=buscar(); autofocus>
<div id=resultados class=nocss>
</div>";
    }

}



 ?>
<?php

 include_once("conexion.php");
$sql="SELECT
    `usuarios`.`IdUsuario`
    , `usuarios`.`Carnet`
    , `usuarios`.`Nombre`
    , `usuarios`.`Apellido`
    , `usuarios`.`E_mail`
    , `usuarios`.`Direccion`
    , `usuarios`.`Fecha_Nacimiento`
    , `usuarios`.`Fotografia`
    , `usuarios`.`Tipo`
    , `usuarios`.`Contra`
    , `carreras`.`Carrera`
    , `usuarios`.`Estado`
FROM
    `proyecto2019_5`.`usuarios`
    INNER JOIN `proyecto2019_5`.`carreras` 
        ON (`usuarios`.`IdCarrera` = `carreras`.`IdCarrera`)
        where Tipo!='Administrador'
        ;";
if ($conexion->query($sql)==TRUE) {
    $resultado=$conexion->query($sql);
    
if ($resultado->num_rows>0) {
$r=' ';
$r.="<br><form method=post><input type=submit name=btndesactivar value=Desactivar class=boton2>
<input type=submit name=btnactivar value=Activar class=boton2><br><br>";
    while ($fila=$resultado->fetch_assoc()) {
        $r.="<table class=blue-form cellpadding= 10>
<tr>
<th colspan=2>
<input type=checkbox name=usuarios[] class=checkbox value='$fila[IdUsuario]'>Usuario</th></tr>";
        $r.="

<tr>
<td rowspan=9>
<img src=$fila[Fotografia] width=200 height=250></td>
<td>Carnet: $fila[Carnet]</td>
</tr>
<tr>
<td>Nombre: $fila[Nombre]</td>
</tr>
<tr>
<td>Apellido: $fila[Apellido]</td>
</tr>
<tr>
<td>E-mail: $fila[E_mail]</td>
</tr>
<tr>
<td >Carrera: $fila[Carrera]</td>
</tr>
<tr>
<td >Tipo: $fila[Tipo]</td>
</tr>
<tr>
<td >Estado: $fila[Estado]</td>
</tr>
    ";
     

    }
    $r.="</table></form>";
    echo $r;}}

 ?>
</div>



</form>



<?php 
}
 ?>