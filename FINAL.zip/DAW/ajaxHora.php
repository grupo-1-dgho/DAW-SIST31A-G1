<?php

  @session_start();
  if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}
?>
<?php  
$valor=$_GET["valor"];
if ($valor!=''){
	$respuesta='';
	include_once("conexion.php");
	$sql="select * from Horarios_Prestamo where HoraF>'$valor'";
	$resultado=$conexion->query($sql);
	$respuesta.=" 
			<select name=fin class=select>";
    while ($row3=$resultado->fetch_assoc()) {
        $respuesta.= "
<option value=$row3[HoraF]>$row3[HoraF]</option>";
}
$respuesta.= "</select>
</td>";

		echo "$respuesta";}
		
?>



