<?php
define('USUARIO', 'root');
define('CONTRA', 'itca2019');
define('SERVIDOR', 'localhost');
define('BASEDEDATOS', 'proyecto2019_5');
?>