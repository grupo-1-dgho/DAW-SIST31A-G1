<?php
@session_start(); 
if ($_SESSION["usuario2"]["Tipo"]!='Administrador') {
header("Location:login.php");
}else{
 ?>
<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>
<?php 
include_once("conexion.php");
$id=$_GET["idcat"];
$consultar="select * from Horarios_Prestamo where IdHorario='$id'";
$r=$conexion->query($consultar);
$fila=$r->fetch_assoc();
 ?>
 <?php
if (isset($_POST["ok"])) {
	$id=$_POST["idhora"];
	$HoraI=$_POST["HoraI"];
	$HoraF=$_POST["HoraF"];

	include_once'conexion.php';
$R=$conexion->query("SELECT * from Horarios_Prestamo where HoraI='$HoraI' and HoraF='$HoraF' and IdHorario!='$id'");
if ($R->num_rows>0) {
	echo "Ya existe esa hora inicial";
}else{
if ($HoraI>=$HoraF) {
	echo "La hora final debe ser mayor a la inicial<br>";
}else{
	$update="UPDATE Horarios_Prestamo set HoraI='$HoraI', HoraF='$HoraF' where IdHorario='$id'";
	$conexion->query($update);
	echo "<script> 
        location.href='index.php?pag=agregar_horarios.php';
    </script>";
}}}
   ?>
 <form method="post">
 	<table class=blue-form2>
 		<tr>
 	<th>Modificar Hora</th>
</tr>
<tr>
	<td><input name="idhora" type="hidden" value="<?php echo $fila["IdHorario"]?>"> 
		<input type="time" name="HoraI" class="texto" value="<?php echo $fila["HoraI"];?>" required=required></td>
</tr>
<tr>
	<td><input type="time" name="HoraF" class="texto" value="<?php echo $fila["HoraF"];?>" required=required></td></td>
</tr>
<tr><th><input type="submit" name="ok" class="boton" value="Actualizar"></th></tr>
 	</table>
 </form>
 <?php
}
?>