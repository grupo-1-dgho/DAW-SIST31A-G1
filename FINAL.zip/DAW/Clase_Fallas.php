<?php 
include 'Conectar.php';
class Fallas{
	protected $c;
	public function fallas(){
		//inicializamos lo necesario
		$this->c=new Conexion();
	}
	
	public function modificar($id,$nom,$ape,$ed,$dir){
		$sql="update persona set
		nombres='$nom', apellidos='$ape', edad='$ed', dirccion='$dir' 
		where id='$id'";
		$this->c->ejecutar($sql);
	}
	public function eliminar($ids){
		foreach ($ids as $id) {
			$sql="delete from fallas_equipo 
		where IdFalla='$id'";
		$this->c->ejecutar($sql);
		}
		
	}
	public function mostrar($id){
		$sql="select * from fallas_equipo where IdEquipo='$id';";
		$sql2="   SELECT
    `equipos`.`NombreEquipo`
    , `marcas`.`Marca`
    , `modelos`.`Modelo`
    , `equipos`.`NumeroSerie`
FROM
    `proyecto2019_5`.`equipos`
    INNER JOIN `proyecto2019_5`.`marcas` 
        ON (`equipos`.`IdMarca` = `marcas`.`IdMarca`)
    INNER JOIN `proyecto2019_5`.`modelos` 
        ON (`equipos`.`IdModelo` = `modelos`.`IdModelo`)
   
        WHERE equipos.IdEquipo='$id';";
		$resultado=$this->c->Consultar($sql);
		$resultado2=$this->c->Consultar($sql2);
		if ($resultado->num_rows>0) {
   $row=$resultado2->fetch_assoc();
$valor="<form method=post>
<h3><table class=blue-form3 cellpadding=8 width=100%><tr><td>
El equipo $row[NombreEquipo] $row[Marca] $row[Modelo], con número de serie $row[NumeroSerie] contiene las siguientes fallas:
</td></tr></table></h3>

";
$valor.="<table class=blue-form3 cellpadding=8 width=100%>

<tr>

<th>Id</th>
<th >Fecha de reporte</th>
<th >Descripción</th>
<th></th>
</tr>
";

    while ($fila=$resultado->fetch_assoc()) {
        $valor.=" 
<tr>";
        $valor.="
<td >
<input type=checkbox name=idfallas[] class=checkbox value='$fila[IdFalla]' ></td>";
        $valor.="

<td>$fila[Fechareporte]</td>
<td >$fila[Descripcion]</td>
<td><a href='?pag=mantenimiento_fallas.php&idcat=$fila[IdFalla]'><img src=img/edit.jpg width=25 height=25 title='Modificar Falla'></a></td>
</tr>

    ";
  
    	
    } 
    $valor.="</table>
<input type=submit name=eliminar value=Eliminar class=boton>

    </form>" ;  
    return $valor;
}

	
	}

}
 ?>

