<?php
@session_start(); 
if ($_SESSION["usuario2"]["Tipo"]!='Administrador') {
header("Location:login.php");
}else{
 ?>
<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}
?>
<style type="text/css">
    
    .blue-form3 { 
    border:3px solid #3E83C9; 
    margin-top: 0px; 
    margin-bottom: 10px; 
    font-size:80%; 
    font-weight: bold;
     width: 100%;
    background-color: white;
 /*establece la altura máxima, lo que no entre quedará por debajo y saldra la barra de scroll*/

} 
.blue-form3 th{ 
    border-bottom:3px solid #999; 
    width: auto;
    background-color:#9B0B0D;
    color: white; 
}
</style>
<?php


 $valor=$_GET["valor"];

 

if ($valor!=''){
include_once("conexion.php");
$sql="SELECT
    `equipos`.`IdEquipo`
    , `equipos`.`NombreEquipo`
    , `equipos`.`Descripcion`
    , `equipos`.`NumeroSerie`
    , `equipos`.`Estado`
    , `equipos`.`Fecha_Registro`
    , `marcas`.`Marca`
    , `tiposequipo`.`Tipo`
    , `carreras`.`Carrera`
    , `modelos`.`Modelo`
FROM
    `proyecto2019_5`.`equipos`
    INNER JOIN `proyecto2019_5`.`marcas` 
        ON (`equipos`.`IdMarca` = `marcas`.`IdMarca`)
    INNER JOIN `proyecto2019_5`.`tiposequipo` 
        ON (`equipos`.`IdTipo` = `tiposequipo`.`IdTipo`)
    INNER JOIN `proyecto2019_5`.`carreras` 
        ON (`equipos`.`IdCarrera` = `carreras`.`IdCarrera`)
    INNER JOIN `proyecto2019_5`.`modelos` 
        ON (`equipos`.`IdModelo` = `modelos`.`IdModelo`)
where NombreEquipo like '$valor%' or Tipo like '$valor%' or Marca like '$valor%' or Carrera like '$valor%' or Modelo like '$valor%';
        ";
if ($conexion->query($sql)==TRUE) {
	$resultado=$conexion->query($sql);
	
if ($resultado->num_rows>0) {
$valor=' ';
$valor.="<br><form method=post>";
$valor.="<input type=submit  name=Ndisponible value='No disponible' class=boton2>
<input type=submit  name=Sdisponible value='Disponible' class=boton2><br><br>";
$valor.="<table class=blue-form3 cellpadding=8 width=100%>
<tr>
<th width='1%'>ID</th>
<th>Nombre</th>
<th>N° <br>Serie</th>
<th>Tipo</th>
<th>Carrera</th>
<th>Estado</th>
<th width='15%'>Descripcion</th>
<th >Fecha de Registro</th>
<th></th>
</tr>
";

	while ($fila=$resultado->fetch_assoc()) {
		$valor.="
<tr>
<td >
<input type=checkbox name=equipos[] class=checkbox value='$fila[IdEquipo]' ></td>";
		$valor.="
<td>$fila[NombreEquipo]</td>
<td>$fila[NumeroSerie]</td>
<td>$fila[Tipo]</td>
<td> $fila[Carrera]</td>
<td>$fila[Estado]</td>
<td >Marca:$fila[Marca]<br>Modelo: $fila[Modelo]<br>$fila[Descripcion]</td>
<td >$fila[Fecha_Registro]</td>
<td><a href='?pag=modificar_equipos.php&idcat=$fila[IdEquipo]'><img src=img/edit.jpg width=25 height=25 title='Modificar Registro'></a>

    </td>
</tr>

	";
	 

	}
	$valor.="</table></form>";
	echo $valor;
}else{
	echo "<h1>No hay Registros que coincidad con la busqueda</h1>";
	include_once("todo_equipo.php");
}
}else{
	include_once("todo_equipo.php");
	
}


        //Realizamos la búsqueda de q en los registros
    }else{
        include_once("todo_equipo.php");
        }
    }
  ?>

