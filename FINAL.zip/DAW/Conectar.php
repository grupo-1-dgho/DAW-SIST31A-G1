<?php 

include 'credenciales.php';  
class Conexion{
    protected $conn;   
    
     const SALT = 'EstoEsUnSalt';//llave para encriptar 
    public function Conexion(){  
     $this->conn=new mysqli(SERVIDOR,USUARIO,CONTRA,BASEDEDATOS);  
    }  
     
     public function desconectar(){  
          $this->conn->close();  
     }  
     
     public function consultar($sql){  
          $this->Conexion();  
          $res = $this->conn->query($sql);            
        $this->desconectar();  
          return $res;  
     }  
     
     public function ejecutar($sql){  
          $this->Conexion();  
         
         if ($this->conn->query($sql)==TRUE){           
        $this->desconectar();  
          return true;  }}
          



//login


    

            // clave encriptada.     
            


    function SQLsegura($strVar){ 
        $banned = array("select", "drop","|","'", ";", "--", "insert","delete", "xp_");      
        $vowels = $banned; 
        $no = str_replace($vowels, "", $strVar); 
        $final = str_replace( "'","",$no); 
        return $final; 
    }//End Function 

    public static function encriptar($password) { 
        return hash('sha512', self::SALT . $password); 
    } 
     
     
    public static function verificar($password, $hash) { 
        return ($hash == self::hash($password)); 
    } 
     
  }  


     ?>