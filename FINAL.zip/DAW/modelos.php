<?php
@session_start(); 
if ($_SESSION["usuario2"]["Tipo"]!='Administrador') {
header("Location:login.php");
}else{
 ?>
<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>

	<?php
include('conexion.php');
?>

	
		<?php
if (isset($_POST['ok'])) {

	$modelo=$_POST['modelo'];
	$IdMarca=$_POST["IdMarca"];
	$consultar="select * from Modelos where Modelo='$modelo' and IdMarca='$IdMarca'";
	$r1=$conexion->query($consultar);
	if ($r1->num_rows>0) {
		echo "Error: Ya existe un modelo con ese nombre y esa marca!";   
}else{
	$inser= "INSERT INTO Modelos (Modelo,IdMarca) VALUES ('$modelo','$IdMarca')";

	if ($conexion->query($inser)==TRUE) {
 	
						echo "<h1>Registro Insertado</h1>";
						 }else{
echo "<h1>Registro No Insertado</h1>";
	}
}

}elseif (isset($_POST["eliminar"]) and isset($_POST['id']) ) {
	$ids=$_POST['id'];
foreach ($ids as $id) {
$delete= "Delete from Modelos where IdModelo='$id'";
$conexion->query($delete);
}

		}
?>
		<?php  
		$marcas="select * from Marcas ";
		$r_m=$conexion->query($marcas);
		if($r_m->num_rows==0){
			echo "<H1>DEVEN EXIXTIR MARCAS PARA INGRESAR MODELOS</H1>";
		}else{
			echo "<form method='post'>
		<table class=blue-form>
	<tr>
	<th colspan=2>Agregar modelos de equipos</th>
		</tr>
		<tr>
			<td>Seleccione Una Marca</td>
			<td>";
echo "<select name=IdMarca class=select>";
	while ($row2=$r_m->fetch_assoc()) {
		echo "
<option value=".$row2["IdMarca"].">".$row2["Marca"]."</option>";
}
echo "</select>";


			echo "</td>
		</tr>	
		<tr>
			<td><input type='text' name='modelo' placeholder='Ingrese un modelo...' required='' autofocus class='texto'></td>
			<td><input type='submit' name='ok' class=boton value='Aceptar'></td>
		</tr>	
		</table>
	</form>	
	<br>
	<form method='post'><table class='blue-form2'>
		<tr>
			<th >Modelos</th><th >Marca</th><th ></th>
		</tr>";
$modelos="SELECT
    `modelos`.`Modelo`
    , `marcas`.`Marca`
    , `modelos`.`IdModelo`
FROM
    `proyecto2019_5`.`modelos`
    INNER JOIN `proyecto2019_5`.`marcas` 
        ON (`modelos`.`IdMarca` = `marcas`.`IdMarca`);";
if ($conexion->query($modelos)==TRUE) {
	$resultado3=$conexion->query($modelos);
	while ($row=$resultado3->fetch_assoc()) {
		echo "<tr>
			<td>
			<input type=checkbox name=id[] value=$row[IdModelo]>$row[Modelo]	
			</td>

			<td>
			$row[Marca]	
			</td>
			<td><a href='?pag=modificar_modelos.php&idcat=$row[IdModelo]'><img src=img/edit.jpg width=25 height=25 title='Modificar Registro'></a>
	</td>
		</tr>";
	}
}
		echo "
		<tr>
			<th colspan=3><input type=submit name=eliminar class=boton value=Eliminar></th>
		</tr>
	</table></form>";
}
}
	?>








	