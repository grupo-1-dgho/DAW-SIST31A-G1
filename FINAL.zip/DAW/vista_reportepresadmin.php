<?php
@session_start();
include_once'clase_reportes.php';
$ob=new Reportes();
$s=$_SESSION["usuario2"]["IdUsuario"];
echo $ob->RprestamosA(); 

 ?>