<?php
@session_start(); 
if ($_SESSION["usuario2"]["Tipo"]!='Administrador') {
header("Location:login.php");
}else{
 ?>
<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>

	<?php
include('conexion.php');
?>
<?php
if (isset($_POST['ok'])) {
	$horai=$_POST['horai'];
$horaf=$_POST['horaf'];
include_once'conexion.php';
$R=$conexion->query("Select * from Horarios_Prestamo where HoraI='$horai'");
if ($R->num_rows>0) {
	echo "Ya existe esa hora inicial";
}else{
if ($horai>=$horaf) {
	echo "La hora final debe ser mayor a la inicial<br>";
}else{
	$inser= "INSERT INTO Horarios_Prestamo (HoraI, HoraF) VALUES ('$horai','$horaf')";

	if ($conexion->query($inser)==TRUE) {
 	
						echo "<h1>Registro Insertado</h1>";
						 }else{
echo "<h1>Registro No Insertado</h1>";
}
}}
}if (isset($_POST["eliminar"]) and isset($_POST['id']) ) {
	$ids=$_POST['id'];
foreach ($ids as $id) {
$delete= "Delete from Horarios_Prestamo where IdHorario='$id'";
$conexion->query($delete);
}

		}

?>

	<form method='post'>
		<table class="blue-form">
	<tr>
	<th colspan="2">Agregar Horarios de prestamos</th>
		</tr>
		<tr>
			<td>Hora Inicial</td><td><input type="time" name="horai"  required='' autofocus class="texto" min="07:00" max="18:00"></td></tr>
			<tr>
				<td>Hora final</td><td><input type="time" name="horaf"  required='' autofocus class="texto" min="07:00" max="18:00"></td></tr><tr>
			<td colspan="2" align="center"><input type="submit" name="ok" class=boton value="Aceptar"></td>
		</tr>	
		</table>
	</form>	
	<font color="BLACK"><i>AGREGAR HORA EN FROMATO DE 24 HORAS</i></font>
	<br><br><br>
	<form method="post"><table class="blue-form2">
		<tr>
			<th></th>
			<th>Hora Inicio</th>
			<th>Hora Fin</th>
			<th></th>
		</tr>
		
		<?php  
$hora="Select * from Horarios_Prestamo";
if ($conexion->query($hora)==TRUE) {
	$resultado2=$conexion->query($hora);
	while ($row=$resultado2->fetch_assoc()) {
		echo "<tr>
			<td>
			<input type=checkbox name=id[]  value=$row[IdHorario]>	
			</td>
			<td>$row[HoraI]</td>
			<td>
			$row[HoraF]	
			</td>
	<td><a href='?pag=modificarhorarios.php&idcat=$row[IdHorario]'><img src=img/edit.jpg width=25 height=25 title='Modificar Registro'></a>
	</td>
		</tr>";
	}
}
		?>
		<tr>
			<th colspan="4"><input type="submit" name="eliminar" class="boton" value="Eliminar"></th>
		</tr>
	</table></form>
<?php
}
?>








	