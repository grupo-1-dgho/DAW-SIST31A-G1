<?php
@session_start(); 
if ($_SESSION["usuario2"]["Tipo"]!='Administrador') {
header("Location:login.php");
}else{
 ?>
<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>



<script type="text/javascript">
function xmlhttp(){
        var xmlhttp;
        try{xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");}
        catch(e){
            try{xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");}
            catch(e){
                try{xmlhttp = new XMLHttpRequest();}
                catch(e){
                    xmlhttp = false;
                }
            }
        }
        if (!xmlhttp)
                return null;
            else
                return xmlhttp;
    }

function buscar(){
        var query = document.getElementById('busqueda').value;
        var A = document.getElementById('resultados');
        var ajax = xmlhttp();
 
        ajax.onreadystatechange=function(){
                if(ajax.readyState==4 && ajax.status==200){
                        
                        A.innerHTML = ajax.responseText;
                    }
            }
ajax.open("GET","busqueda_equipos.php?valor="+query);

        ajax.send(null);
        return false;
    }
</script>

<style type="text/css">
    
    .text{
    /*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
width: 40%;
border-radius: 5px;
height: 30px;
border:1px black solid;
font-size: 15px;
 font-family: Comic Sans MS,Arial,Verdana;
        }
.selec{
 width: 30%;
border-radius: 5px;
height: 25px;
border:1px black solid;
font-size: 15px;
 font-family: Comic Sans MS,Arial,Verdana;
        }
        .text:focus{
    border:3px solid green;
}
</style>
	<?php
if (isset($_POST["Ndisponible"]) and isset($_POST['equipos'])) {
    
   
        $ids=$_POST["equipos"];
include_once("conexion.php");
foreach ($ids as $id) {
$update="update Equipos set Estado='No Disponible' where IdEquipo='$id'";
$conexion->query($update);
}
  echo "<script>alert('Modificación de datos exitoso');</script>";


    
    }
elseif (isset($_POST["Sdisponible"]) and isset($_POST['equipos']) )  {
    
      $ids=$_POST["equipos"];
include_once("conexion.php");
foreach ($ids as $id) {
$update="update Equipos set Estado='Disponible' where IdEquipo='$id'";
$conexion->query($update);
}
  echo "<script>alert('Modificación de datos exitoso');</script>";



    
}



 ?>
<legend>Buscar Equipos</legend>

<input type=text name=dato required=required class=text id=busqueda onKeyUp=buscar(); placeholder="Escribe aquí..." autofocus="">

<div id=resultados class=nocss>
    <?php include_once("conexion.php");
        $sql2="SELECT
    `equipos`.`IdEquipo`
    , `equipos`.`NombreEquipo`
    , `equipos`.`Descripcion`
    , `equipos`.`NumeroSerie`
    , `equipos`.`Estado`
    , `equipos`.`Fecha_Registro`
    , `marcas`.`Marca`
    , `tiposequipo`.`Tipo`
    , `carreras`.`Carrera`
    , `modelos`.`Modelo`
FROM
    `proyecto2019_5`.`equipos`
    INNER JOIN `proyecto2019_5`.`marcas` 
        ON (`equipos`.`IdMarca` = `marcas`.`IdMarca`)
    INNER JOIN `proyecto2019_5`.`tiposequipo` 
        ON (`equipos`.`IdTipo` = `tiposequipo`.`IdTipo`)
    INNER JOIN `proyecto2019_5`.`carreras` 
        ON (`equipos`.`IdCarrera` = `carreras`.`IdCarrera`)
    INNER JOIN `proyecto2019_5`.`modelos` 
        ON (`equipos`.`IdModelo` = `modelos`.`IdModelo`)
;
        ";
if ($conexion->query($sql2)==TRUE) {
    $resultado2=$conexion->query($sql2);
    
if ($resultado2->num_rows>0) {
$valor=' ';
$valor.="<br><form method=post>";
$valor.="<input type=submit  name=Ndisponible value='No disponible' class=boton2>
<input type=submit  name=Sdisponible value='Disponible' class=boton2><br><br>";
$valor.="<table class=blue-form3 cellpadding=8 width=100%>
<tr>
<th width='1%'>ID</th>
<th>Nombre</th>
<th>N° <br>Serie</th>
<th>Tipo</th>
<th>Carrera</th>
<th>Estado</th>
<th width='15%'>Descripcion</th>
<th >Fecha de Registro</th>
<th></th>
</tr>
";

    while ($fila=$resultado2->fetch_assoc()) {
        $valor.=" 
<tr>
<td >
<input type=checkbox name=equipos[] class=checkbox value='$fila[IdEquipo]' ></td>";
        $valor.="
<td>$fila[NombreEquipo]</td>
<td>$fila[NumeroSerie]</td>
<td>$fila[Tipo]</td>
<td> $fila[Carrera]</td>
<td>$fila[Estado]</td>
<td >Marca:$fila[Marca]<br>Modelo: $fila[Modelo]<br>$fila[Descripcion]</td>
<td >$fila[Fecha_Registro]</td>
<td><a href='?pag=modificar_equipos.php&idcat=$fila[IdEquipo]'><img src=img/edit.jpg width=25 height=25 title='Modificar Registro'></a>
    </td>
</tr>

    ";
  
        
    } $valor.="</table></form>" ;  echo "$valor";}}
}
    ?>
</div>




