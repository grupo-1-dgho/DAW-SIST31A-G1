<?php 
include 'Conectar.php';
class Prestamos{
	protected $C;
	public function Prestamos(){
		//inicializamos lo necesario
		$this->C=new Conexion();
	}
public function Mostrar(){
	$sql="SELECT
    `equipos`.`IdEquipo`
    , `equipos`.`NombreEquipo`
    , `equipos`.`NumeroSerie`
    , `equipos`.`Descripcion`
    , `equipos`.`Estado`
    , `marcas`.`Marca`
    , `modelos`.`Modelo`
    , `carreras`.`Carrera`
FROM
    `proyecto2019_5`.`equipos`
    INNER JOIN `proyecto2019_5`.`marcas` 
        ON (`equipos`.`IdMarca` = `marcas`.`IdMarca`)
    INNER JOIN `proyecto2019_5`.`modelos` 
        ON (`equipos`.`IdModelo` = `modelos`.`IdModelo`)
    INNER JOIN `proyecto2019_5`.`carreras` 
        ON (`equipos`.`IdCarrera` = `carreras`.`IdCarrera`)
      WHERE Estado='Disponible';
        ";
       
        $resultado=$this->C->consultar($sql);
        if ($resultado->num_rows>0) {
        	
        	$mostrar='';
        	$mostrar.="<form method=post><table class=blue-form3>
<th>Nombre <br>del Equipo</th>
<th>N° <br>Serie</th>
<th>Marca</th>
<th>Modelo</th>
<th>Descripcion</th>
<th>Carreras</th>
<th>Ver <br>Fallas</th>
<th >Prestar</th>";

while ($filas=$resultado->fetch_assoc()) {
	$mostrar.="<tr>";
$mostrar.="
<td>$filas[NombreEquipo]</td>
<td>$filas[NumeroSerie]</td>
<td>$filas[Marca]</td>
<td>$filas[Modelo]</td>
<td>$filas[Descripcion]</td>
<td>$filas[Carrera]</td>
<td><a href='?pag=fallasporequipo_docente.php&idcat=$filas[IdEquipo]'><H4>VER</H4></a></td>
<td><a href='?pag=realizar_prestamo.php&idcat=$filas[IdEquipo]'><H4>PRESTAR</H4></a></td>
";

	$mostrar.="</tr>";
}

        	$mostrar.="</table></form>";

        	return $mostrar;
        }
}	


public function mostrarfallas($id){
		$sql1="select * from fallas_equipo where IdEquipo='$id';";
		$sql2="   SELECT
    `equipos`.`NombreEquipo`
    , `marcas`.`Marca`
    , `modelos`.`Modelo`
    , `equipos`.`NumeroSerie`
FROM
    `proyecto2019_5`.`equipos`
    INNER JOIN `proyecto2019_5`.`marcas` 
        ON (`equipos`.`IdMarca` = `marcas`.`IdMarca`)
    INNER JOIN `proyecto2019_5`.`modelos` 
        ON (`equipos`.`IdModelo` = `modelos`.`IdModelo`)
   
        WHERE equipos.IdEquipo='$id';";
		$result=$this->C->Consultar($sql1);
		$resultado2=$this->C->Consultar($sql2);
		if ($result->num_rows>0) {
   $row=$resultado2->fetch_assoc();
$valor="<form method=post>
<h3><table class=blue-form3 cellpadding=8 width=100%><tr><td>
El equipo $row[NombreEquipo] $row[Marca] $row[Modelo], con número de serie $row[NumeroSerie] contiene las siguientes fallas:
</td></tr></table></h3>

";
$valor.="<table class=blue-form3 cellpadding=8 width=100%>
<tr>
<th >Fecha de reporte</th>
<th >Descripción</th>
</tr>
";
while ($fila=$result->fetch_assoc()) {
        $valor.=" 
<tr>";
         $valor.="

<td>$fila[Fechareporte]</td>
<td >$fila[Descripcion]</td>

</tr>
 ";
    } 
    $valor.="</table>
</form>" ;  
    return $valor;
}else{
	$valor="<h1>NO HAY FALLAS EN ESTE EQUIPO</H1>";
return $valor;
}
}

	public function prestar($id){
		$sql="select * from aulas";
		$aulas=$this->C->Consultar($sql);
        $hora="select * from Horarios_prestamo";
        $horarios=$this->C->Consultar($hora);
        $hora2="select * from Horarios_prestamo";
        $horarios2=$this->C->Consultar($hora2);
		$respuesta="<form method=post>
 	<table class=blue-form2>
 		<tr>
 	<th colspan=2>Realizar Prestamo</th>
</tr>
<tr>
	<td>Aula del prestamo</td>
			<td><select name=IdAula class=select>";
	while ($row=$aulas->fetch_assoc()) {
		$respuesta.= "
<option value=$row[IdAula]>$row[Aula]</option>";
}
$respuesta.= "</select></td></tr><tr><td>
Fecha del prestamo:</td><td><input type=date name=fecha class=texto required=required></td></tr>
<tr><td>Hora Inicio:</td>
<td><select name=inicio class=select id=inicio onchange=horas(); >";
    while ($row2=$horarios->fetch_assoc()) {
        $respuesta.= "
<option value=$row2[HoraI]>$row2[HoraI]</option>";
}
$respuesta.= "</select></td>
</tr>
<tr ><td>Hora Final:</td>
<td id=resultado><select name=fin class=select>";
    while ($row3=$horarios2->fetch_assoc()) {
        $respuesta.= "
<option value=$row3[HoraF]>$row3[HoraF]</option>";
}
$respuesta.= "</select></td>
</tr>
<tr><th colspan=2><input type=submit class=boton name=ok value=Guardar></th></tr>
";

$respuesta.="</table></form>";
return $respuesta;
	}
	public function prestamoexistente($id,$fecha,$inicio,$fin){
    $sql="SELECT
    `usuarios`.`Nombre`
    , `usuarios`.`Apellido`
    , `aulas`.`Aula`
    , `prestamos`.`IdPrestamo`
    , `prestamos`.`IdEquipo`
    , `prestamos`.`IdUsuario`
    , `prestamos`.`Fecha`
    , `prestamos`.`HoraInicio`
    , `prestamos`.`HoraFin`
    , `prestamos`.`HoraTotal`
    , `prestamos`.`EstadoPrestamo`
FROM
    `proyecto2019_5`.`prestamos`
    INNER JOIN `proyecto2019_5`.`aulas` 
        ON (`prestamos`.`IdAula` = `aulas`.`IdAula`)
    INNER JOIN `proyecto2019_5`.`equipos` 
        ON (`prestamos`.`IdEquipo` = `equipos`.`IdEquipo`)
    INNER JOIN `proyecto2019_5`.`usuarios` 
        ON (`prestamos`.`IdUsuario` = `usuarios`.`IdUsuario`)

WHERE  `prestamos`.`IdEquipo`='$id' AND Fecha='$fecha' AND (('$inicio'  BETWEEN HoraInicio AND HoraFin)OR ('$fin'  BETWEEN HoraInicio AND HoraFin)
 OR (HoraInicio BETWEEN '$inicio' AND '$fin' ) OR (HoraFin BETWEEN '$inicio' AND '$fin' )
) 
AND EstadoPrestamo='Activo' AND HoraFin!='$inicio';";
        $consultar=$this->C->Consultar($sql);
if ($consultar->num_rows>0) {
	$c=$consultar->fetch_assoc();
$mensaje="<script>
titulo='Este equipo se encuentra actualmente prestado por:';
msg='$c[Nombre] $c[Apellido] en el aula $c[Aula]  en los horarios $c[HoraTotal]';
    aler2(titulo,msg);</script>
    ";
  
    return $mensaje;
}

else{
	return FALSE;
}}
public function aula($fecha,$inicio,$fin,$aula){
    $sql="SELECT
    `usuarios`.`Nombre`
    , `usuarios`.`Apellido`
    , `aulas`.`Aula`
    , `prestamos`.`IdPrestamo`
    , `prestamos`.`IdEquipo`
    , `prestamos`.`IdUsuario`
    , `prestamos`.`Fecha`
    , `prestamos`.`HoraInicio`
    , `prestamos`.`HoraFin`
    , `prestamos`.`HoraTotal`
    , `prestamos`.`EstadoPrestamo`
FROM
    `proyecto2019_5`.`prestamos`
    INNER JOIN `proyecto2019_5`.`aulas` 
        ON (`prestamos`.`IdAula` = `aulas`.`IdAula`)
    INNER JOIN `proyecto2019_5`.`equipos` 
        ON (`prestamos`.`IdEquipo` = `equipos`.`IdEquipo`)
    INNER JOIN `proyecto2019_5`.`usuarios` 
        ON (`prestamos`.`IdUsuario` = `usuarios`.`IdUsuario`)

WHERE  Fecha='$fecha' AND (('$inicio'  BETWEEN HoraInicio AND HoraFin)OR ('$fin'  BETWEEN HoraInicio AND HoraFin)
 OR (HoraInicio BETWEEN '$inicio' AND '$fin' ) OR (HoraFin BETWEEN '$inicio' AND '$fin' )
) 
AND EstadoPrestamo='Activo' and `prestamos`.`IdAula`='$aula'  AND HoraFin!='$inicio';";
      $consultar=$this->C->Consultar($sql);
if ($consultar->num_rows>0) {
    $c=$consultar->fetch_assoc();
$mensaje="<script>
titulo='El aula $c[Aula] se encuentra utilizada por: ';
msg='$c[Nombre] $c[Apellido] en los horarios $c[HoraTotal]';
    aler2(titulo,msg);</script>
    ";
    
 
    return $mensaje;
}
else{
    return FALSE;
}
}
public function carrera($idequipo,$carrera){
    $sql1="SELECT
    `equipos`.`IdEquipo`
    , `carreras`.`Carrera`
FROM
    `proyecto2019_5`.`equipos`
    INNER JOIN `proyecto2019_5`.`carreras` 
        ON (`equipos`.`IdCarrera` = `carreras`.`IdCarrera`) where IdEquipo='$idequipo';";
   $consultar=$this->C->Consultar($sql1);
   $fila=$consultar->fetch_assoc();
$careraequipo=strtolower($fila["Carrera"]);
   if (($careraequipo=='patrimonio' or $careraequipo=='patrimonio cultural' or $careraequipo=='gestion de patrimonio patrimonio cultural' or $careraequipo=='gestión de patrimonio y cultura') and $carrera!=$careraequipo) {
       
       return TRUE;
   }else{
    return FALSE;
   }

}

public function agregar($tabla,$campos,$valores){
$sql="INSERT INTO $tabla ($campos) Values ($valores)";
$resultado=$this->C->ejecutar($sql);
if ($resultado==TRUE) {
	return TRUE;
}else{
return FALSE;
}

}
public function prestamosdocente($id){
    $sql="SELECT
    `prestamos`.`IdPrestamo`
    , `prestamos`.`IdUsuario`
    , `prestamos`.`EstadoPrestamo`
    , `prestamos`.`HoraTotal`
    , `prestamos`.`Fecha`
    , `aulas`.`Aula`
    , `equipos`.`NombreEquipo`
    , `equipos`.`NumeroSerie`
    , `marcas`.`Marca`
    , `modelos`.`Modelo`
FROM
    `proyecto2019_5`.`prestamos`
    INNER JOIN `proyecto2019_5`.`aulas` 
        ON (`prestamos`.`IdAula` = `aulas`.`IdAula`)
    INNER JOIN `proyecto2019_5`.`equipos` 
        ON (`prestamos`.`IdEquipo` = `equipos`.`IdEquipo`)
    INNER JOIN `proyecto2019_5`.`marcas` 
        ON (`equipos`.`IdMarca` = `marcas`.`IdMarca`)
    INNER JOIN `proyecto2019_5`.`modelos` 
        ON (`equipos`.`IdModelo` = `modelos`.`IdModelo`) 
    where IdUsuario='$id' and EstadoPrestamo='Activo'";
    $resultado=$this->C->consultar($sql);
    if ($resultado->num_rows>0) {
     $tabla='';   
$tabla.= "<table class=blue-form3><form method=post>
<tr align=center>
<th>Nombre del Equipo</th>
<th>Marca</th>
<th>Modelo</th>
<th>N°<br>Serie</th>
<th>Fecha</th>
<th>Hora del prestamo</th>
<th>Aula</th>
<th>Devolver</th>

</tr>";

while ($filas=$resultado->fetch_assoc()) {
   $tabla.= "<tr>";
$tabla.= "
<input type=hidden name=idprestamo value=$filas[IdPrestamo]>
<td>$filas[NombreEquipo]</td>
<td>$filas[Marca]</td>
<td>$filas[Modelo]</td>
<td>$filas[NumeroSerie]</td>
<td>$filas[Fecha]</td>
<td>$filas[HoraTotal]</td>
<td>$filas[Aula]</td>
<td align=center><input type=submit value=Devolver name=devolver class=boton></td>
";
   $tabla.= "</tr>";
}
$tabla.= "</form></table>";
   return $tabla; 
}else{
    $mensaje="NO EXISTEN PRESTAMOS ACTIVOS";
    return $mensaje;
}
}
public Function devolver($id){
 $update="UPDATE Prestamos set EstadoPrestamo='No Activo' where IdPrestamo='$id'";
 $this->C->ejecutar($update);
 
}
public function prestamosadministrador($sql){
   
    $resultado=$this->C->consultar($sql);
    if ($resultado->num_rows>0) {
     $tabla='';   
$tabla.= "<table class=blue-form3><form method=post>
<tr >
<th>Nombre<br> del Equipo</th>
<th>Marca</th>
<th>Modelo</th>
<th>N°<br>Serie</th>
<th>Fecha</th>
<th>Hora del prestamo</th>
<th>Aula</th>
<th>Docente</th>
<th>carnet</th>


</tr>";

while ($filas=$resultado->fetch_assoc()) {
   $tabla.= "<tr >";
$tabla.= "

<td>$filas[NombreEquipo]<br>  <br></td>
<td  >$filas[Marca]</td>
<td >$filas[Modelo]</td>
<td >$filas[NumeroSerie]</td>
<td >$filas[Fecha]</td>
<td >$filas[HoraTotal]</td>
<td  >$filas[Aula]</td>
<td>$filas[Nombre] $filas[Apellido]</td>
<td  >$filas[Carnet]</td>
";
   $tabla.= "</tr>";
}
$tabla.= "</form></table>";
   return $tabla; 
}else{
    $mensaje="NO EXISTEN PRESTAMOS ACTIVOS";
    return $mensaje;
}
}
public function findesemana($fecha){
    $f=strtotime($fecha);
    $dia=date("l",$f);
    if ($dia=='Sunday' or $dia=='Saturday') {
        return "NO PUEDE HACER PRESTAMOS EN DIA SABADO O DOMINGO";
    }else{
   return FALSE;}
}
}
 ?>

