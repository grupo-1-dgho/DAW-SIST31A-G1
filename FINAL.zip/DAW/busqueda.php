<?php
@session_start(); 
if ($_SESSION["usuario2"]["Tipo"]!='Administrador') {
header("Location:login.php");
}else{
 ?>
<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}
?>
<?php


 $valor=$_GET["valor"];
if ($valor!=''){
include_once("conexion.php");
$sql="SELECT
    `usuarios`.`IdUsuario`
    , `usuarios`.`Carnet`
    , `usuarios`.`Nombre`
    , `usuarios`.`Apellido`
    , `usuarios`.`E_mail`
    , `usuarios`.`Direccion`
    , `usuarios`.`Fecha_Nacimiento`
    , `usuarios`.`Fotografia`
    , `usuarios`.`Tipo`
    , `usuarios`.`Contra`
    , `carreras`.`Carrera`
    , `usuarios`.`Estado`
FROM
    `proyecto2019_5`.`usuarios`
    INNER JOIN `proyecto2019_5`.`carreras` 
        ON (`usuarios`.`IdCarrera` = `carreras`.`IdCarrera`)

where Carnet like '$valor%' and   Tipo!='Administrador'
        ;";
if ($conexion->query($sql)==TRUE) {
	$resultado=$conexion->query($sql);
	
if ($resultado->num_rows>0) {
$valor=' ';
$valor.="<br><form method=post><input type=submit name=btndesactivar value=Desactivar class=boton2>
<input type=submit name=btnactivar value=Activar class=boton2><br><br>";
	while ($fila=$resultado->fetch_assoc()) {
		$valor.="<table class=blue-form cellpadding= 10>
<tr>
<th colspan=2>
<input type=checkbox name=usuarios[] class=checkbox value='$fila[IdUsuario]'>Usuario</th></tr>";
		$valor.="

<tr>
<td rowspan=10>
<img src=$fila[Fotografia] width=200 height=250></td>
<td>Carnet: $fila[Carnet]</td>
</tr>
<tr>
<td>Nombre: $fila[Nombre]</td>
</tr>
<tr>
<td>Apellido: $fila[Apellido]</td>
</tr>
<tr>
<td>E-mail: $fila[E_mail]</td>
</tr>

<tr>
<td >Carrera: $fila[Carrera]</td>
</tr>
<tr>
<td >Tipo: $fila[Tipo]</td>
</tr>

<tr>
<td >Estado: $fila[Estado]</td>
</tr>
	";
	 

	}
	$valor.="</table></form>";
	echo $valor;
}else{
	echo "<h1>No hay Registros que coincidad con la busqueda</h1>";

}
}else{
	
	include_once("todos_usuarios.php");
}


        //Realizamos la búsqueda de q en los registros
    }else{
    	
    	include_once("todos_usuarios.php");
    }
}
  ?>

