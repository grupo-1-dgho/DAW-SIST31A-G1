<!DOCTYPE html>
<html>
<head>

	<style type="text/css">
@charset "utf-8"; 
/* CSS Document */ 

ul.menu { 
    list-style-type: none; 
    margin: 0; 
    padding: 0; 
    overflow: hidden; 
    background-color: #9B0B0D; 
    width: 95%;
    border-radius: 5px;

} 

ul.menu li { 
    float: center; 
} 

ul.menu li a, .dropbtn { 
    display: inline-block; 
    color: white; 
    text-align: center; 
    padding: 14px 16px; 
    text-decoration: none; 
} 

ul.menu li a:hover, .dropdown:hover .dropbtn { 
    background-color:black ; 
} 

ul.menu li.dropdown { 
    display: inline-block; 
} 

ul.menu .dropdown-content { 
    display: none; 
    position: absolute; 
    background-color: #9B0B0D; 
    min-width: 160px; 
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); 
    z-index: 1; 
} 

ul.menu .dropdown-content a { 
    color: white; 
    padding: 12px 16px; 
    text-decoration: none; 
    display: block; 
    text-align: left; 
} 

ul.menu .dropdown-content a:hover {background-color: black} 

ul.menu .dropdown:hover .dropdown-content { 
    display: block; 
} 


</style>
</head>
<body>
   
<nav><!--solo editen cada el nombre y los link-->
	<ul class="menu">
	<li class=dropdown>
	<a href= "?pag=principal_docente.php">Mi perfil</a>
	</li>
	<li class=dropdown>
		<a href="?pag=buscar_equipo.php">Realizar Prestamo</a>
	</li>
	<li class=dropdown>
		<a href="?pag=verprestamos_docente.php">Ver mis Prestamos</a>
	</li>
  
	<li class=dropdown>
        <a href="reporte_presdocente.php" target="_blank">Reporte de prestamos</a>
    </li>
    <li class=dropdown>
    <a href="login.php">Cerrar</a>
    </li>
</ul></nav>
</body>
</html>

