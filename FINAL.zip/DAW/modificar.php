<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:login.php");
}elseif (!(isset($usaindex))) {
	header("Location:index.php");
}
  
?>
 
<script type="text/javascript">   
	function checkForm(form){         
			      
			 	     
if(form.contra.value.length < 8) { 
msg="Error: La clave debe tener un minimo de 8 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.contra.focus();
return false;       
}  

if(form.contra.value == form.nombre.value) { 
msg="Error: La clave debe ser diferente al nombre !";   
tit="Error!!!";  
aler(tit,msg);          
form.contra.focus();         
return false; 
      }     
re = /[0-9]/;       
if(!re.test(form.contra.value)) {         
aler("Error: la clave debe tener almenos un digito (0-9)!");         
form.contra.focus();         
return false;       } 
re = /[a-z]/;       
if(!re.test(form.contra.value)) {  
msg="Error: La clave debe tener al menos una letra minuscula (a-z)!";   
tit="Error!!!";  aler(tit,msg);  
form.contra.focus();          
return false;       }       
re = /[A-Z]/;       
if (!re.test(form.contra.value)) {  
msg="Error: La clave debe tener al menos una letra mayuscula (A-Z)!";   
tit="Error!!!";  
aler(tit,msg);           
form.contra.focus();          
return false;       
}  
re = /[0-9]/;
if (!re.test(form.carnet.value)) {  
msg="Error: El carnet solo acepta numeros!";   
tit="Error!!!";  
aler(tit,msg);           
form.carnet.focus();          
return false;       
}
if(form.carnet.value.length < 6 || form.carnet.value.length > 6) { 
msg="Error: El carnet tiene que tener 6 números!";   
tit="Error!!!";  
aler(tit,msg);
form.carnet.focus();
return false;       
} 
if(form.nombre.value.length < 3) { 
msg="Error: El nombre tiene que tener al menos 3 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.nombre.focus();
return false;       
}  
if(form.apellido.value.length < 3) { 
msg="Error: El apellido tiene que tener al menos 3 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.apellido.focus();
return false;       
}  
if(form.direccion.value.length < 8 && form.direccion.value.length!=' ' ) { 
msg="Error: La direccion tiene que tener al menos 8 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.direccion.focus();
return false;       
} 
}

     
       </script> 
	
	
<?php  
include 'conexion.php';
$consulta_departamentos="Select * from carreras";
$resultado2=$conexion->query($consulta_departamentos);
$n2=$resultado2->num_rows;
if (isset($_POST["ok"])) {
	$nombre=ucfirst($_POST['nombre']);
	$apellido=ucfirst($_POST['apellido']);
	$carnet=$_POST['carnet'];
	$correo=$_POST['correo'];
	$password=$_POST['contra'];
$_SESSION["contraseña"]=$password;
	include_once'Conectar.php';
	$objeto=New Conexion();
	$contraseña = $objeto->encriptar($password);
	
	$direccion=ucfirst($_POST['direccion']);
	if ($_POST['fecha']!=''){
	$fecha1= strtotime('1960-01-01');
	$fecha2= strtotime('2001-12-31');
$fecha=$_POST['fecha'];
	if (strtotime($fecha)>=$fecha1 and strtotime($fecha)<=$fecha2) {
	
	if($n2>0){
		$IdCarrera=$_POST['departamento'];
$modificar="UPDATE Usuarios set Carnet='$carnet' , Nombre='$nombre' , Apellido='$apellido', E_mail='$correo' , Fecha_Nacimiento='$fecha' , IdCarrera='$IdCarrera' , Contra='$contraseña' , Direccion='$direccion'
where IdUsuario=".$_SESSION["usuario2"]["IdUsuario"]."
";}//carreras
else{
$modificar="UPDATE Usuarios set Carnet='$carnet' , Nombre='$nombre' , Apellido='$apellido', E_mail='$correo' , Fecha_Nacimiento='$fecha' , Contra='$contraseña' , Direccion='$direccion'
where IdUsuario=".$_SESSION["usuario2"]["IdUsuario"]."
";	
}
	include_once("conexion.php");					
 if ($conexion->query($modificar)==TRUE) {
 	$consulta_carreras="Select * from carreras";
$resultado3=$conexion->query($consulta_carreras);
$n3=$resultado3->num_rows;
if ($n3>0) {
	

 	$sql2="SELECT
    `usuarios`.`IdUsuario`
    , `usuarios`.`Carnet`
    , `usuarios`.`Nombre`
    , `usuarios`.`Apellido`
    , `usuarios`.`E_mail`
    , `usuarios`.`Direccion`
    , `usuarios`.`Fecha_Nacimiento`
    , `usuarios`.`Fotografia`
    , `usuarios`.`Tipo`
    , `usuarios`.`IdCarrera`
    , `usuarios`.`Contra`
    , `usuarios`.`Estado`
    , `carreras`.`Carrera`
FROM
    `proyecto2019_5`.`usuarios`
    INNER JOIN `proyecto2019_5`.`carreras` 
        ON (`usuarios`.`IdCarrera` = `carreras`.`IdCarrera`) 
        where contra='$contraseña';";
	$rs=$conexion->query($sql2);
	$todo=$rs->fetch_assoc();
	foreach ($todo as $key => $value) {
		$_SESSION["usuario2"][$key]=$value;
	}
	
	
echo "<script>alert('Datos Actualizados');location.href ='?pag=principal_docente.php';</script>";
}//consulta
else{

 	$sql2="SELECT
    `usuarios`.`IdUsuario`
    , `usuarios`.`Carnet`
    , `usuarios`.`Nombre`
    , `usuarios`.`Apellido`
    , `usuarios`.`E_mail`
    , `usuarios`.`Direccion`
    , `usuarios`.`Fecha_Nacimiento`
    , `usuarios`.`Fotografia`
    , `usuarios`.`Tipo`
    , `usuarios`.`IdCarrera`
    , `usuarios`.`Contra`
    , `usuarios`.`Estado`

FROM
    `proyecto2019_5`.`usuarios`
 
        where contra='$contraseña';";
	$rs=$conexion->query($sql2);
	$todo=$rs->fetch_assoc();
	foreach ($todo as $key => $value) {
		$_SESSION["usuario2"][$key]=$value;
	}
	
	
echo "<script>alert('Datos Actualizados');location.href ='?pag=principal_docente.php';</script>";
}

					
						 }else{

echo "<script>alert('No se pudieron guardar los datos, verifique la información');</script>";
} 

}else{
	echo "<script>msg='verifique que la fecha de nacimiento se encuentre entre (01/01/1960)-(31/12/2001)'; tit='Error'; aler(tit,msg);</script>";
}
}//fecha
else{

if($n2>0){
		$IdCarrera=$_POST['departamento'];
$modificar="UPDATE Usuarios set Carnet='$carnet' , Nombre='$nombre' , Apellido='$apellido', E_mail='$correo' ,  IdCarrera='$IdCarrera' , Contra='$contraseña' , Direccion='$direccion'
where IdUsuario=".$_SESSION["usuario2"]["IdUsuario"]."
";}else{
$modificar="UPDATE Usuarios set Carnet='$carnet' , Nombre='$nombre' , Apellido='$apellido', E_mail='$correo' , Contra='$contraseña' , Direccion='$direccion'
where IdUsuario=".$_SESSION["usuario2"]["IdUsuario"]."
";	
}

	include_once("conexion.php");					
 if ($conexion->query($modificar)==TRUE) {

 	$consulta_carreras="Select * from carreras";
$resultado3=$conexion->query($consulta_carreras);
$n3=$resultado3->num_rows;
if ($n3>0) {
	

 	$sql2="SELECT
    `usuarios`.`IdUsuario`
    , `usuarios`.`Carnet`
    , `usuarios`.`Nombre`
    , `usuarios`.`Apellido`
    , `usuarios`.`E_mail`
    , `usuarios`.`Direccion`
    , `usuarios`.`Fecha_Nacimiento`
    , `usuarios`.`Fotografia`
    , `usuarios`.`Tipo`
    , `usuarios`.`IdCarrera`
    , `usuarios`.`Contra`
    , `usuarios`.`Estado`
    , `carreras`.`Carrera`
FROM
    `proyecto2019_5`.`usuarios`
    INNER JOIN `proyecto2019_5`.`carreras` 
        ON (`usuarios`.`IdCarrera` = `carreras`.`IdCarrera`) 
        where contra='$contraseña';";
	$rs=$conexion->query($sql2);
	$todo=$rs->fetch_assoc();
	foreach ($todo as $key => $value) {
		$_SESSION["usuario2"][$key]=$value;
	}
	
	
echo "<script>alert('Datos Actualizados');location.href ='?pag=principal_docente.php';</script>";
}else{

 	$sql2="SELECT
    `usuarios`.`IdUsuario`
    , `usuarios`.`Carnet`
    , `usuarios`.`Nombre`
    , `usuarios`.`Apellido`
    , `usuarios`.`E_mail`
    , `usuarios`.`Direccion`
    , `usuarios`.`Fecha_Nacimiento`
    , `usuarios`.`Fotografia`
    , `usuarios`.`Tipo`
    , `usuarios`.`IdCarrera`
    , `usuarios`.`Contra`
    , `usuarios`.`Estado`

FROM
    `proyecto2019_5`.`usuarios`
 
        where contra='$contraseña';";
	$rs=$conexion->query($sql2);
	$todo=$rs->fetch_assoc();
	foreach ($todo as $key => $value) {
		$_SESSION["usuario2"][$key]=$value;
	}
	
	
echo "<script>alert('Datos Actualizados');location.href ='?pag=principal_docente.php';</script>";
}

					
						 }else{

echo "<script>alert('No se pudieron guardar los datos, verifique la información');</script>";
} 

}}

?>
<table   class=blue-form><form method=post onsubmit="return checkForm(this)"><tr><th colspan="2" align="center">MODIFICAR DATOS</th></tr>


	<tr>
		
<td >Carnet: </td><td><input type=text name=carnet class=texto value="<?php echo $_SESSION["usuario2"]["Carnet"];?>" required=required  title='El carnet debe tener 6 números' autofocus> </td>
	</tr>
	<tr>
	<td >Nombre:</td><td>  <input type=text name=nombre class=texto value="<?php echo $_SESSION["usuario2"]["Nombre"];?>" required=required title='Debe ingresar almenos 3 caracteres'></td>
		
	</tr>
	<tr>
		<td  >Apellido: </td><td> <input type=text name=apellido class=texto value="<?php echo $_SESSION["usuario2"]["Apellido"];?> " required=required  title='Debe ingresar almenos 3 caracteres'></td>
		
	</tr>
<tr>
	<td >E-mail: </td><td>  <input type=email name=correo class=texto 
		value='<?php echo $_SESSION["usuario2"]["E_mail"];?>' required=required></td>
</tr>
<tr>
	<td>Dirección: </td><td><input type=text name=direccion class=texto value='<?php echo $_SESSION["usuario2"]["Direccion"]; ?>' title='Debe ingresar almenos 8 caracteres'></td>
</tr>
<tr>
	<td >Fecha de nacimiento: </td><td> <input type=date name=fecha class=texto value="<?php

	 echo $_SESSION["usuario2"]["Fecha_Nacimiento"];?> " placeholder='yyyy-mm-dd' ></td>
	
</tr>
<tr>
	<td  >Contraseña: </td><td>  <input type=password name=contra class=texto value="<?php echo $_SESSION["contraseña"];?>" required=required title='Debe ingresar almenos 8 caracteres' ></td>
</tr><tr><td>Departamento:</td><td>
<?php




if ($n2>0) {
	
	echo "<select name=departamento class=select>";
	while ($row2=$resultado2->fetch_assoc()) {
		if ($row2[IdCarrera]==$_SESSION["usuario2"]["IdCarrera"]) {
		echo "
<option value=".$row2["IdCarrera"]." title=".$row2["IdCarrera"]." selected=selected>".$row2["Carrera"]."</option>";
		}elseif ($row2[IdCarrera]!=$Cod_Departamento) {
		echo "
<option value=".$row2["IdCarrera"]." title=".$row2["IdCarrera"].">".$row2["Carrera"]."</option>";}
}
echo "</select>";
}else{
	echo "No hay carreras";
}

 ?></td></tr>
<tr>
	<th colspan="2" align="center">
		<input type=submit name=ok value=Actualizar class=boton >
	</th>
</tr>
</form></table>
