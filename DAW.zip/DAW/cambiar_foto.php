<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:index.php");
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Administrador</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<style type="text/css">
body{
	font-family: Comic Sans MS,Arial,Verdana;
}
/*esto no lo tienen que editar*/
article{
			width: 90%;
			border-radius: 20px;
			padding: 10px;
			box-sizing: border-box;
			background-color: #459AE5;
			margin: 10px;
			text-align: left;
			font-size: 18px;
		}

/*esto no lo tienen que editar*/
section{
			width: 80%;
			border-radius: 20px;
			padding: 10px;
			box-sizing: border-box;
			background-color: #1C2EDE;
		}

form .texto{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 90%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
form .textarea{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 40%;
			border-radius: 15px;
			height: 90px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
form .select{
			width: 40%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
input[type="checkbox"] {
   width: 20px;
   height: 20px;
}
input[type="radio"] {
   width: 20px;
   height: 20px;
}
.radio{
	display: none;
	cursor: pointer;
}
.lbradio{cursor: pointer;}
.boton{
	/*dependiento del texto del boton pueden cambiarle el ancho en el width*/
	border-radius: 20px;
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 100px;
	font-size: 18px;
	background-color: #9B0B0D;
	color: white;
}
.boton2{
	/*dependiento del texto del boton pueden cambiarle el ancho en el width*/
	border-radius: 20px;
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 150px;
	font-size: 18px;
	background-color:#1C2EDE;
	color: white;
}


	</style>


</head>
<body bgcolor="#9B0B0D">
<?php
$Datetime = 'America/El_Salvador';
date_default_timezone_set($Datetime);
echo "Fecha: " . date("d/m/Y")."<br>" ;
echo "Hora: " . date("h:i:s A")."<br>" ;

  ?>
  <form method="post" action="index.php">
  	<input type="submit" name="cerrar" value="Cerrar sesión" class="boton2">
  </form>
<center>
<section>
		<!--aqui se incluye el encabezado. NO BORRAR NUNCA ESTO-->
		<?php
include_once("encabezado.html");
		?>
<!--aqui se incluye el menu. NO BORRAR NUNCA ESTO-->
<?php
if ($_SESSION["usuario"]["cargo"]=="Administrador") {
	include_once("menus/menu_mantenimiento.html");
}elseif ($_SESSION["usuario"]["cargo"]=="Docente") {
	include_once("menus/menu_docente.html");
}



		?>
		<!--aqui se incluye el contenido. ESTO ES LO UNICO DONDE VAN IR EDITANDO-->
<article>
	

<fieldset><legend >Fotografía</legend>

<?php 

if(isset($_POST["guardar"]) && !empty($_POST["guardar"]) && (isset($_FILES["fichero"]))){
	if(is_uploaded_file($_FILES["fichero"]["tmp_name"])){
		$tmp_name=$_FILES["fichero"]["tmp_name"];
		$namee="img/".$_FILES["fichero"]["name"];
		if(is_file($namee)){
			$idunico=time();
			$namee="img/".$idunico."-".$_FILES["fichero"]["name"];
		}
		move_uploaded_file($tmp_name, $namee);
include_once("conexion.php");
$sql="UPDATE Usuarios set
Fotografia='$namee' where IdUsuario='".$_SESSION["usuario2"]["IdUsuario"]."'";
if ($conexion->query($sql)==TRUE) {
	$consulta="SELECT * from Usuarios where IdUsuario='".$_SESSION["usuario2"]["IdUsuario"]."'";
	$rs=$conexion->query($consulta);
	$row=$rs->fetch_assoc();
	foreach ($row as $key => $value) {
		$_SESSION["usuario2"][$key]=$value;
	}
	
echo "<script>location.href ='principal_docente.php';</script>";
}
}else{
	echo "<table cellspacing=15 width=80%>


	<tr>
		<td ><img src=". $_SESSION["usuario2"]["Fotografia"]." width=150 height=200></td>
	</tr>
	
<tr><form method=post ENCTYPE=multipart/form-data>
	<td>
<input type=file name=fichero>
	</td></tr><tr>
	<td>
	<input type=submit name=guardar value=Guadar class=boton>
	</td>
</form></tr>
</table>";
}

}else{
	echo "<table cellspacing=15 width=80%>

	<tr>
		<td ><img src=". $_SESSION["usuario2"]["Fotografia"]." width=150 height=200></td>
	</tr>
	
<tr><form method=post ENCTYPE=multipart/form-data>
	<td>
<input type=file name=fichero>
	</td></tr><tr>
	<td>
	<input type=submit name=guardar value=Guadar class=boton>
	</td>
</form></tr>
</table>";
}

 ?>

</fieldset>
</article>
<!--aqui se incluye el pie de pagina. NO BORRAR NUNCA ESTO-->
			<?php
include_once("pie.html");
		?>
	</section></center>
</section>

</body>
</html>
