<!DOCTYPE html>
<html>
<head>
	<title>encabezado</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<style type="text/css">
body{
	font-family: Comic Sans MS,Arial,Verdana;
}
/*esto no lo tienen que editar*/
article{
			width: 90%;
			border-radius: 20px;
			padding: 10px;
			box-sizing: border-box;
			background-color: #459AE5;
			margin: 10px;
			text-align: left;
			font-size: 18px;
		}

/*esto no lo tienen que editar*/
section{
			width: 80%;
			border-radius: 20px;
			padding: 10px;
			box-sizing: border-box;
			background-color: #1C2EDE;
		}

form .texto{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 90%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
form .textarea{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 40%;
			border-radius: 15px;
			height: 90px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
form .select{
			width: 40%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
input[type="checkbox"] {
   width: 20px;
   height: 20px;
}
input[type="radio"] {
   width: 20px;
   height: 20px;
}
.boton{
	/*dependiento del texto del boton pueden cambiarle el ancho en el width*/
	border-radius: 20px;
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 100px;
	font-size: 18px;
	background-color: #9B0B0D;
	color: white;
}


	</style>


</head>
<body bgcolor="#9B0B0D">

<center>
<section>
		<!--aqui se incluye el encabezado. NO BORRAR NUNCA ESTO-->
		<?php
include_once("encabezado.html");
		?>
<!--aqui se incluye el menu. NO BORRAR NUNCA ESTO-->
<?php
include_once("menu_marca.html");
		?>
		<!--aqui se incluye el contenido. ESTO ES LO UNICO DONDE VAN IR EDITANDO-->
<article><fieldset><legend >Datos del Equipo Nuevo</legend>

<table cellspacing="10">
	<tr>
		<td rowspan="6"><img src="imagen.jpg" width="150" height="200"></td>
		<td>Nombre completo del equipo:<input type="text" name="carnet"></td>
	</tr>
	<tr>
		<td>Numero de serie:<input type="text" name="nombre"></td>
	</tr>
<tr>
	<td>Marca:<input type="text" name="correo"></td>
</tr>
<tr>
	<td>Modelo:<input type="text" name="direccion"></td>
</tr>
<tr>
	<td>Precio:<input type="text" name="fecha"></td>
</tr>
<tr>
	<td>Fecha de ingreso a la instalacion:<input type="text" name="fecha"></td>
</tr>
<tr>
	<td>
	<a href="#">Cambiar foto del equipo</a>	
	</td>
	<td>
	<a href="#">Modificar datos para ingresar equipo</a>	
	</td>
</tr>
<tr>
	<td align="center">
<input type="button" name="button" value="Agregar">

<input type="button" name="button" value="Eliminar">

<input type="button" name="button" value="Salir">
</td>
</tr>
</table>
</fieldset>
</article>
<!--aqui se incluye el pie de pagina. NO BORRAR NUNCA ESTO-->
			<?php
include_once("pie.html");
		?>
	</section></center>
</section>
</body>
</html>