
<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:index.php");
}elseif (!(isset($_SESSION["esadministrador"]))) {
header("Location:principal_docente.php");
}
  
?>
<!DOCTYPE html>
<html>

<head>
	<title>Administrador</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<style type="text/css">
body{
	font-family: Comic Sans MS,Arial,Verdana;
}
/*esto no lo tienen que editar*/
article{
			width: 90%;
			border-radius: 20px;
			padding: 10px;
			box-sizing: border-box;
			background-color: #459AE5;
			margin: 10px;
			text-align: left;
			font-size: 18px;
		}

/*esto no lo tienen que editar*/
section{
			width: 80%;
			border-radius: 20px;
			padding: 10px;
			box-sizing: border-box;
			background-color: #1C2EDE;
		}

.texto{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 90%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
		.texto2{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 40%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
.textarea{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 70%;
			border-radius: 15px;
			height: 70px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
 .select{
			width: 40%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
input[type="checkbox"] {
   width: 20px;
   height: 20px;
}
input[type="radio"] {
   width: 20px;
   height: 20px;
}
.boton{
	/*dependiento del texto del boton pueden cambiarle el ancho en el width*/
	border-radius: 20px;
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 150px;
	font-size: 15px;
	background-color:green;
	color: white;
}
.blue-form { 
    border:3px solid #3E83C9; 
    margin-top: 0px; 
    margin-bottom: 10px; 
    font-size:80%; 
    font-weight: bold;
     width: 70%;
    background-color: white;
 /*establece la altura máxima, lo que no entre quedará por debajo y saldra la barra de scroll*/

} 
.blue-form2 { 
    border:3px solid #3E83C9; 
    margin-top: 0px; 
    margin-bottom: 10px; 
    font-size:80%; 
    font-weight: bold;
     width: 40%;
    background-color: white;
 /*establece la altura máxima, lo que no entre quedará por debajo y saldra la barra de scroll*/

} 
table th{ 
    border-bottom:3px solid #999; 
    width: auto;
    background-color:#9B0B0D;
    color: white; 
} 
table td{ 
    border-bottom:1px solid #999; 
   width: auto;
} 

.boton2{
	/*dependiento del texto del boton pueden cambiarle el ancho en el width*/
	border-radius: 20px;
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 150px;
	font-size: 18px;
	background-color:#1C2EDE;
	color: white;
}
	</style>


</head>
<body bgcolor="#9B0B0D">
<?php
$Datetime = 'America/El_Salvador';
date_default_timezone_set($Datetime);
echo "Fecha: " . date("d/m/Y")."<br>" ;
echo "Hora: " . date("h:i:s A")."<br>" ;
  ?>
  <form method="post" action="index.php" >
  	<input type="submit" name="cerrar" value="Cerrar sesión" class="boton2">
  </form>
<center>
<section>
		<!--aqui se incluye el encabezado. NO BORRAR NUNCA ESTO-->
		<?php
include_once("encabezado.html");
		?>
<!--aqui se incluye el menu. NO BORRAR NUNCA ESTO-->
<?php
include_once("menus/menu_mantenimiento.html");
		?>
		<!--aqui se incluye el contenido. ESTO ES LO UNICO DONDE VAN IR EDITANDO-->
<article><fieldset>
	<?php
include('conexion.php');
?>
<?php
if (isset($_POST['ok'])) {
	$tipo=ucfirst($_POST['tipo']);

	$inser= "INSERT INTO tiposequipo (Tipo) VALUES ('$tipo')";

	if ($conexion->query($inser)==TRUE) {
 	
						echo "<h1>Registro Insertado</h1>";
						 }else{
echo "<h1>Registro No Insertado</h1>";
}

}if (isset($_POST["eliminar"]) and isset($_POST['id']) ) {
	$ids=$_POST['id'];
foreach ($ids as $id) {
$delete= "Delete from tiposequipo where IdTipo='$id'";
$conexion->query($delete);
}
echo "<script>location.href ='agregar_tipos.php';</script>";
		}
?>
	<form method='post'>
		<table class="blue-form">
	<tr>
	<th colspan="2">Agregar Tipos de Equipo</th>
		</tr>
		<tr>
			<td><input type="text" name="tipo" placeholder="Ej: Computadora..." required='' autofocus class="texto"></td>
			<td><input type="submit" name="ok" class=boton value="Aceptar"></td>
		</tr>	
		</table>
	</form>	
	<br>
	<form method="post"><table class="blue-form2">
		<tr>
			<th>Tipos</th>
		</tr>
		
		<?php  
$carreras="Select * from tiposequipo";
if ($conexion->query($carreras)==TRUE) {
	$resultado2=$conexion->query($carreras);
	while ($row=$resultado2->fetch_assoc()) {
		echo "<tr>
			<td>
			<input type=checkbox name=id[]  value=$row[IdTipo]>$row[Tipo]	
			</td>
		</tr>";
	}
}
		?>
		<tr>
			<th><input type="submit" name="eliminar" class="boton" value="Eliminar"></th>
		</tr>
	</table></form>





</fieldset>
</article>
<!--aqui se incluye el pie de pagina. NO BORRAR NUNCA ESTO-->

			<?php
include_once("pie.html");
		?>
	</section></center>
</section>

</body>
</html>




	