<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:index.php");
}elseif (!(isset($_SESSION["esadministrador"]))) {
header("Location:principal_docente.php");
}
  
?>
<!DOCTYPE html>
<html>

<head>
	<link rel="stylesheet" type="text/css" href="css/sweetalert2.css">
<script type="text/javascript" src="css/sweetalert2.min.js.download"></script>
<script type="text/javascript">
	function aler(titulo,mensaje)
	{  Swal.fire({ 
	   type: 'error',   
	    title: titulo,   
	     text: mensaje  
	 }) 
}
</script> 

	<title>Administrador</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<style type="text/css">
body{
	font-family: Comic Sans MS,Arial,Verdana;
}
/*esto no lo tienen que editar*/
article{
			width: 90%;
			border-radius: 20px;
			padding: 10px;
			box-sizing: border-box;
			background-color: #459AE5;
			margin: 10px;
			text-align: left;
			font-size: 18px;
		}

/*esto no lo tienen que editar*/
section{
			width: 80%;
			border-radius: 20px;
			padding: 10px;
			box-sizing: border-box;
			background-color: #1C2EDE;
		}

.texto{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 90%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
		.texto2{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 40%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
.textarea{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 70%;
			border-radius: 15px;
			height: 70px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
 .select{
			width: 45%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
input[type="checkbox"] {
   width: 20px;
   height: 20px;
}
input[type="radio"] {
   width: 20px;
   height: 20px;
}
.boton{
	/*dependiento del texto del boton pueden cambiarle el ancho en el width*/
	border-radius: 20px;
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 160px;
	font-size: 18px;
	background-color:green;
	color: white;
}
.blue-form { 
    border:3px solid #3E83C9; 
    margin-top: 0px; 
    margin-bottom: 10px; 
    font-size:80%; 
    font-weight: bold;
     width: 70%;
    background-color: white;
 /*establece la altura máxima, lo que no entre quedará por debajo y saldra la barra de scroll*/

} 
.blue-form th{ 
    border-bottom:3px solid #999; 
    width: auto;
    background-color:#9B0B0D;
    color: white; 
} 
.blue-form td{ 
    border-bottom:1px solid #999; 
   width: auto;
} 

.boton2{
	/*dependiento del texto del boton pueden cambiarle el ancho en el width*/
	border-radius: 20px;
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 150px;
	font-size: 18px;
	background-color:#1C2EDE;
	color: white;
}
	</style>


</head>
<body bgcolor="#9B0B0D">
<?php
$Datetime = 'America/El_Salvador';
date_default_timezone_set($Datetime);
echo "Fecha: " . date("d/m/Y")."<br>" ;
echo "Hora: " . date("h:i:s A")."<br>" ;
  ?>
  <form method="post" action="index.php" >
  	<input type="submit" name="cerrar" value="Cerrar sesión" class="boton2">
  </form>
<center>
<section>
		<!--aqui se incluye el encabezado. NO BORRAR NUNCA ESTO-->
		<?php
include_once("encabezado.html");
		?>
<!--aqui se incluye el menu. NO BORRAR NUNCA ESTO-->
<?php
include_once("menus/menu_mantenimiento.html");
		?>
		<!--aqui se incluye el contenido. ESTO ES LO UNICO DONDE VAN IR EDITANDO-->
<article><fieldset>
	
	<?php
	include_once 'conexion.php';
if (isset($_POST['ok'])) {
	$marca=$_POST['marca'];
	$modelo=$_POST['modelo'];
	$tipo=$_POST['tipo'];
	$des=$_POST['descripcion'];
	$carrera=$_POST['carrera'];
	$nombre=$_POST['nombre'];
	$numero=$_POST['numero'];
	$fecha=date("Y/m/d");
	$consultar="select * from equipos where NombreEquipo='$nombre'";
	$r1=$conexion->query($consultar);
	$consultar2="select * from equipos where NumeroSerie='$numero'";
	$r2=$conexion->query($consultar2);
	if ($r1->num_rows>0) {
		echo "Error: El nombre de ese equipo ya está en uso!";   

	}elseif ($r2->num_rows>0) {
		echo "Error: El número de serie del equipo ya está en uso!";   

	}else{
	$inser= "INSERT INTO Equipos (Idmarca,IdModelo,IdTipo,Descripcion,IdCarrera,NombreEquipo,NumeroSerie,Fecha_Registro) 
	VALUES ('$marca','$modelo','$tipo','$des','$carrera','$nombre','$numero','$fecha')";
if ($conexion->query($inser)==TRUE) {
 	
						echo "<H1>REGISTRO INSERTADO</H1>";
						 }else{
echo "<H1>EL REGISTRO NO SE GUARDO </H1>";
}
}}
?>

<form method='post' onsubmit="return checkForm();">
		

<?php
include('conexion.php');


$consulta_marca="Select * from marcas";
$resultado_marcas=$conexion->query($consulta_marca);
$c3=$resultado_marcas->num_rows;

$consulta_modelo="Select * from modelos";
$resultado_m=$conexion->query($consulta_modelo);
$c4=$resultado_m->num_rows;

$consulta_carrera="Select * from Carreras";
$resultado_c=$conexion->query($consulta_carrera);
$c5=$resultado_c->num_rows;

$consulta_tipo="Select * from tiposequipo";
$resultado_t=$conexion->query($consulta_tipo);
$c6=$resultado_t->num_rows;

if ($c3==0 || $c4==0 || $c5==0 || $c6==0) {
	echo "<h1>Deben existir modelos, marcas, carreras y tipos de equipo para poder agregar</h1>";
}else{
	echo "
		<table class=blue-form><tr>
			<th colspan=2>Agregar equipos</th>
		</tr>
		<tr>
			<td>Marca</td>
			<td><select name=marca class=select id=marca onchange=marcas(); autofocus>";
	while ($row3=$resultado_marcas->fetch_assoc()) {
		echo "
<option value=".$row3["IdMarca"].">".$row3["Marca"]."</option>";
}
echo "</select>";
echo "</td>
</tr>";

	echo "<tr id=resultado><td> Modelo</td>
			<td><select name=modelo class=select>";
	
echo "</select>
</td>
</tr>
<tr>
	
			<td>Tipo</td>
<td>
<select name=tipo class=select>";
$sql3="select * from tiposequipo ";
	$resultado3=$conexion->query($sql3);
	while ($row3=$resultado3->fetch_assoc()) {
		echo "
<option value=".$row3["IdTipo"].">".$row3["Tipo"]."</option>";
}
 echo "</select>
</td></tr>
<tr>
<td>Nombre de equipo</td>
<td><input type=text name=nombre id=nombre required=required class=texto placeholder='Ej: Computadora1'></td>
</tr>
<tr>
<td>Número de serie</td>
<td><input type=text name=numero id=numero required=required class=texto></td>
</tr>
<tr>

			<td>Descripcion</td>
		<td><textarea name=descripcion  title=Debe ingresar almenos 8 caracteres  class=textarea ></textarea></td>
</tr><tr>
<td>Carrera a la que pertenece</td>
<td><select name=carrera class=select>";
$sql2="select * from Carreras ";
	$resultado2=$conexion->query($sql2);
	while ($row2=$resultado2->fetch_assoc()) {
		echo "
<option value=".$row2["IdCarrera"].">".$row2["Carrera"]."</option>";
}
echo "</select> </td></tr>
		<tr>
		<th colspan=2 align=center><input type=submit name=ok class=boton value=Aceptar></th>
		</tr>

		
</table>
"
;
}
?>	
<script type="text/javascript">
function xmlhttp(){
        var xmlhttp;
        try{xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");}
        catch(e){
            try{xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");}
            catch(e){
                try{xmlhttp = new XMLHttpRequest();}
                catch(e){
                    xmlhttp = false;
                }
            }
        }
        if (!xmlhttp)
                return null;
            else
                return xmlhttp;
    }

function marcas(){
        var query = document.getElementById('marca').value;
        var A = document.getElementById('resultado');
        var ajax = xmlhttp();
  
        ajax.onreadystatechange=function(){
                
                if(ajax.readyState==4 && ajax.status==200){
                        
                        A.innerHTML = ajax.responseText;
                   
                   
                      
                    }
            }
 ajax.open("GET","ajaxEquipo.php?valor="+encodeURIComponent(query),true);
        ajax.send(null);
        return false;
    }

</script>
	

</form>
</fieldset>
</article>
<!--aqui se incluye el pie de pagina. NO BORRAR NUNCA ESTO-->

			<?php
include_once("pie.html");
		?>
	</section></center>
</section>

</body>
</html>

