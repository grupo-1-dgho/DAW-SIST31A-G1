<?php
@session_start();  
?>
<!DOCTYPE html>
<html>
<head>
	<title>Sistema ITCA</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<style type="text/css">

body{
	font-family: Comic Sans MS,Arial,Verdana;
}
/*esto no lo tienen que editar*/
article{
			width: 75%;
			border-radius: 20px;
			padding: 10px;
			box-sizing: border-box;
			background-color: #459AE5;
			margin: 10px;
			text-align: center;
			font-size: 18px;
		}

/*esto no lo tienen que editar*/
section{
			width: 80%;
			border-radius: 20px;
			padding: 10px;
			box-sizing: border-box;
			background-color: #1C2EDE;
		}

form .texto{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 90%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
form .textarea{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 40%;
			border-radius: 15px;
			height: 90px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
form .select{
			width: 40%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
input[type="checkbox"] {
   width: 20px;
   height: 20px;
}
input[type="radio"] {
   width: 20px;
   height: 20px;
}
.boton{
	/*dependiento del texto del boton pueden cambiarle el ancho en el width*/
	border-radius: 20px;
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 160px;
	font-size: 18px;
	background-color:green;
	color: white;
}

.article2{
	width: 40%;
	background-color: white;
}

	</style>


</head>
<body bgcolor="#9B0B0D">




<?php 
@session_start();
$Usuario='root';
$Contraseña='itca2019';
$Servidor='localhost';
$Basededatos='proyecto2019_5';
if (isset($_POST["entrar"])) {
	$correo=SQLsegura($_POST["correo"]);
	$contraseña=SQLsegura($_POST["contraseña"]);
	$conexion= new mysqli($Servidor,$Usuario,$Contraseña,$Basededatos);
	
	
$sql="SELECT Tipo, Estado FROM Usuarios
WHERE E_mail='$correo' AND Contra='$contraseña'";

	$resultado=$conexion->query($sql);
	
	$cuantos=$resultado->num_rows;


	if ($cuantos==0) {
		echo "<script>alert('Correo o contraseña incorrecta');location.href ='index.php';</script>";
	}else{

$fila=$resultado->fetch_assoc();
	$cargo=$fila["Tipo"];
	$_SESSION["usaindex"]='Si';
	$sql2="Select * from Usuarios where contra='$contraseña'";
	$rs=$conexion->query($sql2);
	$todo=$rs->fetch_assoc();
	foreach ($todo as $key => $value) {
		$_SESSION["usuario2"][$key]=$value;
	}


	
	if($fila["Estado"]=="Activo"){
		$_SESSION["usuario"]["correo"]=$correo;
		$_SESSION["usuario"]["contraseña"]=$contraseña;
		$_SESSION["usuario"]["cargo"]=$cargo;
		if ($cargo=="Administrador") {
		$_SESSION["esadministrador"]='Si';
		}
	header("Location: principal_docente.php");
}else{
	
	echo "<script>alert('Actualmente su usuario se encuentra desactivado');</script>";
}
	
	}}

	elseif  (isset($_POST["cerrar"])) {
	unset($_SESSION["usuario"]);
unset($_SESSION["usuario2"]);
unset($_SESSION["usaindex"]);
unset($_SESSION["esadministrador"]);

	
}



function SQLsegura($strVar){  
 	$banned = array("select", "drop","|","'", ";", "--", "insert","delete", "xp_");     
   $vowels = $banned; 
    $no = str_replace($vowels, "", $strVar);  
    $final = str_replace( "'","",$no);
      return $final; }
      //End Function 
 ?>
<center><article class=article2>
<form method=post>
	<center><table cellspacing=20 >
		<tr><th colspan=2>INGRESE SUS DATOS</th></tr>
		<tr><td colspan=2><img src=img/login.jpg></td></tr>
		<tr><td>Correo:</td><td><input type=email name=correo required=required class=texto></td></tr>
		<tr><td>Contraseña:</td><td><input type=password name=contraseña required=required class=texto></td></tr>
		<tr><th colspan=2><input type=submit name=entrar class=boton value='Iniciar sesión'></th></tr>
	</table>
</center>
</form></article></center>

</body>
</html>

