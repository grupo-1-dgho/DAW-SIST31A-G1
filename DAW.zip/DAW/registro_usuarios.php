<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:index.php");
}elseif (!(isset($_SESSION["esadministrador"]))) {
header("Location:principal_docente.php");
}
  
?>
<?php 
@session_start(); 
include 'conexion.php';

$consulta_departamentos="Select * from Carreras";
$resultado2=$conexion->query($consulta_departamentos);

$n2=$resultado2->num_rows;

?>
<!DOCTYPE html>
<html>

<head>

	
<link rel="stylesheet" type="text/css" href="css/sweetalert2.css">
<script type="text/javascript" src="css/sweetalert2.min.js.download"></script>
	<title>Administrador</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<style type="text/css">
body{
	font-family: Comic Sans MS,Arial,Verdana;
}
/*esto no lo tienen que editar*/
article{
			width: 90%;
			border-radius: 20px;
			padding: 10px;
			box-sizing: border-box;
			background-color: #459AE5;
			margin: 10px;
			text-align: left;
			font-size: 18px;
		}

/*esto no lo tienen que editar*/
section{
			width: 80%;
			border-radius: 20px;
			padding: 10px;
			box-sizing: border-box;
			background-color: #1C2EDE;
		}

.texto{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 90%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
		.texto2{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 40%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
.textarea{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 40%;
			border-radius: 15px;
			height: 90px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
 .select{
			width: 40%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
input[type="checkbox"] {
   width: 20px;
   height: 20px;
}
input[type="radio"] {
   width: 20px;
   height: 20px;
}
.boton{
	/*dependiento del texto del boton pueden cambiarle el ancho en el width*/
	border-radius: 20px;
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 160px;
	font-size: 18px;
	background-color:green;
	color: white;
}
.blue-form { 
    border:3px solid #3E83C9; 
    margin-top: 0px; 
    margin-bottom: 10px; 
    font-size:80%; 
    font-weight: bold;
     width: 80%;
    background-color: white;
 /*establece la altura máxima, lo que no entre quedará por debajo y saldra la barra de scroll*/

} 
.blue-form th{ 
    border-bottom:3px solid #999; 
    width: auto;
    background-color:#9B0B0D;
    color: white; 
} 
.blue-form td{ 
    border-bottom:1px solid #999; 
   width: auto;
} 

.boton2{
	/*dependiento del texto del boton pueden cambiarle el ancho en el width*/
	border-radius: 20px;
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 150px;
	font-size: 18px;
	background-color:#1C2EDE;
	color: white;
}
	</style>

<script type="text/javascript">
	function aler(titulo,mensaje)
	{  Swal.fire({ 
	   type: 'error',   
	    title: titulo,   
	     text: mensaje  
	 }) 
}
 </script> 
<script type="text/javascript">   
	function checkForm(form){         
			      
			 	     
if(form.contra.value.length < 8) { 
msg="Error: La clave debe tener un minimo de 8 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.contra.focus();
return false;       
}  

if(form.contra.value == form.nombre.value) { 
msg="Error: La clave debe ser diferente al nombre !";   
tit="Error!!!";  
aler(tit,msg);          
form.contra.focus();         
return false; 
      }     
re = /[0-9]/;       
if(!re.test(form.contra.value)) {         
aler("Error: la clave debe tener almenos un digito (0-9)!");         
form.contra.focus();         
return false;       } 
re = /[a-z]/;       
if(!re.test(form.contra.value)) {  
msg="Error: La clave debe tener al menos una letra minuscula (a-z)!";   
tit="Error!!!";  aler(tit,msg);  
form.contra.focus();          
return false;       }       
re = /[A-Z]/;       
if (!re.test(form.contra.value)) {  
msg="Error: La clave debe tener al menos una letra mayuscula (A-Z)!";   
tit="Error!!!";  
aler(tit,msg);           
form.contra.focus();          
return false;       
}  
re = /[0-9]/;
if (!re.test(form.carnet.value)) {  
msg="Error: El carnet solo acepta numeros!";   
tit="Error!!!";  
aler(tit,msg);           
form.carnet.focus();          
return false;       
}
if(form.carnet.value.length < 6 || form.carnet.value.length > 6) { 
msg="Error: El carnet tiene que tener 6 números!";   
tit="Error!!!";  
aler(tit,msg);
form.carnet.focus();
return false;       
} 
if(form.nombre.value.length < 3) { 
msg="Error: El nombre tiene que tener al menos 3 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.nombre.focus();
return false;       
}  
if(form.apellido.value.length < 3) { 
msg="Error: El apellido tiene que tener al menos 3 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.apellido.focus();
return false;       
}  

}
     
       </script> 
</head>
<body bgcolor="#9B0B0D">
<?php
$Datetime = 'America/El_Salvador';
date_default_timezone_set($Datetime);
echo "Fecha: " . date("d/m/Y")."<br>" ;
echo "Hora: " . date("h:i:s A")."<br>" ;
  ?>
  <form method="post" action="index.php" >
  	<input type="submit" name="cerrar" value="Cerrar sesión" class="boton2">
  </form>
<center>
<section>
		<!--aqui se incluye el encabezado. NO BORRAR NUNCA ESTO-->
		<?php
include_once("encabezado.html");
		?>
<!--aqui se incluye el menu. NO BORRAR NUNCA ESTO-->
<?php
include_once("menus/menu_mantenimiento.html");
		?>
		<!--aqui se incluye el contenido. ESTO ES LO UNICO DONDE VAN IR EDITANDO-->
<article><fieldset><legend >Registrarse</legend>
	<article class="article2">
<?php
if (isset($_POST['registrar'])) {
	$nombre=ucfirst($_POST['nombre']);
	$apellido=ucfirst($_POST['apellido']);
	$carnet=$_POST['carnet'];
	$correo=$_POST['correo'];
	$contraseña=$_POST['contra'];
	$Cod_Departamento=$_POST['departamento'];


	
	
	$sql="INSERT INTO Usuarios (Carnet,Nombre,Apellido,E_mail,IdCarrera,Contra)
						 VALUES ('$carnet','$nombre','$apellido','$correo','$Cod_Departamento','$contraseña')";
 if ($conexion->query($sql)==TRUE) {
 	
						echo "<h1>Registro guardado</h1>";
						 }else{
echo "<h1>No se guardo el registro</h1>

";
						 } 

}

?>
<?php
include 'conexion.php';
$carreras="select * from carreras";
$r_m=$conexion->query($carreras);
if ($r_m->num_rows==0) {
	echo "<h1>DEBEN EXIXTIR CARRERAS PARA INGRESAR USUARIOS</h1>";
}else{
	echo "<form method=post name=registro onsubmit='return checkForm(this);' >
<table cellpadding=8 class=blue-form>
	
	<tr>
		<td>Nombre:</td><td width=600><input type=text name=nombre class=texto required=required id=nombre title='Debe ingresar almenos 3 caracteres'></td>
	</tr>
	<tr>
		<td>Apellido:</td><td width=600><input type=text name=apellido class=texto required=required id=apellido title='Debe ingresar almenos 3 caracteres'></td>
	</tr>
	<tr>
		<td>Carnet:</td><td><input type=text  name=carnet class=texto2  required=required id=carnet placeholder=000000></td>
	</tr>
	<tr>
		<td>Correo:</td><td><input type=email name=correo class=texto required=required id=correo></td>
	</tr>
	
	
	<tr>
		<td>Carrera:</td><td>
			"; 
if ($n2>0) {
	
	echo "<select name=departamento class=select>";
	while ($row2=$resultado2->fetch_assoc()) {
		echo "
<option value=".$row2["IdCarrera"]." title=".$row2["IdCarrera"].">".$row2["Carrera"]."</option>";
}
echo "</select>";
}
			echo "

		</td>
	</tr>
	<tr>
		<td>Contraseña:</td><td><input type=password name=contra class=texto2 required=required id=contraseña  title='Debe contener 8 o más caracteres '></td>
	</tr>
	<tr><td colspan=2><input type=submit name=registrar class=boton value=Registrar></td></tr>
</table>


</form>";}?>

</article>
</fieldset>
</article>
<!--aqui se incluye el pie de pagina. NO BORRAR NUNCA ESTO-->

			<?php
include_once("pie.html");
		?>
	</section></center>
</section>

</body>
</html>

