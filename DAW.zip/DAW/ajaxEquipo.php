<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:index.php");
}elseif (!(isset($_SESSION["esadministrador"]))) {
header("Location:principal_docente.php");
}
  
?>
<?php  
$valor=$_GET["valor"];
if ($valor!=''){
	$respuesta='';
	include_once("conexion.php");
	$sql="select * from Modelos where IdMarca='$valor'";
	$resultado=$conexion->query($sql);
	$respuesta.="<td> Modelo</td>
			<td><select name=modelo class=select>";
	while ($row=$resultado->fetch_assoc()) {
		$respuesta.= "
<option value=".$row["IdModelo"].">".$row["Modelo"]."</option>";
}
$respuesta.= "</select>
</td>";

		echo "$respuesta";}
?>



