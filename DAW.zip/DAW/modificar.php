<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:index.php");
}

?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/sweetalert2.css">
<script type="text/javascript" src="css/sweetalert2.min.js.download"></script>
<script type="text/javascript">
	function aler(titulo,mensaje)
	{  Swal.fire({ 
	   type: 'error',   
	    title: titulo,   
	     text: mensaje  
	 }) 
}
 </script> 
<script type="text/javascript">   
	function checkForm(form){         
			      
			 	     
if(form.contra.value.length < 8) { 
msg="Error: La clave debe tener un minimo de 8 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.contra.focus();
return false;       
}  

if(form.contra.value == form.nombre.value) { 
msg="Error: La clave debe ser diferente al nombre !";   
tit="Error!!!";  
aler(tit,msg);          
form.contra.focus();         
return false; 
      }     
re = /[0-9]/;       
if(!re.test(form.contra.value)) {         
aler("Error: la clave debe tener almenos un digito (0-9)!");         
form.contra.focus();         
return false;       } 
re = /[a-z]/;       
if(!re.test(form.contra.value)) {  
msg="Error: La clave debe tener al menos una letra minuscula (a-z)!";   
tit="Error!!!";  aler(tit,msg);  
form.contra.focus();          
return false;       }       
re = /[A-Z]/;       
if (!re.test(form.contra.value)) {  
msg="Error: La clave debe tener al menos una letra mayuscula (A-Z)!";   
tit="Error!!!";  
aler(tit,msg);           
form.contra.focus();          
return false;       
}  
re = /[0-9]/;
if (!re.test(form.carnet.value)) {  
msg="Error: El carnet solo acepta numeros!";   
tit="Error!!!";  
aler(tit,msg);           
form.carnet.focus();          
return false;       
}
if(form.carnet.value.length < 6 || form.carnet.value.length > 6) { 
msg="Error: El carnet tiene que tener 6 números!";   
tit="Error!!!";  
aler(tit,msg);
form.carnet.focus();
return false;       
} 
if(form.nombre.value.length < 3) { 
msg="Error: El nombre tiene que tener al menos 3 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.nombre.focus();
return false;       
}  
if(form.apellido.value.length < 3) { 
msg="Error: El apellido tiene que tener al menos 3 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.apellido.focus();
return false;       
}  
if(form.direccion.value.length < 8) { 
msg="Error: La direccion tiene que tener al menos 8 caracteres!";   
tit="Error!!!";  
aler(tit,msg);
form.direccion.focus();
return false;       
} 
}
     
       </script> 
	<title>Administrador</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<style type="text/css">
body{
	font-family: Comic Sans MS,Arial,Verdana;
}
/*esto no lo tienen que editar*/
article{
			width: 90%;
			border-radius: 20px;
			padding: 10px;
			box-sizing: border-box;
			background-color: #459AE5;
			margin: 10px;
			text-align: left;
			font-size: 18px;
		}

/*esto no lo tienen que editar*/
section{
			width: 80%;
			border-radius: 20px;
			padding: 10px;
			box-sizing: border-box;
			background-color: #1C2EDE;
		}

 .texto{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 50%;
			border-radius: 15px;
			height: 25px;
			border:2px solid #3E83C9;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
 .textarea{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 40%;
			border-radius: 15px;
			height: 90px;
			border:1px solid #3E83C9;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
 .select{
			width: 40%;
			border-radius: 15px;
			height: 25px;
			border:2px solid #3E83C9;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
input[type="checkbox"] {
   width: 20px;
   height: 20px;
}
input[type="radio"] {
   width: 20px;
   height: 20px;
}
.radio{
	display: none;
	cursor: pointer;
}
.lbradio{cursor: pointer;}
.boton{
	/*dependiento del texto del boton pueden cambiarle el ancho en el width*/
	border-radius: 20px;
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 100px;
	font-size: 18px;
	background-color: #9B0B0D;
	color: white;
}
.boton2{
	/*dependiento del texto del boton pueden cambiarle el ancho en el width*/
	border-radius: 20px;
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 150px;
	font-size: 18px;
	background-color:#1C2EDE;
	color: white;
}
.blue-form { 
    border:4px solid #3E83C9; 
    margin-top: 0px; 
    margin-bottom: 10px; 
    font-size:85%; 
    font-weight: bold;
     
    background-color: white;
 /*establece la altura máxima, lo que no entre quedará por debajo y saldra la barra de scroll*/

} 


.blue-form td{ 
    border-bottom:1px solid #999; 
   width: auto;
} 



	</style>


</head>
<body bgcolor="#9B0B0D">
<?php
$Datetime = 'America/El_Salvador';
date_default_timezone_set($Datetime);
echo "Fecha: " . date("d/m/Y")."<br>" ;
echo "Hora: " . date("h:i:s A")."<br>" ;

  ?>
  <form method="post" action="index.php">
  	<input type="submit" name="cerrar" value="Cerrar sesión" class="boton2">
  </form>
<center>
<section>
		<!--aqui se incluye el encabezado. NO BORRAR NUNCA ESTO-->
		<?php
include_once("encabezado.html");
		?>
<!--aqui se incluye el menu. NO BORRAR NUNCA ESTO-->

<?php
if ($_SESSION["usuario"]["cargo"]=="Administrador") {
include_once("menus/menu_mantenimiento.html");
}elseif ($_SESSION["usuario"]["cargo"]=="Docente") {
	include_once("menus/menu_docente.html");
}



		?>
		<!--aqui se incluye el contenido. ESTO ES LO UNICO DONDE VAN IR EDITANDO-->
<article>
	

<fieldset><legend >Datos personales</legend>
	
<?php  

if (isset($_POST["ok"])) {
	$nombre=ucfirst($_POST['nombre']);
	$apellido=ucfirst($_POST['apellido']);
	$carnet=$_POST['carnet'];
	$correo=$_POST['correo'];

	
	$contraseña=$_POST['contra'];
	$IdCarrera=$_POST['departamento'];
	$direccion=ucfirst($_POST['direccion']);
	if ($_POST['fecha']!=''){
	$fecha1= strtotime('1960-01-01');
	$fecha2= strtotime('2001-12-31');
$fecha=$_POST['fecha'];
	if (strtotime($fecha)>=$fecha1 and strtotime($fecha)<=$fecha2) {
	
	
$modificar="UPDATE Usuarios set Carnet='$carnet' , Nombre='$nombre' , Apellido='$apellido', E_mail='$correo' , Fecha_Nacimiento='$fecha' , IdCarrera='$IdCarrera' , Contra='$contraseña' , Direccion='$direccion'
where IdUsuario=".$_SESSION["usuario2"]["IdUsuario"]."
";
	include_once("conexion.php");					
 if ($conexion->query($modificar)==TRUE) {

 	$sql2="Select * from Usuarios where contra='$contraseña'";
	$rs=$conexion->query($sql2);
	$todo=$rs->fetch_assoc();
	foreach ($todo as $key => $value) {
		$_SESSION["usuario2"][$key]=$value;
	}
	
echo "<script>alert('Datos Actualizados');location.href ='principal_docente.php';</script>";


					
						 }else{

echo "<script>alert('No se pudieron guardar los datos, verifique la información');</script>";
} 
}else{
	echo "<script>msg='verifique que la fecha de nacimiento se encuentre entre (01/01/1960)-(31/12/2001)'; tit='Error'; aler(tit,msg);</script>";
}
}else{$fecha='yyyy-mm-dd';
$modificar="UPDATE Usuarios set Carnet='$carnet' , Nombre='$nombre' , Apellido='$apellido', E_mail='$correo' , Fecha_Nacimiento='$fecha' , IdCarrera='$IdCarrera' , Contra='$contraseña' , Direccion='$direccion'
where IdUsuario=".$_SESSION["usuario2"]["IdUsuario"]."
";
	include_once("conexion.php");					
 if ($conexion->query($modificar)==TRUE) {

 	$sql2="Select * from Usuarios where contra='$contraseña'";
	$rs=$conexion->query($sql2);
	$todo=$rs->fetch_assoc();
	foreach ($todo as $key => $value) {
		$_SESSION["usuario2"][$key]=$value;
	}
	
echo "<script>alert('Datos Actualizados');location.href ='principal_docente.php';</script>";



}else{
	echo "<script>alert('No se pudieron guardar los datos, verifique la información');</script>";

}

}

}
?>
<table  width=80% cellspacing=15  class=blue-form><form method=post onsubmit="return checkForm(this)">


	<tr>
		
<td >Carnet: <input type=text name=carnet class=texto value="<?php echo $_SESSION["usuario2"]["Carnet"];?>" required=required  title='El carnet debe tener 6 números'> </td>
	</tr>
	<tr>
	<td >Nombre:  <input type=text name=nombre class=texto value="<?php echo $_SESSION["usuario2"]["Nombre"];?>" required=required title='Debe ingresar almenos 3 caracteres'></td>
		
	</tr>
	<tr>
		<td  >Apellido:  <input type=text name=apellido class=texto value="<?php echo $_SESSION["usuario2"]["Apellido"];?> " required=required  title='Debe ingresar almenos 3 caracteres'></td>
		
	</tr>
<tr>
	<td >E-mail:   <input type=email name=correo class=texto 
		value='<?php echo $_SESSION["usuario2"]["E_mail"];?>' required=required></td>
</tr>
<tr>
	<td>Dirección:  <input type=text name=direccion class=texto value='<?php echo $_SESSION["usuario2"]["Direccion"]; ?>' title='Debe ingresar almenos 8 caracteres'></td>
</tr>
<tr>
	<td >Fecha de nacimiento:  <input type=date name=fecha class=texto value="<?php echo $_SESSION["usuario2"]["Fecha_Nacimiento"];?> " ></td>
</tr>
<tr>
	<td  >Contraseña:   <input type=text name=contra class=texto value="<?php echo $_SESSION["usuario2"]["Contra"];?> " required=required title='Debe ingresar almenos 8 caracteres' ></td>
</tr><tr><td>Departamento:
<?php

include 'conexion.php';
$consulta_departamentos="Select * from carreras";
$resultado2=$conexion->query($consulta_departamentos);
$n2=$resultado2->num_rows;


if ($n2>0) {
	
	echo "<select name=departamento class=select>";
	while ($row2=$resultado2->fetch_assoc()) {
		if ($row2[IdCarrera]==$_SESSION["usuario2"]["IdCarrera"]) {
		echo "
<option value=".$row2["IdCarrera"]." title=".$row2["IdCarrera"]." selected=selected>".$row2["Carrera"]."</option>";
		}elseif ($row2[IdCarrera]!=$Cod_Departamento) {
		echo "
<option value=".$row2["IdCarrera"]." title=".$row2["IdCarrera"].">".$row2["Carrera"]."</option>";}
}
echo "</select>";
}

 ?></td></tr>
<tr>
	<td>
		<input type=submit name=ok value=Actualizar class=boton>
	</td>
</tr>
</form></table>
</fieldset>
</article>
<!--aqui se incluye el pie de pagina. NO BORRAR NUNCA ESTO-->
			<?php
include_once("pie.html");
		?>
	</section></center>
</section>

</body>
</html>
