<?php
$Usuario='root';
$Contraseña='itca2019';
$Servidor='localhost';
$Basededatos='proyecto2019_5';
	$conexion= new mysqli($Servidor,$Usuario,$Contraseña,$Basededatos);
	if ($conexion->connect_error) {
	die("Conexion fallida:".$conexion->connect_error);
	}

	?>
