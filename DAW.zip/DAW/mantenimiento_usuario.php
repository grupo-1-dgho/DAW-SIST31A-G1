<?php
@session_start();  
if (!(isset($_SESSION["usaindex"]))){
    header("Location:index.php");
}elseif (!(isset($_SESSION["esadministrador"]))) {
header("Location:principal_docente.php");
}
  
?>
<?php
@session_start(); 
 ?>
<!DOCTYPE html>
<html>
<head>

	<title>Administrador</title>
	<meta charset="utf-8">

<script type="text/javascript">
function xmlhttp(){
        var xmlhttp;
        try{xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");}
        catch(e){
            try{xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");}
            catch(e){
                try{xmlhttp = new XMLHttpRequest();}
                catch(e){
                    xmlhttp = false;
                }
            }
        }
        if (!xmlhttp)
                return null;
            else
                return xmlhttp;
    }

function buscar(){
        var query = document.getElementById('busqueda').value;
        var A = document.getElementById('resultados');
        var B = document.getElementById('loading');
        var ajax = xmlhttp();
 
        ajax.onreadystatechange=function(){
                if(ajax.readyState==1){
                        B.innerHTML = "<img src='images/loading.gif' alg='Loading...'>";
                    }
                if(ajax.readyState==4 && ajax.status==200){
                        
                        A.innerHTML = ajax.responseText;
                        B.innerHTML = "";
                    }
            }
 ajax.open("GET","busqueda.php?valor="+encodeURIComponent(query),true);
        ajax.send(null);
        return false;
    }

</script>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<style type="text/css">
body{
	font-family: Comic Sans MS,Arial,Verdana;
}
/*esto no lo tienen que editar*/
article{
			width: 90%;
			border-radius: 20px;
			padding: 10px;
			box-sizing: border-box;
			background-color: #459AE5;
			margin: 10px;
			text-align: left;
			font-size: 18px;
		}

/*esto no lo tienen que editar*/
section{
			width: 80%;
			border-radius: 20px;
			padding: 10px;
			box-sizing: border-box;
			background-color: #1C2EDE;
		}

.texto{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 30%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
form .textarea{
	/*pueden cambiar el ancho de las cajas de texto dependiento el dato que se vaya a introducir en el width*/
			width: 40%;
			border-radius: 15px;
			height: 90px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
form .select{
			width: 20%;
			border-radius: 15px;
			height: 25px;
			border:1px black solid;
				font-size: 15px;
				font-family: Comic Sans MS,Arial,Verdana;
		}
input[type="checkbox"] {
   width: 20px;
   height: 20px;
}
input[type="radio"] {
   width: 20px;
   height: 20px;
}

.lbradio{cursor: pointer;}
.boton{
	/*dependiento del texto del boton pueden cambiarle el ancho en el width*/
	border-radius: 20px;
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 100px;
	font-size: 18px;
	background-color: #9B0B0D;
	color: white;
}
.boton2{
	/*dependiento del texto del boton pueden cambiarle el ancho en el width*/
	border-radius: 20px;
	font-family: Comic Sans MS,Arial,Verdana;
	cursor: pointer;
	width: 150px;
	font-size: 18px;
	background-color:green;
	color: white;
}
.blue-form { 
    border:3px solid #3E83C9; 
    margin-top: 0px; 
    margin-bottom: 10px; 
    font-size:80%; 
    font-weight: bold;
     width: 80%;
    background-color: white;
 /*establece la altura máxima, lo que no entre quedará por debajo y saldra la barra de scroll*/

} 

.blue-form th{ 
    border-bottom:3px solid #999; 
    width: auto;
    background-color:#9B0B0D;
    color: white; 
} 
.blue-form td{ 
    border-bottom:1px solid #999; 
   width: auto;
} 

	</style>


</head>
<body bgcolor="#9B0B0D">
<?php
$Datetime = 'America/El_Salvador';
date_default_timezone_set($Datetime);
echo "Fecha: " . date("d/m/Y")."<br>" ;
echo "Hora: " . date("h:i:s A")."<br>" ;

  ?>
  <form method="post" action="index.php">
  	<input type="submit" name="cerrar" value="Cerrar sesión" class="boton2">
  </form>
<center>
<section>
		<!--aqui se incluye el encabezado. NO BORRAR NUNCA ESTO-->
		<?php
include_once("encabezado.html");
		?>
<!--aqui se incluye el menu. NO BORRAR NUNCA ESTO-->

<?php
include_once("menus/menu_mantenimiento.html");
		?>
		<!--aqui se incluye el contenido. ESTO ES LO UNICO DONDE VAN IR EDITANDO-->
<article>
	

<fieldset><legend >Buscar Usuarios</legend>
	

Carnet:
<input type=text name=dato required=required class=texto id=busqueda onKeyUp=buscar();>
<div id=resultados class=nocss>
</div>

<?php
if (isset($_POST["btndesactivar"]) ) {
	
	if (!empty($_POST["usuarios"])) {
		$id=$_POST["usuarios"];
include_once("conexion.php");

$update="update Usuarios set Estado='Inactivo' where IdUsuario='$id'";
if ($conexion->query($update)==TRUE) {


}	echo "<script>alert('Modificación de datos exitoso');</script>";


	
	}else{
		
echo "Carnet:
<input type=text name=dato required=required class=texto id=busqueda onKeyUp=buscar();>
<div id=resultados class=nocss>
</div>";
	}

}
elseif (isset($_POST["btnactivar"]) )  {
	
	if (!empty($_POST["usuarios"])) {
		$id=$_POST["usuarios"];
include_once("conexion.php");

$update="update Usuarios set Estado='Activo' where IdUsuario='$id'";
if ($conexion->query($update)==TRUE) {
	
}echo "<script>alert('Modificación de datos exitoso');</script>";



	}else{
		echo "Carnet:
<input type=text name=dato required=required class=texto id=busqueda onKeyUp=buscar();>
<div id=resultados class=nocss>
</div>";
	}

}



 ?>

</form>
</fieldset>
</article>
<!--aqui se incluye el pie de pagina. NO BORRAR NUNCA ESTO-->
			<?php
include_once("pie.html");
		?>
	</section></center>
</section>

</body>
</html>


